<?php

function inPrint_r($array) {

    echo "<pre>";
    print_r($array);
    echo "</pre>";
}

function inForeach($array) {
    if (!empty($array)) {
        foreach ($array as $key => $value) {
            echo $key . "=>" . $value . "<br>";
        }
    }
}

function filter() {
    
}

function comparion($str1, $str2) {
    $percent = 0;
    $count = 0;
    // chuan hoa chuoi dau vao 
    //$strlower1 = strtolower($str1);
    //$strlower2 = strtolower($str2);

    // tach xau
    $array1 = explode(" ", $str1);
    $array2 = explode(" ", $str2);

    $arraySame = array_intersect($array1, $array2);

    $percent = count($arraySame) / count($array1) * 100;
   // echo $percent;
    return $percent;
}

function checkQuestion($str1, $str2, $percent) {
    if ($percent >= 99) {
        echo "Mời bạn xem qua câu hỏi tương tự đã được trả lời. ";
       
        echo "<br>" . $str2;
    } elseif ($percent > 80) {
        echo '<br> Câu hỏi của bạn là : ' . $str1;
        echo '<br> Và câu hỏi này giống tới ' . (int) $percent . '% so với câu hỏi chúng tôi đã trả lời: ';
        echo "<br>" . $str2;
        echo "<br> Bạn có chắc rằng mình muốn tiếp tục gửi câu hỏi này ko?";
        echo '<br><button type ="submit" > Có,Tiếp tục </button><button type ="submit" > Thôi,cảm ơn. </button>';
    }
    else
        echo '<br><button type ="submit" > Có,Tiếp tục </button>' ;
}

function config() {
    $conn = new mysqli('localhost', 'root', '', 'TuyenSinh');

    if ($conn->connect_errno) {
        die("<br>Ket noi that bai :" . $conn->connect_errno);
    } else {
        echo "<br>Ket noi thanh cong ";
    }
}

function creatTable() {


    $sqlCreatTable = "CREATE TABLE Vocabulary ( 
    id INT(11) UNSIGNED  PRIMARY KEY AUTO_INCREMENT,
     OldWords VARCHAR(50)  NOT NULL ,
     NewWords VARCHAR(50)
        )";
    $creatTable = $conn->query($sqlCreatTable);
    if ($creatTable === TRUE) {
        echo "<br> Tao table thanh cong";
    } else {
        echo "<br> Khong tao dc table";
    }
}

function select() {
    $sql_select = "SELECT * FROM Vocabulary";

    $resulf = $conn->query($sql_select);

    if ($resulf && $resulf->num_rows > 0) {
        while ($row = $resulf->fetch_assoc()) {
            echo $row['Words'] . "<br>";
        }
    } else {
        echo "Chua co du lieu.";
    }
}

function checkLength($str, $max, $min) {
    $flat = false;
    $length = strlen($str);
    if ($length < $min || $length > $max) {
        $flat = true;
    }

    return $flat;
}

function checkEmpty($str) {
    $flat = false;
    if (!isset($str) || trim($str) == "") {
        $flat = true;
    }
    return $flat;
}

function menuVoca() {
    
}

function formatString($str) {

    $low = strtolower($str);
    $array = explode(" ", $low);

    foreach ($array as $key => $value) {
        if (trim($value) == null) {
            unset($array[$key]);
        }
    }

    $low = implode(" ", $array);
    $low = ucfirst($low);
    $array = explode(".", $low);

    foreach ($array as $key => $value) {
        $array[$key] = trim($array[$key]);
        $array[$key] = ucfirst($array[$key]);
    }
    $str = implode(".", $array);

    return $str;
}


function editString($str) {
    config();
    $sql_select = "SELECT * FROM Vocabulary";
    $resulf = $conn->query($sql_select);

    if ($resulf && $resulf->num_rows > 0) {

        while ($row = $resulf->fetch_assoc()) {
            $str = str_replace($row['Words'], $row['NewWords'], $str);
        }
    }

    return $str;
}



