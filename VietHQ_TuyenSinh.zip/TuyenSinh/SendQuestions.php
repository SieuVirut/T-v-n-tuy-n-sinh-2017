<!DOCTYPE html>


<head>
    <meta charset="UTF-8">
    <title>Gửi câu hỏi</title>
</head>
<body>
    <?php
    require 'function.php';
    require 'config.php';

    $noti = "Mời bạn nhập tiêu đề câu hỏi và nội dung câu hỏi !";
    $m_title = null;
    $m_content = null;
    $m_vien = "CNTT&TT";

    $change_title = "hidden";
    $change_content = "hidden";
    $change_vien = "hidden";
    $change_noti = "hidden";
    $check_question = "submit";
    $flat = true;



    if (isset($_REQUEST['m_title']) && isset($_REQUEST['m_content'])) {

        $m_title = $_REQUEST['m_title'];
        $m_content = $_REQUEST['m_content'];
        $m_vien = $_REQUEST['m_vien'];

        $noti = null;


        // Dinh dang lai Tieu de va Noi Dung cau hoi. 
        $a_title = formatString($m_title);
        $a_content = formatString($m_content);

        // Kiem tra do dai cua title va content
        if (checkLength($a_title, 100, 10)) {
            $noti .= "Tiêu đề câu hỏi phải >10 kí tự và <100 kí tự !";
            $flat = false;
        }
        if (checkLength($a_content, 500, 20)) {
            $noti .= "Nội dung câu hỏi phải từ 20 đến 500 kí tự !";
            $flat = false;
        }
        if ($flat) {
            $noti = "Câu hỏi đã  ";


            // Bo loc tu vung va chuan hoa SEO 
            $sql_select = "SELECT * FROM Vocabulary";
            $resulf = $conn->query($sql_select);

            if ($resulf && $resulf->num_rows > 0) {

                while ($row = $resulf->fetch_assoc()) {
                    $a_title = str_replace($row['Words'], $row['NewWords'], $a_title);
                    $a_content = str_replace($row['Words'], $row['NewWords'], $a_content);
                }
            }
            // Kiểm tra sự thay đổi nếu có và thông báo 
            if ($m_title == $a_title && $m_content == $a_content) {
                $noti .= " đc giữ nguyên ! ";
                // $check_question = "hidden";
                $change_noti = "submit";
                $change_content = "text";
                $change_title = "text";
            } else {
                // $check_question = "hidden";
                //  $change_noti = "submit";
                $change_vien = "text";
                $change_content = "text";
                $change_title = "text";
                $noti .= " đc thay đổi phần : ";
                $a_vien = "";

                if ($m_title != $a_title) {
                    $noti .= "Tiêu đề ";
                }
                if ($m_content != $a_content) {
                    $noti .= "Câu hỏi ";
                }
            }
        }




        // Kiem tra su ton tai cua cau hoi .
    }
    ?>

    <form method="post" action="#"> 
        <input type="text" name="m_title" value="<?php echo $m_title ?>">
        <input type="text" name="m_content" value="<?php echo $m_content ?>">
        <select name="m_vien"> 
            <option>CNTT&TT</option>
            <option>Toán Tin ƯD</option>
            <option selected="on"><?php echo $m_vien ?></option>
        </select>




        <input type="submit" value="Check Question"> 

        <br>
        <input type="<?php echo $change_title ?>" name="a_title" value=" <?php echo $a_title ?>" readonly="readonly">
        <input type="<?php echo $change_content ?>" name="a_content" value="<?php echo $a_content ?>" readonly="readonly">




    </form>

    <?php
    echo $noti . "<br>";
    ?>
    <?php
    $arraypercent = array();
    $soluong = 15;
    $maxpercent = 0;
    $kodchoi = 95;
    $dcphephoi = 80;
    $num = 1;
    if ($flat) {
        if (isset($_REQUEST['a_title']) && isset($_REQUEST['a_content'])) {

            $change_title = "text";
            $change_content = "text";
            $a_title = $_REQUEST['a_title'];
            $a_content = $_REQUEST['a_content'];

            // Tinh gia tri cua bien auto Vien .
            $a_vien = "CNTT&TT";

            $sql_check = "SELECT * FROM `tb_question` WHERE 1";
            $resulf = $conn->query($sql_check);


            if ($resulf && $resulf->num_rows > 0) {

                while ($row = $resulf->fetch_assoc()) {

                    // So sanh do tuong quan giua tieu de
                    $title = $row['title'];
                    $percent_a = comparion($a_title, $title);

                    // So sanh do tuong quan giua cau hoi
                    $question = $row['question'];
                    $percent_b = comparion($a_content, $question);

                    $percent = $percent_a / 2 + $percent_b / 2;
                    // echo $percent . " <br> ";
                    // Tao mang dong luu cac gia tri tuong quan nhat va ID cua cau hoi tuong quan nhat. 

                    $arraypercent[$row['id']] = $percent;

                    // Sap xep theo gia tri tuong quan tu cao xuong thap
                    arsort($arraypercent);

                    if (count($arraypercent) > $soluong) {
                        array_pop($arraypercent);
                    }
                    $maxpercent = ($percent > $maxpercent) ? $percent : $maxpercent;
                }

                if ($maxpercent >= $kodchoi) {
                    echo "Mời bạn xem qua câu hỏi tương tự đã được trả lời. <br> ";
                    foreach ($arraypercent as $key => $value) {
                        if ($arraypercent[$key] > $kodchoi) {
                            $select = "SELECT * FROM `tb_question` WHERE id = '$key' ";
                            $resulf = $conn->query($select);

                            while ($row = $resulf->fetch_assoc()) {
                                echo "<h4> Câu " . $num . " : </h4>";
                                echo "Câu này giống tới " . (int) $arraypercent[$key] . " % câu hỏi mà bạn " . $row['name_question'] . " hỏi, chúng tôi đã trả lời !";
                                echo " <h3>Tiêu đề : <a href='#' >" . $row['title'] . "</a></h3>";
                                echo "Nội dung: " . $row['question'] . "<hr>";
                                $num ++;
                            }
                        }
                    }
                } elseif ($maxpercent > $dcphephoi) {
                    echo "Mời bạn xem qua câu hỏi tương tự đã được trả lời. <br> ";
                    foreach ($arraypercent as $key => $value) {
                        if ($arraypercent[$key] > $dcphephoi) {
                            $select = "SELECT * FROM `tb_question` WHERE id = '$key' ";
                            $resulf = $conn->query($select);

                            while ($row = $resulf->fetch_assoc()) {
                                echo "<h4> Câu " . $num . " : </h4>";
                                echo "Câu này giống tới " . (int) $arraypercent[$key] . " % câu hỏi mà bạn " . $row['name_question'] . " hỏi, chúng tôi đã trả lời !";
                                echo " <h3>Tiêu đề : <a href='#' >" . $row['title'] . "</a></h3>";
                                echo "Nội dung: " . $row['question'] . "<hr>";
                                $num ++;
                            }
                        }
                    }

                    echo "Câu hỏi của bạn : ";
                    echo " <h3>Tiêu đề : " . $a_title . " </h3>";
                    echo "<b>Nội dung: " . $a_content . "</b><br>";
                    echo "<br> Bạn có chắc rằng mình muốn tiếp tục gửi câu hỏi này ko?";
                    echo '<br><button type ="submit" > Có,Tiếp tục </button><button type ="submit" > Thôi,cảm ơn. </button>';
                } else {
                    echo "Câu hỏi của bạn : ";
                    echo " <h3>Tiêu đề : " . $a_title . " </h3>";
                    echo "<b>Nội dung: " . $a_content . "</b><br>";
                    echo "<br> Bạn có chắc rằng mình muốn tiếp tục gửi câu hỏi này ko?";
                    echo '<br><button type ="submit" > Có,Tiếp tục </button><button type ="submit" > Thôi,cảm ơn. </button>';
                }

                echo "<hr>";
            }
        }
    }
    ?>


</body>
</html>