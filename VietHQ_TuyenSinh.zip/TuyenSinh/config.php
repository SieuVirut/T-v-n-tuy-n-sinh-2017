<?php

$conn = new mysqli('localhost', 'root', '', 'TuyenSinh');
mysqli_set_charset($conn, 'UTF8');
if ($conn->connect_errno) {
    die("<br>Ket noi that bai :" . $conn->connect_errno);
} else {
    //echo "<br>Ket noi thanh cong ";
}


//mysqli_select_db($conn, 'TuyenSinh');
//$sqlInsert = "INSERT INTO TuTuc (keyword) VALUES ('sao khong ket noi dc ? ')";

// $resulf = mysqli_query($conn, $sqlInsert);
//  var_dump($resulf);
//echo $conn->insert_id;



 
  
/*
 * $sql = "CREATE DATABASE TuyenSinh";

if($conn ->query($sql)===TRUE){
    echo "<br> Tao Data Base thanh cong";
} else {
    echo "<br> Khong tao dc DATABASE";
}
$conn ->close();
 
 

$sql = "CREATE TABLE Questions ( 
    id INT(6) UNSIGNED AUTO_INCREAMENT PRIMARY KEY ,
    title VARCHAR(30)  NOT NULL ,
    content TEXT ,
    add_date TIMESTAMP )";
if($conn ->query($sql)===TRUE){
    echo "<br> Tao table thanh cong";
} else {
    echo "<br> Khong tao dc table";
}
$conn ->close();
 */
/*
  $sql = "CREAT DATABASE Questions";



if ($conn ->query($sql)===TRUE){
    echo "Tao thanh cong.";
} else {
    echo "huhu Tao that bai";
}
  $conn ->close();
$sql = null;    
$sql = "SELECT id, title , content FROM Questions";

$resulf = $conn ->query($sql);

if( $resulf -> num_rows > 0 ){
    while ($row = $resulf ->fetch_assoc()){
        echo "Title: ".$row["title"]." -Content: ". $row["content"] . "<br>";
        
    }
} else {
    echo "Khong co record nao.";
} 
 */