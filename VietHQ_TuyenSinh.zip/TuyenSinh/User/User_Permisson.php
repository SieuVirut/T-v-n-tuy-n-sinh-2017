<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Reply by User</title>
    </head>

    <body>


        <?php
        require '../config.php';
        require '../function.php';

        $id = null;
        $manu = null;
        $user = "Tất cả";
        $status = "Tất cả";
        $manu = "Viện CNTT&TT";
        $reply_by = "Tất cả";

        $sql_select = "SELECT * FROM QUESTIONS WHERE Manual_Send_To='$manu'";


        if (isset($_REQUEST['user']) && isset($_REQUEST['status'])) {
            $user = $_REQUEST['user'];
            $status = $_REQUEST['status'];
            if ($user == "Tất cả") {
                $sql_select .= "";
            } elseif ($user == "Chưa phân") {
                 $sql_select .= "AND Reply_By='' OR Reply_By='Chưa phân'";
            } else {
                $sql_select .= "AND Reply_By='$user'";
            }
            if ($status == "Tất cả") {
                $sql_select .= "";
            } else {
                $sql_select .= " AND Check_Reply='$status' ";
            }
        }

        $resulf = $conn->query($sql_select);

        if (isset($_REQUEST['id']) && isset($_REQUEST['reply_by']) && isset($_REQUEST['manual_send_to'])) {
            $id = $_REQUEST['id'];
            $reply_by = $_REQUEST['reply_by'];
            $manu = $_REQUEST['manual_send_to'];


            $sqlUpdate = "UPDATE QUESTIONS SET Manual_Send_To = '$manu',Reply_By = '$reply_by' WHERE ID = '$id' ";

            $update = $conn->query($sqlUpdate);
            if ($update)
                echo $noti = "<p> Cấp quyền thành công câu hỏi $id </p>";
        }
        ?>

        <form action="#">
            <input name="id" type="hidden" value="0">
            <button type="submit"> Xem </button>
            <select name="user">
                <option> Tất cả </option>
                <option>Chưa phân </option>
                <option>Hồ Quang Hiếu </option>
                <option>Nguyễn Gia Thiều</option>
                <option>Phùng Xuân Nhạ</option>
                <option selected="on" > <?php echo $user ?></option>
            </select>
            <select name="status">
                <option>Tất cả</option>
                <option>Chưa trả lời</option>
                <option>Đang trả lời</option>
                <option>Đã trả lời</option>
                <option selected="on" > <?php echo $status ?></option>
            </select>


            <a href="User_Permisson.php" target="_blank" ><button type="button">  Phân Quyền </button> </a>
            <a href="User_Reply.php" target="_blank" ><button type="button">  Trả lời</button> </a>

        </form>
        <hr>



        <?php
        if ($resulf && $resulf->num_rows > 0) {
            $i = 0;
            while ($row = $resulf->fetch_assoc()) {

                // echo var_dump($row) ;
                ?>
                <form action="#">


                    <input name="id" type="hidden" value="<?php echo $row['ID'] ?>">
                    <input name="user" type="hidden" value="<?php echo $user ?>">
                    <input name="status" type="hidden" value="<?php echo $status ?>">


                    <input type="text" value="<?php echo $row['Title'] ?>">
                    <input type="text" value="<?php echo $row['Content'] ?>">
                    <select name="reply_by">
                        <option> Tất cả </option>
                        <option>Chưa phân </option>
                        <option>Hồ Quang Hiếu </option>
                        <option>Nguyễn Gia Thiều</option>
                        <option>Phùng Xuân Nhạ</option>
                        <option selected="on" > <?php echo $row['Reply_By'] ?></option>
                    </select>
                    <select  name="manual_send_to">
                        <option>Chung</option>
                        <option>Viện CNTT&TT</option>
                        <option selected="on" ><?php echo $manu ?> </option>
                    </select>

                    <a href="User_Permisson.php?id=<?php echo $row['ID'] ?>&user=<?php echo $user ?>&status=<?php echo $status ?>&reply_by=<?php echo $reply_by ?>&manual_send_to=<?php echo $manu ?>
                       ">
                        <button type="submit">Phân Quyền</button>
                    </a>


                </form>


                <?php
                $i++;
            } echo "Tổng số: " . $i . " câu hỏi.";
        } else {
            echo "No Data ";
        }
        ?>


    </body>
</html>
