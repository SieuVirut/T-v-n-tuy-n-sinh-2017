<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Vocabulary</title>
    </head>
    <body>


        <?php
        require '../config.php';
        require '../function.php';

        $oldword = null;
        $newword = null;


        $noti = "<p>Thêm từ mới và nghĩa phiên dịch. </p>";

        $error = null;
        if (isset($_REQUEST['Words']) && isset($_REQUEST['NewWords'])) {
            $id     = $_REQUEST['ID'];
            $oldword = $_REQUEST['Words'];
            $newword = $_REQUEST['NewWords'];

            if (checkEmpty($oldword)) {
                $error .= "<p>Từ cập nhập vào không được để rỗng.</p>";
                $noti .= "<p> <small>Nếu là từ bậy, nghĩa phiên dịch để trắng. </small> </p>";
            }
            if (checkLength($oldword, 100, 1)) {
                $error .= "<p> Từ nhập vào phải có tối thiểu 1 kí tự và ít hơn 100 kí tự. </p>";
            }
            $sqlUpdate = "UPDATE Vocabulary SET Words = '$oldword', NewWords = '$newword' WHERE ID = '$id' ";

            $update = $conn->query($sqlUpdate);
            if($update) $error .="<p> Thanh cong </p>";
        }
        ?>

        <div>
            <?php echo $noti; ?>
            <form action="Vocabulary_Insert.php">

                <input method="POST" type="text" name="oldword" value="<?php echo $oldword ?>" >
                <input method="POST" type="text" name="newword" value="<?php echo $newword ?>">
                <button type="submit"> Thêm Từ </button>
                <?php echo $error; ?>     

            </form>
        </div>


        <?php
        $sql_select = "SELECT * FROM `Vocabulary` ORDER BY `Vocabulary`.`ID` DESC ";

        $resulf = $conn->query($sql_select);

        if ($resulf && $resulf->num_rows > 0) {
            $i = 0;
            while ($row = $resulf->fetch_assoc()) {
                echo "<br>";
                ?>
                <form action="Vocabulary_Update.php">
                    <input name="ID" type="hidden" value="<?php echo $row['ID'] ?>">
                    <input name="Words" type="text" value="<?php echo $row['Words'] ?>">
                    <input name="NewWords" type="text" value="<?php echo $row['NewWords'] ?>">
                    <a href="Vocabulary_Update.php?ID='<?php echo $row['ID'] ?>'&Words='<?php echo $row['Words'] ?>'&NewWords='<?php echo $row['NewWords'] ?>'"><button type="submit">  Cập nhập </button></a>
                    <a href="Vocabulary_Delete.php?ID='<?php echo $row['ID'] ?>'"> <button type="button" >  Loại bỏ  </button> </a>
                </form>
               


                <?php
                $i++;
            }
        } else {
            echo "No Data ";
        }
        ?>


    </body>
</html>
