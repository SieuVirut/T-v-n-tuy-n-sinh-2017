<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Phân quyền câu hỏi</title>
    </head>
    <!-- Look of this document is driven by a CSS referenced by an href attribute. See http://www.w3.org/TR/xml-stylesheet/ -->
    <link rel="StyleSheet" type="text/css" href="/PhpProject1/TuyenSinh/admin.css" media="screen" >
    <body>


        <?php
      
        require '../config.php';
        require '../function.php';

        $id = null;
        $manu = null;
        $auto = null;
         $option = "Tất cả";
        $quyen = "Tất cả";
        if (isset($_REQUEST['id']) && isset($_REQUEST['auto_send_to']) && isset($_REQUEST['manual_send_to'])) {
            $id = $_REQUEST['id'];
            $manu = $_REQUEST['manual_send_to'];
            $auto = $_REQUEST['auto_send_to'];

            $sqlUpdate = "UPDATE QUESTIONS SET Manual_Send_To = '$manu', Auto_Send_To = '$auto' WHERE ID = '$id' ";

            $update = $conn->query($sqlUpdate);
            if ($update)
                echo $noti = "<p> Cấp quyền thành công câu hỏi $id </p>";
        }

        $sql_select = "SELECT * FROM QUESTIONS ";
       
         
        if (isset($_REQUEST['vien']) && isset($_REQUEST['quyen'])) {
            $option = $_REQUEST['vien'];
            $quyen = $_REQUEST['quyen'];
            if ($option == "Tất cả") {
                $sql_select .= "WHERE 1";
            } else {
                $sql_select .= "WHERE Manual_Send_To='$option'";
            }
            if ($quyen == "Tất cả")
                ;

            if ($quyen == "Chưa phân quyền")
                $sql_select .= " AND Auto_Send_To != Manual_Send_To ";
            if ($quyen == "Đã phân quyền")
                $sql_select .= " AND Auto_Send_To  = Manual_Send_To ";
        }

        $resulf = $conn->query($sql_select);
        ?>



        <form action="#">
            <input name="id" type="hidden" value="0">
            <button type="submit"> Xem </button>
            <select name="vien">
                <option>Tất cả</option>
                <option>Viện CNTT&TT</option>
                <option>Viện Toán Tin</option>
                <option selected="on" > <?php echo $option ?></option>
            </select>
            <select name="quyen">
                <option>Tất cả</option>
                <option>Chưa phân quyền</option>
                <option>Đã phân quyền</option>
                <option selected="on" > <?php echo $quyen ?></option>
            </select>
            <a href="Questions_Permisson.php" target="_blank" ><button type="button">  Phân Quyền </button> </a>
            <a href="Questions_Edit.php" target="_blank" ><button type="button">  Sửa câu hỏi</button> </a>
            <a href="Questions_Delete.php" target="_blank" ><button type="button">  Xóa câu hỏi</button> </a>
        </form>
        <hr>



        <?php
        if ($resulf && $resulf->num_rows > 0) {
            $i = 0;
            while ($row = $resulf->fetch_assoc()) {

                // echo var_dump($row) ;
                ?>
        <form action="Questions_Permisson.php">
                    <input name="vien" type="hidden" value="<?php echo $option ?>">
                    <input name="quyen" type="hidden" value="<?php echo $quyen ?>">
                    <input name="id" type="hidden" value="<?php echo $row['ID'] ?>">
                    <input type="text" value="<?php echo $row['Title'] ?>">
                    <input type="text" value="<?php echo $row['Content'] ?>">
                    <select name="manual_send_to">
                        <option>Chung</option>
                        <option>Viện CNTT&TT</option>
                        <option>Viện Toán Tin</option>
                        <option selected="on" > <?php echo $row['Manual_Send_To'] ?></option>
                    </select>
                    <select name="auto_send_to">
                        <option>Chung</option>
                        <option>Viện CNTT&TT</option>
                        <option>Viện Toán Tin</option>
                        <option selected="on" ><?php echo $row['Auto_Send_To'] ?> </option>
                    </select>

                    <a href="Questions_Permisson.php?vien=<?php echo $option ?>&quyen=<?php echo $quyen ?>&id=<?php echo $id ?>&manual_send_to=<?php echo $manu ?>&auto_send_to=<?php echo $auto ?>">
                        <button type="submit">Phân Quyền</button>
                    </a>

                </form>
       

                <?php
                $i++;
            } echo "Tổng số: " . $i . " câu hỏi.";
        } else {
            echo "No Data ";
        }
        ?>


    </body>
</html>
