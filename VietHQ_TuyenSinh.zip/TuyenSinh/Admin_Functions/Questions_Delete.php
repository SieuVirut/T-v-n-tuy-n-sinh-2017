<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Xóa câu hỏi</title>
    </head>
    <!-- Look of this document is driven by a CSS referenced by an href attribute. See http://www.w3.org/TR/xml-stylesheet/ -->
    <link rel="StyleSheet" type="text/css" href="/PhpProject1/TuyenSinh/admin.css" media="screen" >
    <body>


        <?php
        require '../config.php';
        require '../function.php';

        $id = null;

        if (isset($_REQUEST['id'])) {
            $id = $_REQUEST['id'];


            $sqlDel = " DELETE FROM QUESTIONS WHERE ID=$id ";

            $del = $conn->query($sqlDel);


            if ($del)
                echo $noti = "<p> Xóa thành công câu hỏi $id </p>";
        }

        $sql_select = "SELECT * FROM QUESTIONS ";
        $option = "Tất cả";
        $quyen = "Tất cả";
        if (isset($_REQUEST['vien']) && isset($_REQUEST['quyen'])) {
            $option = $_REQUEST['vien'];
            $quyen = $_REQUEST['quyen'];
            if ($option == "Tất cả") {
                $sql_select .= "WHERE 1";
            } else {
                $sql_select .= "WHERE Manual_Send_To='$option'";
            }
            if ($quyen == "Tất cả")
               $sql_select ;

            if ($quyen == "Chưa phân quyền")
                $sql_select .= " AND Auto_Send_To != Manual_Send_To ";
            if ($quyen == "Đã phân quyền")
                $sql_select .= " AND Auto_Send_To  = Manual_Send_To ";
        }

        $resulf = $conn->query($sql_select);
        ?>


        <form>
            <input type="hidden" name="id" value="0">

            <button type="submit"> Xem </button> 
            <select name="vien">
                <option>Tất cả</option>
                <option>Viện CNTT&TT</option>
                <option>Viện Toán Tin</option>
                <option selected="on" > <?php echo $option ?></option>
            </select>
            <select name="quyen">
                <option>Tất cả</option>
                <option>Chưa phân quyền</option>
                <option>Đã phân quyền</option>
                <option selected="on" > <?php echo $quyen ?></option>
            </select>
            <a href="Questions_Permisson.php" target="_blank" ><button type="button">  Phân Quyền </button> </a>
            <a href="Questions_Edit.php" target="_blank" ><button type="button">  Sửa câu hỏi</button> </a>
            <a href="Questions_Delete.php" target="_blank" ><button type="button">  Xóa câu hỏi</button> </a>
        </form>

        <hr>



        <?php
        if ($resulf && $resulf->num_rows > 0) {
            $i = 0;
            while ($row = $resulf->fetch_assoc()) {

                // echo var_dump($row) ;
                ?>
                <form>
                    <input name="id" type="hidden" value="<?php echo $row['ID'] ?>">
                    <input name="vien" type="hidden" value="<?php echo $option ?>">
                    <input name="quyen" type="hidden" value="<?php echo $quyen ?>">
                    <input type="text" value="<?php echo $row['Title'] ?>">
                    <input type="text" value="<?php echo $row['Content'] ?>">
                    <input type="text" value="<?php echo $row['Reply'] ?>">
                    <select name="manual_send_to">
                        <option>Chung</option>
                        <option>Viện CNTT&TT</option>
                        <option>Viện Toán Tin</option>
                        <option selected="on" > <?php echo $row['Manual_Send_To'] ?></option>
                    </select>


                    <a href="Questions_Delete.php?vien=<?php echo $option ?>&quyen=<?php echo $quyen ?>&id=<?php echo $id ?>">
                        <button type="submit">Xóa </button>
                    </a>

                </form>


                <?php
                $i++;
            } echo "Tổng số: " . $i . " câu hỏi.";
        } else {
            echo "No Data ";
        }
        ?>


    </body>
</html>
