<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Vocabulary</title>
    </head>
    <!-- Look of this document is driven by a CSS referenced by an href attribute. See http://www.w3.org/TR/xml-stylesheet/ -->
    <link rel="StyleSheet" type="text/css" href="/PhpProject1/TuyenSinh/admin.css" media="screen" >
    <body>


        <?php
        require '../config.php';
        require '../function.php';

        $sql_select = "SELECT * FROM QUESTIONS";
        $option = "Tất cả";
        if (isset($_REQUEST['vien'])) {
            $option = $_REQUEST['vien'];
            if ($option == "Tất cả") {
                $sql_select = "SELECT * FROM QUESTIONS ";
            } else {
                $sql_select = "SELECT * FROM QUESTIONS WHERE Send_To='$option'";
            }
        }
        $resulf = $conn->query($sql_select);
        ?>

        <form>
            <a href="#" ><button type="submit"> Xem </button> </a>
            <select name="vien">
                <option>Tất cả</option>
                <option>Viện CNTT&TT</option>
                <option>Viện Toán Tin</option>
                <option selected="on" > <?php echo $option ?></option>
            </select>
            <a href="Questions_Permisson.php" target="_blank" ><button type="button">  Phân Quyền </button> </a>
            <a href="Questions_Edit.php" target="_blank" ><button type="button">  Sửa câu hỏi</button> </a>
            <a href="Questions_Delete.php" target="_blank" ><button type="button">  Xóa câu hỏi</button> </a>
        </form>








        <?php
        if ($resulf && $resulf->num_rows > 0) {
            $i = 0;
            while ($row = $resulf->fetch_assoc()) {
                //  echo var_dump($row) ;
                ?>
                <table  style="table-layout: fixed"  > 
                    <tr>
                        <th colspan="1"> ID</th>
                        <th colspan="3"> Questions</th>
                        <th colspan="2"> Answer </th>
                        <th colspan="2"> Send To </th>
                        <th colspan="2"> Time </th>
                        <th colspan="1"> Count </th>
                        <th colspan="2"> From </th>
                    </tr>
                    <tr>
                        <td colspan="1" rowspan="3"><?php echo $row['ID']; ?> </td>
                        <td colspan="3" rowspan="1"><?php echo $row['Title']; ?></td>
                        <td colspan="2" rowspan="1">Bởi: <?php echo $row['Reply_By']; ?> </td>
                        <td colspan="2" rowspan="1"><?php echo $row['Manual_Send_To']; ?> </td>
                        <td colspan="2" rowspan="1"><?php echo $row['Time_Send']; ?></td>
                        <td colspan="1" rowspan="1">Xem: <?php echo $row['Count_View']; ?></td>
                        <td colspan="2" rowspan="1"><?php echo $row['Name']; ?></td>
                    </tr>
                    <tr>
                        <td colspan="3" rowspan="2" ><?php echo $row['Content']; ?></td>
                        <td colspan="2" rowspan="2"><?php echo $row['Reply']; ?></td>
                        <td colspan="2" rowspan="1"><?php echo $row['Auto_Send_To']; ?></td>
                        <td colspan="2" rowspan="1"><?php echo $row['Time_Reply']; ?></td>
                        <td colspan="1" rowspan="1">Like: <?php echo $row['Count_Like']; ?></td>
                        <td colspan="2" rowspan="1"><?php echo $row['School']; ?></td>
                    </tr>
                    <tr>
                        <td colspan="2" rowspan="1"><?php echo $row['Check_Reply']; ?></td>
                        <td colspan="2" rowspan="1"><?php echo $row['Time_Post']; ?></td>
                        <td colspan="1" rowspan="1">Tổng: <?php echo $row['Total']; ?></td>
                        <td colspan="2" rowspan="1"><?php echo $row['Email']; ?></td>
                    </tr>
                    <br>

                </table>
                <?php
                $i++;
            } echo "Tổng số: " . $i . " câu hỏi.";
        } else {
            echo "No Data ";
        }
        ?>


    </body>
</html>
