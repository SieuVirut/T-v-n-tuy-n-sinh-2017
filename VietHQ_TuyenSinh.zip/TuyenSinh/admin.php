<?php
require 'config.php';
require 'function.php';


echo '<a href="Admin_Functions/Vocabulary_View.php">asd </a>';