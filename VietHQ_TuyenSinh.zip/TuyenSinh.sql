-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 28, 2017 at 06:57 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `TuyenSinh`
--

-- --------------------------------------------------------

--
-- Table structure for table `AUTO_SEND_TO`
--

CREATE TABLE `AUTO_SEND_TO` (
  `ID` int(6) NOT NULL,
  `Keyword` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Institute` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `id_user` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `AUTO_SEND_TO`
--

INSERT INTO `AUTO_SEND_TO` (`ID`, `Keyword`, `Institute`, `id_user`) VALUES
(1, 'Công nghệ thông tin', 'Viện CNTT&TT', 'cong123,cong234'),
(2, 'Hệ thống thông tin', 'Viện CNTT&TT', '');

-- --------------------------------------------------------

--
-- Table structure for table `QUESTIONS`
--

CREATE TABLE `QUESTIONS` (
  `ID` int(6) NOT NULL,
  `Title` text COLLATE utf8_unicode_ci NOT NULL,
  `Content` text COLLATE utf8_unicode_ci NOT NULL,
  `Manual_Send_To` text COLLATE utf8_unicode_ci NOT NULL,
  `Auto_Send_To` text COLLATE utf8_unicode_ci NOT NULL,
  `Reply` text COLLATE utf8_unicode_ci NOT NULL,
  `Reply_By` text COLLATE utf8_unicode_ci NOT NULL,
  `Check_Reply` text COLLATE utf8_unicode_ci NOT NULL,
  `Time_Send` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Time_Reply` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Time_Post` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Count_View` int(11) NOT NULL,
  `Count_Like` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `Name` text COLLATE utf8_unicode_ci NOT NULL,
  `School` text COLLATE utf8_unicode_ci NOT NULL,
  `Email` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `QUESTIONS`
--

INSERT INTO `QUESTIONS` (`ID`, `Title`, `Content`, `Manual_Send_To`, `Auto_Send_To`, `Reply`, `Reply_By`, `Check_Reply`, `Time_Send`, `Time_Reply`, `Time_Post`, `Count_View`, `Count_Like`, `Total`, `Name`, `School`, `Email`) VALUES
(26, 'Gui vien X', 'hoi the nao thi hoi', 'Chung', 'Viện CNTT&TT', 'cau hoi hay lam', 'Nguyễn Gia Thiều', '0', '2017-08-31 07:24:53', '0000-00-00 00:00:00', '2017-08-31 07:24:53', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(30, 'Gui co giao ', ',sdhakdhasd,sdhakdh asd, sdhakdhasd,s dhakdhasd,sdha kdhasd,sdh akdhasd,sd hakdhasd', 'Viện CNTT&TT', 'Viện CNTT&TT', 'ok gir', 'Hồ Quang Hiếu', 'Đã trả lời', '2017-08-17 00:14:36', '0000-00-00 00:00:00', '2017-08-17 00:14:36', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(33, 'Hay lam co giao a', 'Ko co gi de hoi a', 'Chung', 'Viện CNTT&TT', 'da rep', 'Hồ Quang Hiếu', '0', '2017-09-20 08:13:22', '0000-00-00 00:00:00', '2017-09-20 08:13:22', 0, 0, 0, '', '', ''),
(35, 'Gui vien X', 'Hoi gi the ban oi?', 'Viện CNTT&TT', 'Viện CNTT&TT', 'ok gir', 'Nguyễn Gia Thiều', '0', '2017-08-17 00:03:54', '0000-00-00 00:00:00', '2017-08-17 00:03:54', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(39, 'Gui vien X', 'hoi the nao thi hoi', 'Viện CNTT&TT', 'Viện CNTT&TT', 'cau hoi hay lam', 'Hồ Quang Hiếu', 'Đã trả lời', '2017-08-17 00:00:48', '0000-00-00 00:00:00', '2017-08-17 00:00:48', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(40, 'Gui co giao ', ',sdhakdhasd,sdhakdh asd, sdhakdhasd,s dhakdhasd,sdha kdhasd,sdh akdhasd,sd hakdhasd', 'Viện Toán Tin', 'Viện Toán Tin', 'ok gir', '', '0', '2017-08-16 12:59:55', '0000-00-00 00:00:00', '2017-08-16 12:59:55', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(42, 'Gui vien X', 'Hoi gi the ban oi?', 'Viện Toán Tin', 'Viện Toán Tin', 'ok gir', '', '0', '2017-08-16 17:09:10', '0000-00-00 00:00:00', '2017-08-16 17:09:10', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(43, 'Gui vien X', 'hoi the nao thi hoi', 'Viện CNTT&TT', 'Viện CNTT&TT', 'cau hoi hay lam', 'Hồ Quang Hiếu', 'Đã trả lời', '2017-08-17 00:03:38', '0000-00-00 00:00:00', '2017-08-17 00:03:38', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(44, 'Gui co giao ', ',sdhakdhasd,sdhakdh asd, sdhakdhasd,s dhakdhasd,sdha kdhasd,sdh akdhasd,sd hakdhasd', 'Viện Toán Tin', 'Viện Toán Tin', 'ok gir', '', '0', '2017-08-16 17:11:51', '0000-00-00 00:00:00', '2017-08-16 17:11:51', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(45, '', 'Ko co gi de hoi a', 'Chung', 'Viện CNTT&TT', 'da rep', '', '0', '2017-08-16 12:49:30', '0000-00-00 00:00:00', '2017-08-16 12:49:30', 0, 0, 0, '', '', ''),
(46, 'Gui vien X', 'Hoi gi the ban oi?', 'Viện CNTT&TT', 'Viện CNTT&TT', 'ok gir', 'Chưa phân', '0', '2017-08-17 00:13:18', '0000-00-00 00:00:00', '2017-08-17 00:13:18', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(47, 'Gui vien X', 'hoi the nao thi hoi', 'Viện Toán Tin', 'Viện CNTT&TT', 'cau hoi hay lam', '', 'Đã trả lời', '2017-08-16 14:47:28', '0000-00-00 00:00:00', '2017-08-16 14:47:28', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(48, 'Gui co giao ', ',sdhakdhasd,sdhakdh asd, sdhakdhasd,s dhakdhasd,sdha kdhasd,sdh akdhasd,sd hakdhasd', 'Viện Toán Tin', 'Viện Toán Tin', 'ok gir', '', '0', '2017-08-16 12:56:19', '0000-00-00 00:00:00', '2017-08-16 12:56:19', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(50, 'Gui vien X', 'Hoi gi the ban oi?', 'Viện CNTT&TT', 'Viện CNTT&TT', 'ok gir', 'Hồ Quang Hiếu', '0', '2017-08-17 00:03:48', '0000-00-00 00:00:00', '2017-08-17 00:03:48', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(51, 'Gui vien X', 'hoi the nao thi hoi', 'Viện CNTT&TT', 'Viện CNTT&TT', 'cau hoi hay lam', 'Phùng Xuân Nhạ', '0', '2017-08-17 00:03:58', '0000-00-00 00:00:00', '2017-08-17 00:03:58', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(52, 'Gui co giao ', ',sdhakdhasd,sdhakdh asd, sdhakdhasd,s dhakdhasd,sdha kdhasd,sdh akdhasd,sd hakdhasd', 'Chung', 'Viện CNTT&TT', 'ok gir', 'Chưa phân', 'Đã trả lời', '2017-08-17 00:11:28', '0000-00-00 00:00:00', '2017-08-17 00:11:28', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(53, 'U thay co nao xinh ca', 'Ko co gi de hoi a', 'Chung', 'Viện CNTT&TT', 'da rep', 'Tất cả', '0', '2017-08-16 23:58:28', '0000-00-00 00:00:00', '2017-08-16 23:58:28', 0, 0, 0, '', '', ''),
(54, 'Gui vien X', 'Hoi gi the ban oi?', 'Viện Toán Tin', 'Viện CNTT&TT', 'ok gir', '', '0', '2017-08-16 12:49:21', '0000-00-00 00:00:00', '2017-08-16 12:49:21', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(55, 'Gui vien X', 'hoi the nao thi hoi', 'Viện CNTT&TT', 'Viện CNTT&TT', 'cau hoi hay lam', 'Phùng Xuân Nhạ', '0', '2017-08-17 00:04:02', '0000-00-00 00:00:00', '2017-08-17 00:04:02', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(56, 'Gui co giao ', ',sdhakdhasd,sdhakdh asd, sdhakdhasd,s dhakdhasd,sdha kdhasd,sdh akdhasd,sd hakdhasd', 'Viện Toán Tin', 'Viện Toán Tin', 'ok gir', '', '0', '2017-08-16 12:59:45', '0000-00-00 00:00:00', '2017-08-16 12:59:45', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(58, 'Gui vien X', 'Hoi gi the ban oi?', 'Viện Toán Tin', 'Viện CNTT&TT', 'ok gir', '', '0', '2017-08-16 12:49:21', '0000-00-00 00:00:00', '2017-08-16 12:49:21', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(59, 'Gui vien X', 'hoi the nao thi hoi', 'Viện Toán Tin', 'Viện CNTT&TT', 'cau hoi hay lam', '', '0', '2017-08-16 12:48:45', '0000-00-00 00:00:00', '2017-08-16 12:48:45', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(60, 'Gui co giao ', ',sdhakdhasd,sdhakdh asd, sdhakdhasd,s dhakdhasd,sdha kdhasd,sdh akdhasd,sd hakdhasd', 'Viện CNTT&TT', 'Viện Toán Tin', 'ok gir', 'Chưa phân', '0', '2017-08-17 00:13:40', '0000-00-00 00:00:00', '2017-08-17 00:13:40', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(61, '', 'Ko co gi de hoi a', 'Chung', 'Viện CNTT&TT', 'da rep', '', '0', '2017-08-16 12:49:30', '0000-00-00 00:00:00', '2017-08-16 12:49:30', 0, 0, 0, '', '', ''),
(62, 'Gui vien X', 'Hoi gi the ban oi?', 'Viện Toán Tin', 'Viện CNTT&TT', 'ok gir', '', '0', '2017-08-16 12:49:21', '0000-00-00 00:00:00', '2017-08-16 12:49:21', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(63, 'Gui vien X', 'hoi the nao thi hoi', 'Viện Toán Tin', 'Viện CNTT&TT', 'cau hoi hay lam', '', '0', '2017-08-16 12:48:45', '0000-00-00 00:00:00', '2017-08-16 12:48:45', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(64, 'Gui co giao ', ',sdhakdhasd,sdhakdh asd, sdhakdhasd,s dhakdhasd,sdha kdhasd,sdh akdhasd,sd hakdhasd', 'Chung', 'Viện Toán Tin', 'ok gir', '', '0', '2017-08-16 12:48:56', '0000-00-00 00:00:00', '2017-08-16 12:48:56', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(65, '', 'Ko co gi de hoi a', 'Chung', 'Viện CNTT&TT', 'da rep', '', '0', '2017-08-16 12:49:30', '0000-00-00 00:00:00', '2017-08-16 12:49:30', 0, 0, 0, '', '', ''),
(66, 'Gui vien X', 'Hoi gi the ban oi?', 'Viện Toán Tin', 'Viện CNTT&TT', 'ok gir', '', '0', '2017-08-16 12:49:21', '0000-00-00 00:00:00', '2017-08-16 12:49:21', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(67, 'Gui vien X', 'hoi the nao thi hoi', 'Viện Toán Tin', 'Viện CNTT&TT', 'cau hoi hay lam', '', '0', '2017-08-16 12:48:45', '0000-00-00 00:00:00', '2017-08-16 12:48:45', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu'),
(68, 'Gui co giao ', ',sdhakdhasd,sdhakdh asd, sdhakdhasd,s dhakdhasd,sdha kdhasd,sdh akdhasd,sd hakdhasd', 'Chung', 'Viện Toán Tin', 'ok gir', '', '0', '2017-08-16 12:48:56', '0000-00-00 00:00:00', '2017-08-16 12:48:56', 0, 0, 0, 'nhu kieu', 'thieu ne', 'hoc gu');

-- --------------------------------------------------------

--
-- Table structure for table `tb_question`
--

CREATE TABLE `tb_question` (
  `id` int(5) NOT NULL,
  `name_question` varchar(64) CHARACTER SET utf8 NOT NULL,
  `address_question` varchar(100) CHARACTER SET utf8 NOT NULL,
  `phone_question` int(13) NOT NULL,
  `email_question` varchar(100) CHARACTER SET utf8 NOT NULL,
  `type_question` varchar(64) CHARACTER SET utf8 NOT NULL,
  `time_question` datetime DEFAULT NULL,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `question` text COLLATE utf8_unicode_ci,
  `rep_question` text CHARACTER SET utf8,
  `id_user` varchar(64) CHARACTER SET utf8 DEFAULT NULL,
  `time_rep_question` datetime DEFAULT NULL,
  `time_public` datetime DEFAULT NULL,
  `rank_view` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_question`
--

INSERT INTO `tb_question` (`id`, `name_question`, `address_question`, `phone_question`, `email_question`, `type_question`, `time_question`, `title`, `question`, `rep_question`, `id_user`, `time_rep_question`, `time_public`, `rank_view`) VALUES
(120, 'Phan Quốc Bảo', '(Nam Đàn 1 - Nghệ An)', 123456, 'congpham@gmail.com', '9', '2017-07-17 09:55:45', 'Kính thưa thầy có.  E thi  được', 'Kính thưa thầy có.  E thi  được 26,95( toán 8.2; lý 9.5; hoá 9.25) E có được làm tròn 27 điểm k a. Và 1 điểm ưu tiên KV. Tống gần 28 điểm. E đăng ki vào DHBK. NV1 CNTT; NV2 Điều khiến và tự đông hoá. Vậy xin hỏi E có cần phải đăng kí thêm NV nữa k a. E xin thầy cô tư vân giúp E. E cảm ơn.', NULL, NULL, NULL, NULL, NULL),
(121, 'minh', '(ngô thì nhậm )', 123456, 'congpham@gmail.com', '14', '2017-07-16 13:03:40', 'Kính thưa thầy có.  E thi  được', 'các thầy cho em hỏi sự khác biệt giữa ngành Kỹ thuật điều khiển và tự động hóa và Công nghệ kỹ thuật điều khiển và tự động hóa (CN) với ạ, em cảm ơn ạ ', NULL, NULL, NULL, NULL, NULL),
(122, 'tạ hoàng', '(nguyễn trãi)', 123456, 'congpham@gmail.com', '2', '2017-07-15 21:23:53', 'thầy ơi cho em hỏi, CTTT cơ điện tử gồm những g', 'thầy ơi cho em hỏi, CTTT cơ điện tử gồm những gì và đào tạo như thế nào ạ? Em cảm ơn ạ!', 'VIkdsajflsdkafdsafdsafdsffsdafsdafds dfsafdsafsad', '3', '2017-08-24 10:41:19', '2017-08-24 11:00:00', NULL),
(123, 'tạ hiếu', '(lê quý đôn - đống đa - hà nội)', 123456, 'congpham@gmail.com', '10', '2017-07-15 21:22:19', 'thầy ơi cho em hỏi, CTTT cơ điện tử g', 'Thầy cô cho em hỏi ạ, CTTT Cơ Điện tử , TA chuyên nghiệp quốc tế, TA KHKT công nghệ thì có gì khác nhau và đào tạo như thế nào ạ?\n', NULL, NULL, NULL, NULL, NULL),
(124, 'Nguyễn phương trang', '(Phú Xuyên A)', 123456, 'congpham@gmail.com', '15', '2017-07-15 21:21:10', 'thầy ơi cho em hỏi, CTTT cơ điện tử g0', 'Chào thầy cô, em có câu hỏi:\nEm học ban D, thích học về xã hội. Em không thích mấy vấn đề về kĩ thuật. Vậy có nên học tiếng anh KHKT và CN của trường k ạ?  Và chuyên ngành đào tạo của ngành này là như thế nào ạ? E có phải học về máy móc hay định lý gì k ạ? Cơ hội nghề nghiệp của ngành này thế nào ạ? \nEm cảm ơn!  ', NULL, NULL, NULL, NULL, NULL),
(125, 'Nguyễn Thị Mai Phương', '(Trường THPT Đan Phượng)', 123456, 'congpham@gmail.com', '6', '2017-07-15 21:19:49', 'thầy ơi cho em hỏi, CTTT cơ điện tử g', 'Em muốn tìm hiểu thêm về ngành Tiếng Anh Khoa học kĩ thuật, về chương trình đào tạo cũng như cơ hội việc làm và học phí ạ. Và liệu điểm chuẩn của ngành năm nay sẽ rơi vào khoảng bn ạ? Em cảm ơn!', NULL, NULL, NULL, NULL, NULL),
(126, 'Trần Nguyễn Hồng Lam', '(thpt lê hồng phong)', 123456, 'congpham@gmail.com', '10', '2017-07-15 21:18:14', '0thầy ơi cho em hỏi, CTTT cơ điện tử g', 'cho em hỏi cơ hội làm việc của ngành ngôn ngữ anh quốc tế, ngành này có khác gì với ngành ngôn ngữ anh kĩ thuật', NULL, NULL, NULL, NULL, NULL),
(127, 'Hà Anh', '(thpt cao bá quát )', 123456, 'congpham@gmail.com', '4', '2017-07-15 21:17:57', 'thầy ơi cho em hỏi, CTTT cơ điện tử g', 'e chào thầy cô  ạ, e có 1 số câu hỏi muốn hỏi thầy cô về khoa TA2 và TA1 của trường ạ :\n1. TA1 và TA2 có yêu cầu ielts hay chứng chỉ ngoại ngữ gì k ạ ?\n2. chương trình đào tạo của TA2 và TA1 khác nhau ra sao ạ ? TA2 có học tiếng anh kĩ thuật k ạ ?\n3. Theo thầy cô thì TA1 hay TA2 có cơ hội có việc làm cao hơn ạ ? \nem cảm ơn thầy cô ạ !', NULL, NULL, NULL, NULL, NULL),
(128, 'phạm hà', '(B DUY TIÊN)', 123456, 'congpham@gmail.com', '12', '2017-07-15 21:13:41', 'thầy ơi cho em hỏi, CTTT cơ điện tử g', 'thưa thầy cô, các khoa chương trình tiên tiến như tt21,tt22..  có xét tiêu chuẩn đầu vào tiếng anh như năm 2016 không ạ', NULL, NULL, NULL, NULL, NULL),
(129, 'nguyễn ngọc tiến ', '(Nguyễn Bỉnh Khiêm)', 123456, 'congpham@gmail.com', '4', '2017-07-14 15:45:20', 'a điện tử viễn thông hệ quốc tế của ...', 'cho em hỏi khoa điện tử viễn thông hệ quốc tế của Đức thì điểm xét tuyển khối nào ạ???', NULL, NULL, NULL, NULL, NULL),
(130, 'Lê Quý Đôn', '(Lê Quý Đôn)', 123456, 'congpham@gmail.com', '15', '2017-07-14 14:03:15', 'ho e hỏi nếu được tuyển thẳng vào trường ', 'Cho e hỏi nếu được tuyển thẳng vào trường có nhất định phải học ở trường này k ạ?', NULL, NULL, NULL, NULL, NULL),
(131, 'Nguyễn Tú', '(THPT Đan Phượng)', 123456, 'congpham@gmail.com', '13', '2017-07-14 13:59:55', 'thầy ơi cho em hỏi, CTTT cơ điện tử g', 'thầy cô cho em hỏi là vs BKHN thì điểm toán ( ngành có môn chinh) có làm tròn đến 0.5 ko ạ?\nvà theo công thức tính điểm, mới thì em được 24,125 thì có được làm tròn đến 24,25 ko ạ?\nEm cảm ơn.', NULL, NULL, NULL, NULL, NULL),
(132, 'Nguyễn Đình Nam', '(Trường THPT Cổ Loa)', 123456, 'congpham@gmail.com', '13', '2017-07-14 13:57:09', 'thầy ơi cho em hỏi, CTTT cơ điện tử g', 'Kính gửi quý thầy cô, với số điểm hiện tại của em là 24,5 thì em đã trượt các nguyện vọng trước của mình. Bây giờ em muốn chuyển nguyện vọng sang Trường Đại Học Bách Khoa Hà Nội (trước đó em không đăng ký nguyện vọng Bách Khoa) thì em phải đến trường xin chuyển hay em có thể chuyển nguyện vọng qua mạng ạ. Em xin chân thành cảm ơn.', NULL, NULL, NULL, NULL, NULL),
(133, 'Đỗ Thảo Linh', '(Việt Nam-Ba Lan)', 123456, 'congpham@gmail.com', '10', '2017-07-13 16:10:35', '0thầy ơi cho em hỏi, CTTT cơ điện tử g', 'Nếu trượt nguyện vọng 1 của mình e có được trườg em đăng kí nghyện vọng 2 nhận xét tuyển và mức điểm xét tuyển của nguyện vọng 2 có bị tăng lên không ạ', NULL, NULL, NULL, NULL, NULL),
(134, 'Nguyễn Thùy An', '(THPT Quỳnh Lưu 1)', 123456, 'congpham@gmail.com', '16', '2017-07-13 16:07:46', 'thầy ơi cho em hỏi, CTTT cơ điện tử g', 'Em chào thầy cô và anh chị ạ. Kết quả thi đại học của e vừa rồi là 8,08 ạ. Điểm toán e là 9 ạ. E trước đăng kí nguyện vọng 1 vào ngành KT31 ạ. E xin các thầy cô tư vấn là liệu e có khả năng đậu vào ngành ấy của trường đại học Bách Khoa Hà Nội ko ạ? E xin chân thành cảm ơn ạ.', NULL, NULL, NULL, NULL, NULL),
(135, 'Hoàng Nam Tiến', '(THPT Hàm Rồng)', 123456, 'congpham@gmail.com', '8', '2017-07-13 14:53:27', 'thầy ơi cho em hỏi, CTTT cơ điện tử g', 'thầy cô cho em hỏi năm nay 23   0,5 ( điểm vùng) và toán được 8,4 thì liệu có đỗ được KT11 ko ạ?', NULL, NULL, NULL, NULL, NULL),
(136, 'lê thị ngọc hà', '(thpt pd)', 123456, 'congpham@gmail.com', '16', '2017-07-13 14:29:34', 'thầy ơi cho em hỏi, CTTT cơ điện tử g', 'E dk khoang 26.5 có đỗ dk kt 31 k', NULL, NULL, NULL, NULL, NULL),
(137, 'Trần Quang Hải', '(THPT Bắc Sơn)', 123456, 'congpham@gmail.com', '9', '2017-07-13 14:24:34', '0thầy ơi cho em hỏi, CTTT cơ điện tử g', 'Kính chào quý Thầy (Cô). \r\nEm hiện đã có kết quả thi THPT 2007 khối A1: Toán 8,6; Lý 5,5 ; Anh 8,4. Khu vực ưu tiên nơi em học được cộng 1,5 điểm. Với kết quả đó, em có cơ hội trúng tuyển vào khoa nào của trường a? ', NULL, NULL, NULL, NULL, NULL),
(138, 'Đỗ Thảo Linh', '(Việt Nam-Ba Lan)', 123456, 'congpham@gmail.com', '5', '2017-07-13 14:22:28', 'thầy ơi cho em hỏi, CTTT cơ điện tử g', 'E đăng kí 3 NV nếu trúng cả 3 e có thể nộp hồ sơ vào NV 2 hoặc 3 mà bỏ qua NV1 không ạ?', NULL, NULL, NULL, NULL, NULL),
(139, 'Hoàng Minh Châu', '(Thpt chuyên ngoại ngữ đại học quốc gia)', 123456, 'congpham@gmail.com', '12', '2017-07-13 14:20:23', 'thầy ơi cho em hỏi, CTTT cơ điện tử g', 'Con nhà tôi thi được 24 điểm khối A1 và 25,5 điểm khối D thì có thể dăng ký vào khoa nào của trường?', NULL, NULL, NULL, NULL, NULL),
(140, 'Nguyễn quang Anh', '(Nguyễn Gia Thiều)', 123456, 'congpham@gmail.com', '10', '2017-07-13 14:18:32', '0thầy ơi cho em hỏi, CTTT cơ điện tử g', 'Thưa thầy nếu em đăng ký NV1 là KT13 nhưng bây giờ  điểm thi  em đạt cao hơn em muôn thay đổi NV sang KT21 thì em có cơ hội đỗ hơn các ban đăng ký KT21 ngay từ đầu ko ạ.', NULL, NULL, NULL, NULL, NULL),
(141, 'vũ công anh', '(thpt Trí Đức - Hà Nội)', 123456, 'congpham@gmail.com', '5', '2017-07-13 14:10:30', 'thầy ơi cho em hỏi, CTTT cơ điện tử g', 'Thầy cô cho em xin hỏi, điểm thi của em khối AO1 là: Toán 8, lý 6, Anh 6,25 Tổng cộng là 20,25 điểm, em đăng ký nguyện vọng KT22 như vậy em có đủ điểm để vào trường không ạ? em xin cảm ơn Thầy cô ạ ', NULL, NULL, NULL, NULL, NULL),
(142, 'Lê Vĩnh Phúc', '(Thăng long)', 123456, 'congpham@gmail.com', '5', '2017-07-13 14:07:03', 'thầy ơi cho em hỏi, CTTT cơ điện tử g', 'Em thi đựơc 21.8 điểm liệu em có đỗ được CTTT công nghệ thông tin hoặc Cơ điện tử Nagaoka nhật bản không ạ ?', NULL, NULL, NULL, NULL, NULL),
(143, 'Phạm Hà Linh', '(Nguyễn Du)', 123456, 'congpham@gmail.com', '7', '2017-07-13 14:04:14', 'thầy ơi cho em hỏi, CTTT cơ điện tử g', 'Chao thay co em co cau hoi : Khi nào thì cần nộp hồ sơ xét tuyển ạ . Và hồ dơ bao gồm những gì ạ . E c.ơn', 'ỪA E CỨ NÓIFDSKLFJ SDFJSDLKJFLKJDSLJFLKADSJFKLSDJ', '7', '2017-08-31 13:02:20', '2017-08-31 22:00:00', NULL),
(144, 'Phạm Văn Đắc', '(Trường THPT Bình Lục A)', 123456, 'congpham@gmail.com', '8', '2017-07-13 14:02:02', 'thầy ơi cho em hỏi, CTTT cơ điện tử g', 'Các thầy cô cho em hỏi .Năm nay nhà trường xét tuyển nguyện vọng như thế nào ạ .Các nguyện vọng ưu tiên từ trên xuống hay là mức độ ưu tiên là như nhau .Giả sử em được 27 điểm và em đỗ tất các khoa của trường thì em có quyền  được chọn bất kỳ nhóm ngành mình đã đăng kí hay là theo thứ tự ưu tiên từ trên xuống ạ .Em cảm ơn ', NULL, NULL, NULL, NULL, NULL),
(145, 'NGUYỄN THỊ PHƯƠNG', '(NGUYỄN ĐỨC THUẬN)', 123456, 'congpham@gmail.com', '3', '2017-07-13 10:58:58', '0', 'Cho em hỏi chương trình tiên tiến của trường như điện -điện tử ,  cơ điện tử ngoài xét điểm trúng tuyển đại học ra có xét thêm tiêu chí phị nào không ạ ? ví dụ như điểm thi môn Tiếng Anh .', NULL, NULL, NULL, NULL, NULL),
(146, 'Le thanh hiền', '(Thpt uông bí)', 123456, 'congpham@gmail.com', '2', '2017-07-13 10:55:53', '0', 'Cho e hỏi ngành công nghệ thông tin và nghành điện tử viễn thông bách khoa có bao nhieu hs dăng ký ty le 1chọi may e dc 25.6điên da cộng 0,5 diem khu vuc toan e dc8.6 vay có len dăng ky 2 nghành do o trương  o a', 'VIkdsajflsdkafdsafdsafdsffsdafsdafds dfsafdsafsad f', '3', '2017-08-24 10:41:19', '2017-08-24 11:00:00', NULL),
(147, 'Đỗ thu hoà', '(Chuyên biên hoà)', 123456, 'congpham@gmail.com', '4', '2017-07-13 10:52:05', '0', 'Em đươc 27 điểm của 3 môn toán, lý , hóa  trong kỳ th tốt nghiệp ptth năm 2017. Nếu chọn bách khoa thí nên chọn khoa nào?', NULL, NULL, NULL, NULL, NULL),
(148, 'Nguyễn Tấn DŨng', '(THPT Đông Triều)', 123456, 'congpham@gmail.com', '11', '2017-07-13 10:48:57', '0', 'E thi đươc 20,55 0,5 (điểm vùng) có cơ hội đỗ ngành công nghệ thông tin tại trường không ạ. Mong nhận được câu trả lời sớm từ tổ tư vấn.Em cảm ơn', NULL, NULL, NULL, NULL, NULL),
(149, 'Đặng Văn Đức', '(Nam Đông Quan)', 123456, 'congpham@gmail.com', '16', '2017-07-13 10:45:27', '0', '-Cho em hỏi năm nay trường xét tuyển theo cách tính điểm như nào ạ\n-Em được ttỏng 3 môn toán lý hóa là 26,4 và thêm 1 điểm khu vực nữa thì liệu sẽ vào được các ngành nào trong 3 ngành\n1. Công nghệ thông tin\n2. Điện - Điều khiển và tự động hóa\n3. Cơ điện tử\nEm xin cảm ơn ạ!', NULL, NULL, NULL, NULL, NULL),
(150, 'Hoàng Thành Trung', '(Xuân Hòa)', 123456, 'congpham@gmail.com', '8', '2017-07-13 10:44:21', '0', 'Chào thầy cô ạ, cho em hỏi là điều kiện để đăng kí vào lớp tài năng là gì ạ vào bao giờ thì bắt đầu xét điều kiện để học lớp tài năng ạ? Em cảm ơn', NULL, NULL, NULL, NULL, NULL),
(151, 'Nguyễn Khắc Trung', '(Trường THPT Nguyễn Trãi - Thường Tín)', 123456, 'congpham@gmail.com', '10', '2017-07-13 09:44:29', '0', 'Em được Toán 8.00  Lý 7.00 Hóa 6,25 mong thầy cô tư vấn cho em đủ điều kiện vào ngành nào của trường', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `USER`
--

CREATE TABLE `USER` (
  `ID` int(11) NOT NULL,
  `Name` text COLLATE utf8_unicode_ci NOT NULL,
  `Pass` text COLLATE utf8_unicode_ci NOT NULL,
  `Level` text COLLATE utf8_unicode_ci NOT NULL,
  `Institute` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Vocabulary`
--

CREATE TABLE `Vocabulary` (
  `ID` int(11) UNSIGNED NOT NULL,
  `Words` text COLLATE utf8_unicode_ci NOT NULL,
  `NewWords` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Vocabulary`
--

INSERT INTO `Vocabulary` (`ID`, `Words`, `NewWords`) VALUES
(44, 'nguye', 'Nguyễn'),
(49, 'cntt', 'CNTT&TT'),
(70, 'chường', 'trường'),
(73, 'họk sih', 'học sinh'),
(83, 'đếch', ''),
(90, 'méo', ''),
(97, 'bkhn', 'Bách Khoa Hà Nội'),
(98, 'hoa hậy', 'hoa hậu'),
(99, 'hao hậy', 'hoa hậu');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `AUTO_SEND_TO`
--
ALTER TABLE `AUTO_SEND_TO`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `QUESTIONS`
--
ALTER TABLE `QUESTIONS`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tb_question`
--
ALTER TABLE `tb_question`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Vocabulary`
--
ALTER TABLE `Vocabulary`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `AUTO_SEND_TO`
--
ALTER TABLE `AUTO_SEND_TO`
  MODIFY `ID` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `QUESTIONS`
--
ALTER TABLE `QUESTIONS`
  MODIFY `ID` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
--
-- AUTO_INCREMENT for table `Vocabulary`
--
ALTER TABLE `Vocabulary`
  MODIFY `ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
