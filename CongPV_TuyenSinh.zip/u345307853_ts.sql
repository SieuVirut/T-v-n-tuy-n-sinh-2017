-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 03, 2017 at 07:43 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u345307853_ts`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_question`
--

CREATE TABLE `tb_question` (
  `id` int(5) NOT NULL,
  `name_question` varchar(64) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci NOT NULL,
  `address_question` varchar(100) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci NOT NULL,
  `phone_question` int(13) NOT NULL,
  `type_question` varchar(64) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci NOT NULL,
  `time_question` datetime DEFAULT NULL,
  `question` text CHARACTER SET utf8 COLLATE utf8_vietnamese_ci,
  `rep_question` text CHARACTER SET utf8 COLLATE utf8_vietnamese_ci,
  `name_rep_question` varchar(64) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `time_rep_question` date DEFAULT NULL,
  `emai_question` varchar(64) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_question`
--

INSERT INTO `tb_question` (`id`, `name_question`, `address_question`, `phone_question`, `type_question`, `time_question`, `question`, `rep_question`, `name_rep_question`, `time_rep_question`, `emai_question`) VALUES
(4, 'Phan Quá»‘c Báº£o', 'Nam ÄÃ n 1 - Nghá»‡ An', 1658, '', '2017-07-27 09:43:48', ' KÃ­nh thÆ°a tháº§y cÃ³. E thi Ä‘Æ°á»£c 26,95( toÃ¡n 8.2; lÃ½ 9.5; hoÃ¡ 9.25) E cÃ³ Ä‘Æ°á»£c lÃ m trÃ²n 27 Ä‘iá»ƒm k a. VÃ  1 Ä‘iá»ƒm Æ°u tiÃªn KV. Tá»‘ng gáº§n 28 Ä‘iá»ƒm. E Ä‘Äƒng ki vÃ o DHBK. NV1 CNTT; NV2 Äiá»u khiáº¿n vÃ  tá»± Ä‘Ã´ng hoÃ¡. Váº­y xin há»i E cÃ³ cáº§n pháº£i Ä‘Äƒng kÃ­ thÃªm NV ná»¯a k a. E xin tháº§y cÃ´ tÆ° vÃ¢n giÃºp E. E cáº£m Æ¡n.', 'dsafdsafdsafasd', 'dsafdsafdasf', NULL, 'Nam ÄÃ n 1 - Nghá»‡ An'),
(5, 'minh', 'ngÃ´ thÃ¬ nháº­m', 1234, '', '2017-07-27 09:44:32', 'cÃ¡c tháº§y cho em há»i sá»± khÃ¡c biá»‡t giá»¯a ngÃ nh Ká»¹ thuáº­t Ä‘iá»u khiá»ƒn vÃ  tá»± Ä‘á»™ng hÃ³a vÃ  CÃ´ng nghá»‡ ká»¹ thuáº­t Ä‘iá»u khiá»ƒn vÃ  tá»± Ä‘á»™ng hÃ³a (CN) vá»›i áº¡, em cáº£m Æ¡n áº¡', 'ChÃ o Minh,\r\n\r\nViá»‡n Äiá»‡n tá»« trÆ°á»›c nÄƒm 2009 chÃºng tÃ´i chá»‰ Ä‘Ã o táº¡o ká»¹ sÆ° ká»¹ thuáº­t Ä‘iá»u khiá»ƒn tá»± Ä‘á»™ng hÃ³a vÃ  ká»¹ sÆ° ká»¹ thuáº­t Ä‘iá»‡n. Tá»« nÄƒm 2009 Viá»‡n Äiá»‡n phÃ¡t triá»ƒn thÃªm mÃ´ hÃ¬nh Ä‘Ã o táº¡o cá»­ nhÃ¢n ká»¹ thuáº­t vÃ  cá»­ nhÃ¢n cÃ´ng nghá»‡ (theo Ä‘á»‹nh hÆ°á»›ng chung cá»§a toÃ n trÆ°á»ng. NÄƒm 2010 chÃºng tÃ´i chÃ­nh thá»©c tuyá»ƒn sinh thÃªm ngÃ nh cÃ´ng nghá»‡ Ä‘iá»u khiá»ƒn vÃ  tá»± Ä‘á»™ng hÃ³a chuyÃªn vá» báº£o dÆ°á»¡ng vÃ  váº­n hÃ nh há»‡ thá»‘ng Ä‘o lÆ°á»ng Ä‘iÃªu khiá»ƒn tá»± Ä‘á»™ng. ChÆ°Æ¡ng trÃ¬nh cá»­ nhÃ¢n cÃ³ thá»i gian há»c táº­p chuáº©n lÃ  4 nÄƒm. ChÆ°Æ¡ng trÃ¬nh cá»­ nhÃ¢n ká»¹ thuáº­t chuyÃªn vá» tÃ­ch há»£p, thiáº¿t káº¿ thiáº¿t bá»‹ vÃ  há»‡ thá»‘ng.', 'dsfdsafsadf', NULL, 'ngÃ´ thÃ¬ nháº­m'),
(6, 'táº¡ hoÃ ng', 'nguyá»…n trÃ£i', 21321312, '', '2017-08-03 04:48:57', 'tháº§y Æ¡i cho em há»i, CTTT cÆ¡ Ä‘iá»‡n tá»­ gá»“m nhá»¯ng gÃ¬ vÃ  Ä‘Ã o táº¡o nhÆ° tháº¿ nÃ o áº¡? Em cáº£m Æ¡n áº¡!', 'lkafdsjlfasdf', NULL, NULL, 'dsafasdf@gmail.com'),
(7, ' táº¡ hiáº¿u ', 'lÃª quÃ½ Ä‘Ã´n - Ä‘á»‘ng Ä‘a - hÃ  ná»™i', 1234, '', '2017-08-03 04:49:40', 'Tháº§y cÃ´ cho em há»i áº¡, CTTT CÆ¡ Äiá»‡n tá»­ , TA chuyÃªn nghiá»‡p quá»‘c táº¿, TA KHKT cÃ´ng nghá»‡ thÃ¬ cÃ³ gÃ¬ khÃ¡c nhau vÃ  Ä‘Ã o táº¡o nhÆ° tháº¿ nÃ o áº¡?', NULL, NULL, NULL, 'dsfsdafads@gmail.com'),
(8, 'NguyÃªÌƒn phÆ°Æ¡ng trang ', 'PhuÌ XuyÃªn A', 21321312, '', '2017-08-03 04:50:40', 'ChaÌ€o thÃ¢Ì€y cÃ´, em coÌ cÃ¢u hoÌ‰i: Em hoÌ£c ban D, thiÌch hoÌ£c vÃªÌ€ xaÌƒ hÃ´Ì£i. Em khÃ´ng thiÌch mÃ¢Ìy vÃ¢Ìn Ä‘ÃªÌ€ vÃªÌ€ kiÌƒ thuÃ¢Ì£t. VÃ¢Ì£y coÌ nÃªn hoÌ£c tiÃªÌng anh KHKT vaÌ€ CN cuÌ‰a trÆ°Æ¡Ì€ng k aÌ£? VaÌ€ chuyÃªn ngaÌ€nh Ä‘aÌ€o taÌ£o cuÌ‰a ngaÌ€nh naÌ€y laÌ€ nhÆ° thÃªÌ naÌ€o aÌ£? E coÌ phaÌ‰i hoÌ£c vÃªÌ€ maÌy moÌc hay Ä‘iÌ£nh lyÌ giÌ€ k aÌ£? CÆ¡ hÃ´Ì£i nghÃªÌ€ nghiÃªÌ£p cuÌ‰a ngaÌ€nh naÌ€y thÃªÌ naÌ€o aÌ£? Em caÌ‰m Æ¡n!', NULL, NULL, NULL, 'dsafasdf@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id` int(11) UNSIGNED NOT NULL,
  `username` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fullname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` tinyint(1) DEFAULT NULL,
  `add_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id`, `username`, `password`, `email`, `fullname`, `level`, `add_date`) VALUES
(1, 'admin_question', '81dc9bdb52d04dc20036dbd8313ed055', 'admin_question@gmail.com', 'PhamCong', 1, NULL),
(2, 'admin_tt', '81dc9bdb52d04dc20036dbd8313ed055', 'admin_tt@gmail.com', 'Ha Viet', 2, NULL),
(3, 'admin_web', '81dc9bdb52d04dc20036dbd8313ed055', 'admin_web@gmail.com', 'Ha Viet', 3, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_question`
--
ALTER TABLE `tb_question`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_question`
--
ALTER TABLE `tb_question`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
