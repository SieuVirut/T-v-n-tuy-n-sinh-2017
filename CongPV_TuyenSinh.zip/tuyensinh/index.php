<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');
?>
<!doctype html>
<html>
<head>
	<meta charset="utf-8">
    <title>Trang tuyển sinh Đại hoc bách khoa Hà Nội</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="lib/style.css" type="text/css" media="screen">
    <script type="text/javascript" src="lib/totop.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Pacifico&amp;subset=latin-ext,vietnamese" rel="stylesheet">
</head>
<body class="tuyensinh">
	
	<nav id="main" data-controller="MainNav" style="margin-top: -110px;">
		<ul>
        	<li data-id="question" class=" ">
        		<h1 style="display: none; right: 15px; opacity: 0;">
        		<span>Gửi câu hỏi</span>
        		</h1>
        		<a href="#from_ques">Gửi câu hỏi</a>
        	</li>
        	<li data-id="top_question" class=" ">
        		<h1 style="display: none; right: 15px; opacity: 0;">
        		<span>Top cậu hỏi</span>
        		</h1>
        		<a href="#ttr_content_and_sidebar_container">Top câu hỏi</a>
        	</li>
            <li data-id="new_question" class=" ">
        		<h1 style="display: none; right: 15px; opacity: 0;">
        		<span>Câu hỏi mới</span>
        		</h1>
        		<a href="#new_question">câu hỏi mới</a>
        	</li>
        </ul>
    </nav>
	<div class="totopshow">
    	<a href="#" class="back-to-top">
        <img alt="Lên đầu trang" src="images/gototop0.png">
        </a>
    </div>
    <div id="ttr_page" class="container" style="width:90%">
        <nav class="navbar navbar-inverse row" style="background-color:#8DC26F !important;">
                <div class="col-lg-4 col-md-4 col-xs-4"><a style="padding-top:0px !important; z-index:9" href="http://ts.hust.edu.vn">
                        	<img src="images/logo.png" alt="Tuyển sinh ĐHBK Hà Nội">
                    </a></div>
            <div class="container-fluid col-lg-8 col-md-8 col-xs-8" style="z-index:1 !important">
            	<div class="navbar-header">
                    <button id="nav-expander" data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
					</button>
                    
				</div>
                <div class="collapse navbar-collapse" id="myNavbar">
                	<ul class="nav navbar-nav">
                        <li><a href="#">Trang chủ</a></li>
                        <li><a href="#" onClick="myFunction_letter()" id="qu_form">Học sinh hỏi</a></li>
                        <li><a href="#">Sinh Viên hỏi</a></li>
                        <li><a href="#">Phự huynh hởi</a></li>
                    </ul>
                    	<ul class="nav navbar-nav navbar-right" >
                        <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span>Đăng nhập</a></li>
                    </ul>
                </div>
			</div>
		</nav>
        <div class="ttr_banner_slideshow"></div>
        <div class="ttr_slideshow">
        	<div id="ttr_slideshow_inner">
            <ul>
                <li id="Slide0" class="ttr_slide" data-slideEffect="Fade">
                	<a href="#"></a>
                	<div class="ttr_slideshow_last">
                    	<div class="ttr_slideshowshape01" data-effect="None" data-begintime="0" data-duration="1" data-easing="linear" data-slide="None">
                        	<div class="html_content">
                            	<p style="margin:0.36em 0.36em 1.43em 0.36em;text-align:Center;">
                                	<span style="font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight:700;font-size:3.429em; border:2px solid:#F00">Tuyển sinh đại học bách khoa Hà Nội</span>
                                </p>
                                <p>
                                	<span style="font-family:'PT Sans','Arial';font-size:2.571em;background-color:transparent;">Chú Thích Bla bla</span>
                                </p>
                            </div>
                        </div>
                    </div>
                </li>
                <li id="Slide1" class="ttr_slide" data-slideEffect="Fade">
                    <a href="#"></a>
                    <div class="ttr_slideshow_last">
                        <div class="ttr_slideshowshape11" data-effect="None" data-begintime="0" data-duration="1" data-easing="linear" data-slide="None">
                            <div class="html_content">
                                <p style="margin:0.36em 0.36em 1.43em 0.36em;text-align:Center;">
                                    <span style="font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight:700;font-size:3.429em;color:rgba(30,214,203,1);">Lượng đăng ký xét tuyển</span>
                                 </p>
                                 <p style="text-align:Center;line-height:2.11267605633803;">
                                    <span style="font-family:'PT Sans','Arial';font-size:1.143em;">Muốn gì phải nói </span>
                                </p>
                            </div>
                        </div>
                    </div>
                </li>
                <li id="Slide2" class="ttr_slide" data-slideEffect="Fade">
                    <a href="#"></a>
                    <div class="ttr_slideshow_last">
                        <div class="ttr_slideshowshape21" data-effect="None" data-begintime="0" data-duration="1" data-easing="linear" data-slide="None">
                            <div class="html_content">
                                <p style="text-align:Center;">
                                    <span style="font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight:700;font-size:3.429em;color:rgba(30,214,203,1);">Nắng Bách Khoa</span>
                                </p>
                                <p style="text-align:Center;">
                                    <span style="font-family:'PT Sans','PT Sans';font-size:1.143em;">Hôm qua em đến trường, xe của em ngập nước ý a!!</span>
                                </p>
                            </div>
                        </div>
                    </div>
                </li>
			</ul>
        	</div>
        <div class="ttr_slideshow_in">
			<div class="ttr_slideshow_last">
				<div id="nav"></div>
			</div>
		</div>
	</div>
    <div id="ttr_content_and_sidebar_container">
    	<div class="ttr_Home_html_row0 row">
        	<div class="post_column col-lg-12 col-md-12 col-sm-12 col-xs-12">
            	<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
                <div class="html_content">
                	<p style="margin:0.14em 0em 1.43em 1.43em;text-align:Center;">
                    	<span style="font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight:700;font-size:36px;color:#F00;">Top 20 câu hỏi hay nhất</span>
                    </p>
                </div>
                <div class="Main_question_answer">
                	<?php
					$top_20=0;
					try{
						include'connect.php';
						$sql_select="SELECT * from tb_question ORDER BY rank_view DESC";
						$dl=mysqli_query($connect, $sql_select);
					}catch (PDOException $e){
						die("lỗi" . $e->getMessage());
						}
					while($row = mysqli_fetch_array($dl)){
						if(!empty($row['rep_question'])){
							if($top_20<=20){
								$top_20++;
						?>
						<div id="manaquestion" class="collapse navbar-collapse"  style="border-width: 2px; border-style:solid; border-color:#3C0;border-radius:6%; margin:10px 0 10px; background:rgba(255,255,255,0.9)">
							<div class="question" style=" margin:5px">
								<div class="time-question" style="color:#060"><?php echo htmlspecialchars($row['time_question']) ?></div>
								<div class="main_question">
										<strong style="color:#060">Bạn: </strong>
										<span class="name" style="color:#060"><?php echo htmlspecialchars($row['name_question']) ?></span>
										<span class="address" style="color:#060"><?php echo htmlspecialchars($row['address_question']) ?></span>
										<span style="color:#030"><?php echo htmlspecialchars($row['question']) ?></span>
								</div>
							</div>
							<div id="bt" style="color:#060; text-align:center">Hiện phần trả lời</div>
                            <div id="like_id"><button class="like_btn" data-id="<?php echo $row['id'] ?>">yêu thích <span id="rank<?php echo $row['id'] ?>"><?php echo $row['rank_view'] ?></span></button></div>
							<div class="answer" id="ans" style="margin:20px; display:none">
								<div class="main_answer">
									<p><span style="color:#600"><?php echo htmlspecialchars($row['rep_question']) ?></span></p>
									<?php $type_room= mysqli_query($connect, "SELECT * from tb_room WHERE id='".$row['type_question']."'");
									$row_room=mysqli_fetch_array($type_room)?>
									<span class="answer-user-name" style="color:#060">(<?php echo htmlspecialchars($row_room['name_room']) ?>)</span>
								</div>
							</div>
							
						</div>
						<script>
						document.getElementById("manaquestion").id="h_ana<?php echo $row['id']?>";
						document.getElementById("bt").id="bta<?php echo $row['id']?>";
						document.getElementById("ans").id="b_ana<?php echo $row['id']?>";
						$<?php echo $row['id']?>=1;
						$('#h_ana<?php echo $row['id']?>').click(function(){
							if($<?php echo $row['id']?>==1){
								$('#bta<?php echo $row['id']?>').text('Ẩn phần trả lời');
								$<?php echo $row['id']?>=0;
							}else{
								$('#bta<?php echo $row['id']?>').text('Hiện phần trả lời');
								$<?php echo $row['id']?>=1;
							}	
							$('#b_ana<?php echo $row['id']?>').toggle('slow');
							$(this).toggleClass('green');
							});
						</script>
						<?php 	}else{
							break;
						}
							}
						} ?>
                </div>
                <div style="clear:both;"></div>
                <div class="clearfix visible-lg-block visible-sm-block visible-md-block visible-xs-block"></div>
            </div>
        </div>
		<div class="ttr_Home_html_row2 row" id="new_question">
			<div class="post_column col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ttr_Home_html_column20">
					<div class="html_content">
                    	<p style="margin:0.36em 0.36em 1.43em 0em;text-align:Center;">
                        	<span style="font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight:700;font-size:36px; color:#900">Câu hỏi </span>
                            <span style="font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight:700;font-size:36px;color:#060;">mới</span>
						</p>
                        <p style="margin:0.14em 0em 0em 1.43em;text-align:Center;line-height:1.76056338028169;">
						</p>
                        <?php
		try{
			include'connect.php';
			$sql_select="SELECT * from tb_question ORDER BY time_public DESC";
			$dl=mysqli_query($connect, $sql_select);
		}catch (PDOException $e){
			die("lỗi" . $e->getMessage());
			}
		while($row = mysqli_fetch_array($dl)){
			if(!empty($row['rep_question'])){
			?>
			<div id="manaquestion" style="border-width: 2px; border-style:solid; border-color:#3C0;border-radius:6%; margin:10px 0 10px; background:rgba(255,255,255,0.9)">
				<div class="question" style=" margin:5px">
					<div class="time-question" style="color:#060"><?php echo htmlspecialchars($row['time_question']) ?></div>
					<div class="main_question">
							<strong style="color:#060">Bạn: </strong>
							<span class="name" style="color:#060"><?php echo htmlspecialchars($row['name_question']) ?></span>
							<span class="address" style="color:#060"><?php echo htmlspecialchars($row['address_question']) ?></span>
							<span style="color:#030"><?php echo htmlspecialchars($row['question']) ?></span>
					</div>
				</div>
                <div id="bt" style="color:#060; text-align:center">Hiện phần trả lời</div>
                <div id="like_id"><button class="like_btn" data-id="<?php echo $row['id'] ?>">yêu thích <span id="rank_<?php echo $row['id'] ?>"><?php echo $row['rank_view'] ?></span></button></div>
				<div class="answer" id="ans" style="margin:20px; display:none">
					<div class="main_answer">
						<p><span style="color:#600"><?php echo htmlspecialchars($row['rep_question']) ?></span></p>
                        <?php $type_room= mysqli_query($connect, "SELECT * from tb_room WHERE id='".$row['type_question']."'");
						$row_room=mysqli_fetch_array($type_room)?>
						<span class="answer-user-name" style="color:#060">(<?php echo htmlspecialchars($row_room['name_room']) ?>)</span>
					</div>
				</div>
				
			</div>
			<script>
			document.getElementById("manaquestion").id="h_an<?php echo $row['id']?>";
			document.getElementById("bt").id="bt<?php echo $row['id']?>";
			document.getElementById("ans").id="b_an<?php echo $row['id']?>";
			$<?php echo $row['id']?>=1;
			$('#h_an<?php echo $row['id']?>').click(function(){
				if($<?php echo $row['id']?>==1){
					$('#bt<?php echo $row['id']?>').text('Ẩn phần trả lời');
					$<?php echo $row['id']?>=0;
				}else{
					$('#bt<?php echo $row['id']?>').text('Hiện phần trả lời');
					$<?php echo $row['id']?>=1;
				}	
				$('#b_an<?php echo $row['id']?>').toggle('slow');
				$(this).toggleClass('green');
				});
			</script>
			<?php } 
			} ?>
		<script src="lib/show_question.js"></script>
        
    				</div>
				</div>
			</div>
            <div class="clearfix visible-lg-block visible-sm-block visible-md-block visible-xs-block"></div>
		</div>
		<div class="ttr_Home_html_row3 row">
			<div class="post_column col-lg-6 col-md-12 col-sm-12 col-xs-12">
				<div class="ttr_Home_html_column30">
					<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
					<div class="html_content">
                    	<p>
                        	<span>
                            	<img src="images/bk2017.jpg" style="max-width:521px;max-height:420px;" />
                            </span>
						</p>
					</div>
					<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
					<div style="clear:both;"></div>
				</div>
			</div>
            <div class="clearfix visible-sm-block visible-md-block visible-xs-block"></div>
            <div class="post_column col-lg-6 col-md-12 col-sm-12 col-xs-12">
                <div class="ttr_Home_html_column31">
                    <div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
                    <div class="html_content">
                        <p style="margin:0.14em 0em 0em 1.43em;line-height:1.47042253521127;">
                            <br style="font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-size:1.286em;" />
                        </p>
                        <p style="margin:0.14em 0em 0em 1.43em;line-height:1.47042253521127;">
                            <br style="font-family::Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-size:1.286em;" />
                        </p>
                        <p style="margin:0.14em 0em 0em 1.43em;line-height:1.47042253521127;">
                            <br style="font-family::Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight:700;font-size:1.429em;" />
                        </p>
                        <p style="margin:0.14em 0em 0em 1.43em;line-height:1.47042253521127;">
                            <br style="font-family::Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight:700;font-size:1.429em;" />
                        </p>
                        <p style="margin:0.14em 0em 0em 1.43em;line-height:1.47042253521127;">
                            <span style="font-family::Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight:700;font-size:1.429em;color:#F00;">Trường Đại học Bách Khoa Hà Nội - Hanoi University of Science and Technology (HUST)</span>
                        </p>
                        <p style="margin:0.14em 0em 0em 1.43em;line-height:1.76056338028169;">
                            <span style="font-family:'PT Sans','Arial';color:rgba(52,52,52,1);">Thành lập năm 1956, Trường Đại học Bách Khoa Hà Nội là trường Đại học kỹ thuật đầu tiên và luôn luôn là trường đại học kỹ thuật hàng đầu của Việt Nam. Với truyền thống gần 60 năm xây dựng và phát triển, Trường Đại học Bách Khoa Hà Nội luôn năng động, sáng tạo trong đào tạo, nghiên cứu khoa học và có những đóng góp đáng kể vào sự nghiệp công nghiệp hóa, hiện đại hóa của đất nước.</span>
                        </p>
                        <p style="margin:0.14em 0em 0em 1.43em;line-height:1.47042253521127;">&nbsp;</p>
                        <p style="margin:0.14em 0em 0em 1.43em;line-height:1.47042253521127;">
                            <span>
                                <a HREF="#" target="_self" class="btn btn-lg btn-primary">Đọc tiếp ></a>
                            </span>
                        </p>
                    </div>
                    <div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
                    <div style="clear:both;"></div>
                </div>
            </div>
			<div class="clearfix visible-lg-block visible-sm-block visible-md-block visible-xs-block"></div>
		</div>
        <div class="ttr_Home_html_row5 row">
                <div class="post_column col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
                    <div class="html_content">
                        <p style="margin:0.36em 0.36em 1.43em 0.36em;text-align:Center;">
                            <span style="font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight:700;font-size:1.429em;color:rgba(40,54,61,1);">Danh mục</span>
                        </p>
                    </div>
                    <div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
                    <div style="clear:both;"></div>
                    <div class="post_column col-lg-4 col-md-6 col-sm-6 col-xs-12">
                        <div class="ttr_Home_html_column60">
                            <div class="html_content">
                                <img src="images/101.jpg" width="431" height="382" class="ttr_fill" style="max-width:450px;max-height:250px;" />
                            </div>
                        </div>
                    </div>
                    <div class="post_column col-lg-4 col-md-6 col-sm-6 col-xs-12">
                        <div class="ttr_Home_html_column61">
                                <div class="html_content">
                                        <img src="images/102.jpg" class="ttr_fill" style="max-width:450px;max-height:250px;" />
                                </div>
                        </div>
                     </div>
                    <div class="post_column col-lg-4 col-md-6 col-sm-6 col-xs-12">
                        <div class="ttr_Home_html_column62">
                                <div class="html_content">
                                <img src="images/103.jpg" class="ttr_fill" style="max-width:450px;max-height:250px;" />
                                </div>
                        </div>
                    </div>
                    <div class="post_column col-lg-4 col-md-6 col-sm-6 col-xs-12">
                        <div class="ttr_Home_html_column63">
                            <div class="html_content">
                                    <img src="images/104.jpg" class="ttr_fill" style="max-width:450px;max-height:250px;" />
                            </div>
                        </div>
                    </div>
                    <div class="post_column col-lg-4 col-md-6 col-sm-6 col-xs-12">
                            <div class="ttr_Home_html_column64">
                                <div class="html_content">
                                    <img src="images/105.jpg" class="ttr_fill" style="max-width:450px;max-height:250px;" />
                                        
                                </div>
                            </div>
                    </div>
                    <div class="post_column col-lg-4 col-md-6 col-sm-6 col-xs-12">
                            <div class="ttr_Home_html_column65">
                                <div class="html_content">
                                    <img src="images/106.jpg" class="ttr_fill" style="max-width:450px;max-height:250px;" />
                                </div>
                            </div>
                    </div>
                    </div>
                    <div class="clearfix visible-lg-block visible-sm-block visible-md-block visible-xs-block"></div>
        </div>
        <div class="ttr_Home_html_row1 row" id="from_ques">
            <div class="post_column ol-lg-12 col-md-12 col-sm-12 col-xs-12">
            	<div class="ttr_Home_html_column10">
                    <div class="html_content">
                        <p style="margin:0.36em 0.36em 1.43em 0.36em;text-align:Center;">
                            <span style="font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight:700;font-size:30px;color:#000;">TƯ VẤN </span>
                            <span style="font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight:700;font-size:30px;color:#F0F; border:2px solid:#666">- </span>
                            <span style="font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;font-weight:700;font-size:30px;color:#F00;">LIÊN HỆ</span>
                        </p>
                    </div>
                    <div id="about" class="span4 ol-lg-6 col-md-6 col-sm-6 col-xs-6">
                        <div class="logo">
                            <p><a href="#"><img src="images/logo.png" alt="Tuyển sinh ĐHBK Hà Nội"></a></p>	
                        </div>
                        <div class="ice_contact">
                            <div class="custom">
                                <ul>
                                <li>Số 1 Đại Cồ Việt, Quận Hai Bà Trưng, Hà Nội</li>
                                <li>ĐT: 043.8692104-043.8692008-043.8682305</li>
                                <li>Fax: 043.8683618</li>
                                </ul>
                                <ul>
                                <li>Email:&nbsp;tuyensinhdh@hust.edu.vn</li>
                                </ul>
                            </div>
                            
                        </div>
                        <div id="social_icons">
                            <h3>We Are Social</h3>
                            <ul>
                                <li class="social_facebook">
                                <a target="_blank" rel="tooltip" data-placement="bottom" title="" data-original-title="Like on Facebook" href="http://www.facebook.com/dhbkhanoi"><span>Facebook</span></a>			
                                </li>
                                </ul>
                        </div>
                    </div>
                    <div class="ol-lg-6 col-md-6 col-sm-6 col-xs-6">
                    <div class="letter_question" id="letter_id" style="font-family: 'Pacifico', cursive; color:#b20202;">
                          
                    </div>
                    </div>
                    
                </div>
            </div>
		</div>
		<div style="clear:both"></div>
	</div>
    </div>
    <script>
		var myIndex = 0;
		carousel();
		
		function carousel() {
			var x = document.getElementsByClassName("ttr_slide");
			for (var i = 0; i < x.length; i++) {
			   x[i].style.display = "none";
			}
			myIndex++;
			if (myIndex > x.length) {myIndex = 1}    
			x[myIndex-1].style.display = "block";  
			setTimeout(carousel, 3500);    
			}
		//lấy giá trị 
		var i=0;
		function myFunction_letter(){
			if(i==0){
				document.getElementById('letter_id').className ="mv_letter";
				i=1;
			}else{
				document.getElementById('letter_id').className ="letter_question";
				i=0;
			}
			
		}
		
 	</script>
</body>
</html>
<script>
	$('#letter_id').load("SendQuestions.php");
	$(document).on('click', '#qu_form', function(e){
		e.preventDefault();
            $('#letter_id').load("SendQuestions.php");
	});
	$(document).on('click','#btn_sub',function(e){
		e.preventDefault();
		var m_title=$("#m_title").val();
		var m_content=$("#m_content").val();
		var m_vien=$("#m_vien").val();
		$.ajax({
			url:"SendQuestions.php",
			method:"POST",
			data:{m_title:m_title,m_content:m_content,m_vien:m_vien},
			success:function(data){
				$("#letter_id").html(data);
			}
			});
		
		});
	$(document).on('click','#btn_next',function(e){
		e.preventDefault();
		var a_title=$("#a_title").val();
		var a_content=$("#a_content").val();
		var m_vien=$("#m_vien").val();
		$.ajax({
			url:"form.php",
			method:"POST",
			data:{a_title:a_title,a_content:a_content,m_vien:m_vien},
			success:function(data){
				$("#letter_id").html(data);
			}
			});
		
		});
		$(document).on('click','.like_btn', function(){
			var id=$(this).data("id");
			$.ajax({
				url:"like.php",
				method:"POST",
				data:{id:id},
				success:function(data){
					$("#rank"+id).html(data);
					$("#rank_"+id).html(data);
				}
				});
		});
</script>
