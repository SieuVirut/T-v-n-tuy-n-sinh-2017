<!DOCTYPE html>


<head>
    <meta charset="UTF-8">
    <title>Gửi câu hỏi</title>
</head>
<body>
    <?php
	header('Content-Type: text/html; charset=UTF-8');
    require 'function.php';
    require 'connect.php';

    $noti = "Mời bạn nhập tiêu đề câu hỏi và nội dung câu hỏi !";
    $m_title = "";
    $m_content = "";
	 $a_title = "";
    $a_content = "";
    $m_vien = "CNTT&TT";

    $change_title = "hidden";
    $change_content = "hidden";
    $change_vien = "hidden";
    $change_noti = "hidden";
    $check_question = "submit";
    $flat = true;



    if (isset($_POST['m_title']) && isset($_POST['m_content'])) {

        $m_title = $_POST['m_title'];
        $m_content = $_POST['m_content'];
        $m_vien = $_POST['m_vien'];

        $noti = null;


        // Dinh dang lai Tieu de va Noi Dung cau hoi. 
        $a_title = formatString($m_title);
        $a_content = formatString($m_content);

        // Kiem tra do dai cua title va content
        if (checkLength($a_title, 100, 10)) {
            $noti .= "Tiêu đề câu hỏi phải >10 kí tự và <100 kí tự !";
            $flat = false;
        }
        if (checkLength($a_content, 500, 20)) {
            $noti .= "Nội dung câu hỏi phải từ 20 đến 500 kí tự !";
            $flat = false;
        }
        if ($flat) {
            $noti = "Câu hỏi đã  ";


            // Bo loc tu vung va chuan hoa SEO 
            $sql_select = "SELECT * FROM Vocabulary";
            $resulf = $connect->query($sql_select);

            if ($resulf && $resulf->num_rows > 0) {

                while ($row = $resulf->fetch_assoc()) {
                    $a_title = str_replace($row['Words'], $row['NewWords'], $a_title);
                    $a_content = str_replace($row['Words'], $row['NewWords'], $a_content);
                }
            }
            // Kiểm tra sự thay đổi nếu có và thông báo 
            if ($m_title == $a_title && $m_content == $a_content) {
                $noti .= " đc giữ nguyên ! ";
                // $check_question = "hidden";
                $change_noti = "submit";
                $change_content = "text";
                $change_title = "text";
            } else {
                // $check_question = "hidden";
                //  $change_noti = "submit";
                $change_vien = "text";
                $change_content = "text";
                $change_title = "text";
                $noti .= " đc thay đổi phần : ";
                $a_vien = "";

                if ($m_title != $a_title) {
                    $noti .= "Tiêu đề ";
                }
                if ($m_content != $a_content) {
                    $noti .= "Câu hỏi ";
                }
            }
        }




        // Kiem tra su ton tai cua cau hoi .
		$noti .= "<br>";
    $arraypercent = array();
    $soluong = 15;
    $maxpercent = 0;
    $kodchoi = 95;
    $dcphephoi = 80;
    $num = 1;
    if ($flat) {

            $change_title = "text";
            $change_content = "text";

            // Tinh gia tri cua bien auto Vien .
            $a_vien = "CNTT&TT";

            $sql_check = "SELECT * FROM `tb_question` WHERE 1";
            $resulf = $connect->query($sql_check);


            if ($resulf && $resulf->num_rows > 0) {

                while ($row = $resulf->fetch_assoc()) {

                    // So sanh do tuong quan giua tieu de
                    $title = $row['title'];
                    $percent_a = comparion($a_title, $title);

                    // So sanh do tuong quan giua cau hoi
                    $question = $row['question'];
                    $percent_b = comparion($a_content, $question);

                    $percent = $percent_a / 2 + $percent_b / 2;
                    // echo $percent . " <br> ";
                    // Tao mang dong luu cac gia tri tuong quan nhat va ID cua cau hoi tuong quan nhat. 

                    $arraypercent[$row['id']] = $percent;

                    // Sap xep theo gia tri tuong quan tu cao xuong thap
                    arsort($arraypercent);

                    if (count($arraypercent) > $soluong) {
                        array_pop($arraypercent);
                    }
                    $maxpercent = ($percent > $maxpercent) ? $percent : $maxpercent;
                }

                if ($maxpercent >= $kodchoi) {
                    $noti .= "Mời bạn xem qua câu hỏi tương tự đã được trả lời. <br> ";
                    foreach ($arraypercent as $key => $value) {
                        if ($arraypercent[$key] > $kodchoi) {
                            $select = "SELECT * FROM `tb_question` WHERE id = '$key' ";
                            $resulf = $connect->query($select);

                            while ($row = $resulf->fetch_assoc()) {
                                $noti .= "<h4> Câu " . $num . " : </h4>";
                                $noti .= "Câu này giống tới " . (int) $arraypercent[$key] . " % câu hỏi mà bạn " . $row['name_question'] . " hỏi, chúng tôi đã trả lời !";
                                $noti .= " <h3>Tiêu đề : <a href='#' >" . $row['title'] . "</a></h3>";
                                $noti .= "Nội dung: " . $row['question'] . "<hr>";
                                $num ++;
                            }
                        }
                    }
                } elseif ($maxpercent > $dcphephoi) {
                    $noti .= "Mời bạn xem qua câu hỏi tương tự đã được trả lời. <br> ";
                    foreach ($arraypercent as $key => $value) {
                        if ($arraypercent[$key] > $dcphephoi) {
                            $select = "SELECT * FROM `tb_question` WHERE id = '$key' ";
                            $resulf = $connect->query($select);

                            while ($row = $resulf->fetch_assoc()) {
                                $noti .= "<h4> Câu " . $num . " : </h4>";
                                $noti .= "Câu này giống tới " . (int) $arraypercent[$key] . " % câu hỏi mà bạn " . $row['name_question'] . " hỏi, chúng tôi đã trả lời !";
                                $noti .= " <h3>Tiêu đề : <a href='#' >" . $row['title'] . "</a></h3>";
                                $noti .= "Nội dung: " . $row['question'] . "<hr>";
                                $num ++;
                            }
                        }
                    }

                    $noti .= "Câu hỏi của bạn : ";
                    $noti .= " <h3>Tiêu đề : " . $a_title . " </h3>";
                    $noti .= "<b>Nội dung: " . $a_content . "</b><br>";
                    $noti .= "<br> Bạn có chắc rằng mình muốn tiếp tục gửi câu hỏi này ko?";
                    $noti .= '<br><button id="btn_next" > Có,Tiếp tục </button><button id="btn_exit" > Thôi,cảm ơn. </button>';
                } else {
                    $noti .= "Câu hỏi của bạn : ";
                    $noti .= " <h3>Tiêu đề : " . $a_title . " </h3>";
                    $noti .= "<b>Nội dung: " . $a_content . "</b><br>";
                    $noti .= "<br> Bạn có chắc rằng mình muốn tiếp tục gửi câu hỏi này ko?";
                    $noti .= '<br><button id="btn_next" > Có,Tiếp tục </button><button id="btn_exit" > Thôi,cảm ơn. </button>';
                }

                $noti .= "<hr>";
            }
        }
    }
    ?>
        <textarea type="text" name="m_title" id="m_title" ><?php echo $m_title ?></textarea>
        <textarea type="text" name="m_content" id="m_content" ><?php echo $m_content ?></textarea>
        <select name="m_vien" id="m_vien"> 
            <?php
                                        try{
												include'connect.php';
												$sql_select_room="SELECT * from tb_room ORDER BY id";
												$dl_room=mysqli_query($connect, $sql_select_room);
											}catch (PDOException $e){
												die("lỗi" . $e->getMessage());
												}
											while($row = mysqli_fetch_array($dl_room)){
												?>
                                      	<option value="<?php echo htmlspecialchars($row['id'])?>"><?php echo $row['name_room']?></option>
                                        <?php }?>
                                        <option selected="on"><?php echo $m_vien ?></option>
        </select>




        <input id="btn_sub" type="button" value="Check Question"> 

        <br>
        <input type="<?php echo $change_title ?>" name="a_title" id="a_title" value=" <?php echo htmlspecialchars($a_title) ?>" readonly>
        <input type="<?php echo $change_content ?>" name="a_content" id="a_content" value="<?php echo htmlspecialchars($a_content) ?>" readonly>

    <?php
    
	echo $noti;
    ?>


</body>
</html>