-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 27, 2017 at 12:05 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u345307853_ts`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id` int(3) NOT NULL,
  `name_admin` varchar(30) NOT NULL,
  `password_admin` varchar(250) NOT NULL,
  `email_admin` varchar(250) NOT NULL,
  `fullname_admin` varchar(250) NOT NULL,
  `level` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`id`, `name_admin`, `password_admin`, `email_admin`, `fullname_admin`, `level`) VALUES
(1, 'admin', '81dc9bdb52d04dc20036dbd8313ed055', 'admin@hust.edu.vn', 'A đê min', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_question`
--

CREATE TABLE `tb_question` (
  `id` int(5) NOT NULL,
  `name_question` varchar(64) CHARACTER SET utf8 NOT NULL,
  `address_question` varchar(100) CHARACTER SET utf8 NOT NULL,
  `phone_question` int(13) NOT NULL,
  `email_question` varchar(100) CHARACTER SET utf8 NOT NULL,
  `type_question` varchar(64) CHARACTER SET utf8 NOT NULL,
  `time_question` datetime DEFAULT NULL,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `question` text COLLATE utf8_unicode_ci,
  `rep_question` text CHARACTER SET utf8,
  `id_user` varchar(64) CHARACTER SET utf8 DEFAULT NULL,
  `time_rep_question` datetime DEFAULT NULL,
  `time_public` datetime DEFAULT NULL,
  `rank_view` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_question`
--

INSERT INTO `tb_question` (`id`, `name_question`, `address_question`, `phone_question`, `email_question`, `type_question`, `time_question`, `title`, `question`, `rep_question`, `id_user`, `time_rep_question`, `time_public`, `rank_view`) VALUES
(120, 'Phan Quốc Bảo', '(Nam Đàn 1 - Nghệ An)', 123456, 'congpham@gmail.com', '9', '2017-07-17 09:55:45', '', 'Kính thưa thầy có.  E thi  được 26,95( toán 8.2; lý 9.5; hoá 9.25) E có được làm tròn 27 điểm k a. Và 1 điểm ưu tiên KV. Tống gần 28 điểm. E đăng ki vào DHBK. NV1 CNTT; NV2 Điều khiến và tự đông hoá. Vậy xin hỏi E có cần phải đăng kí thêm NV nữa k a. E xin thầy cô tư vân giúp E. E cảm ơn.', NULL, NULL, NULL, NULL, 0),
(121, 'minh', '(ngô thì nhậm )', 123456, 'congpham@gmail.com', '14', '2017-07-16 13:03:40', '', 'các thầy cho em hỏi sự khác biệt giữa ngành Kỹ thuật điều khiển và tự động hóa và Công nghệ kỹ thuật điều khiển và tự động hóa (CN) với ạ, em cảm ơn ạ ', NULL, NULL, NULL, NULL, 0),
(122, 'tạ hoàng', '(nguyễn trãi)', 123456, 'congpham@gmail.com', '2', '2017-07-15 21:23:53', '', 'thầy ơi cho em hỏi, CTTT cơ điện tử gồm những gì và đào tạo như thế nào ạ? Em cảm ơn ạ!', 'VIkdsajflsdkafdsafdsafdsffsdafsdafds dfsafdsafsad', '3', '2017-08-24 10:41:19', '2017-08-24 11:00:00', 86705),
(123, 'tạ hiếu', '(lê quý đôn - đống đa - hà nội)', 123456, 'congpham@gmail.com', '10', '2017-07-15 21:22:19', '', 'Thầy cô cho em hỏi ạ, CTTT Cơ Điện tử , TA chuyên nghiệp quốc tế, TA KHKT công nghệ thì có gì khác nhau và đào tạo như thế nào ạ?\n', NULL, NULL, NULL, NULL, NULL),
(124, 'Nguyễn phương trang', '(Phú Xuyên A)', 123456, 'congpham@gmail.com', '15', '2017-07-15 21:21:10', '', 'Chào thầy cô, em có câu hỏi:\nEm học ban D, thích học về xã hội. Em không thích mấy vấn đề về kĩ thuật. Vậy có nên học tiếng anh KHKT và CN của trường k ạ?  Và chuyên ngành đào tạo của ngành này là như thế nào ạ? E có phải học về máy móc hay định lý gì k ạ? Cơ hội nghề nghiệp của ngành này thế nào ạ? \nEm cảm ơn!  ', NULL, NULL, NULL, NULL, NULL),
(125, 'Nguyễn Thị Mai Phương', '(Trường THPT Đan Phượng)', 123456, 'congpham@gmail.com', '6', '2017-07-15 21:19:49', '', 'Em muốn tìm hiểu thêm về ngành Tiếng Anh Khoa học kĩ thuật, về chương trình đào tạo cũng như cơ hội việc làm và học phí ạ. Và liệu điểm chuẩn của ngành năm nay sẽ rơi vào khoảng bn ạ? Em cảm ơn!', NULL, NULL, NULL, NULL, NULL),
(126, 'Trần Nguyễn Hồng Lam', '(thpt lê hồng phong)', 123456, 'congpham@gmail.com', '10', '2017-07-15 21:18:14', '', 'cho em hỏi cơ hội làm việc của ngành ngôn ngữ anh quốc tế, ngành này có khác gì với ngành ngôn ngữ anh kĩ thuật', NULL, NULL, NULL, NULL, NULL),
(127, 'Hà Anh', '(thpt cao bá quát )', 123456, 'congpham@gmail.com', '4', '2017-07-15 21:17:57', '', 'e chào thầy cô  ạ, e có 1 số câu hỏi muốn hỏi thầy cô về khoa TA2 và TA1 của trường ạ :\n1. TA1 và TA2 có yêu cầu ielts hay chứng chỉ ngoại ngữ gì k ạ ?\n2. chương trình đào tạo của TA2 và TA1 khác nhau ra sao ạ ? TA2 có học tiếng anh kĩ thuật k ạ ?\n3. Theo thầy cô thì TA1 hay TA2 có cơ hội có việc làm cao hơn ạ ? \nem cảm ơn thầy cô ạ !', 'Bố mày đéo thsich trả lời m okay dskfjfldkjlfjdsa', '4', '2017-09-21 03:54:52', '2017-09-22 00:00:00', 48851),
(128, 'phạm hà', '(B DUY TIÊN)', 123456, 'congpham@gmail.com', '12', '2017-07-15 21:13:41', '', 'thưa thầy cô, các khoa chương trình tiên tiến như tt21,tt22..  có xét tiêu chuẩn đầu vào tiếng anh như năm 2016 không ạ', NULL, NULL, NULL, NULL, NULL),
(129, 'nguyễn ngọc tiến ', '(Nguyễn Bỉnh Khiêm)', 123456, 'congpham@gmail.com', '4', '2017-07-14 15:45:20', '', 'cho em hỏi khoa điện tử viễn thông hệ quốc tế của Đức thì điểm xét tuyển khối nào ạ???', 'Chào em! Khoa điện tử được sét tuyển theo khối A và A1.', '2', '2017-09-25 16:04:56', '2017-09-25 17:00:00', NULL),
(130, 'Lê Quý Đôn', '(Lê Quý Đôn)', 123456, 'congpham@gmail.com', '15', '2017-07-14 14:03:15', '', 'Cho e hỏi nếu được tuyển thẳng vào trường có nhất định phải học ở trường này k ạ?', NULL, NULL, NULL, NULL, NULL),
(131, 'Nguyễn Tú', '(THPT Đan Phượng)', 123456, 'congpham@gmail.com', '13', '2017-07-14 13:59:55', '', 'thầy cô cho em hỏi là vs BKHN thì điểm toán ( ngành có môn chinh) có làm tròn đến 0.5 ko ạ?\nvà theo công thức tính điểm, mới thì em được 24,125 thì có được làm tròn đến 24,25 ko ạ?\nEm cảm ơn.', NULL, NULL, NULL, NULL, NULL),
(132, 'Nguyễn Đình Nam', '(Trường THPT Cổ Loa)', 123456, 'congpham@gmail.com', '13', '2017-07-14 13:57:09', '', 'Kính gửi quý thầy cô, với số điểm hiện tại của em là 24,5 thì em đã trượt các nguyện vọng trước của mình. Bây giờ em muốn chuyển nguyện vọng sang Trường Đại Học Bách Khoa Hà Nội (trước đó em không đăng ký nguyện vọng Bách Khoa) thì em phải đến trường xin chuyển hay em có thể chuyển nguyện vọng qua mạng ạ. Em xin chân thành cảm ơn.', NULL, NULL, NULL, NULL, NULL),
(133, 'Đỗ Thảo Linh', '(Việt Nam-Ba Lan)', 123456, 'congpham@gmail.com', '10', '2017-07-13 16:10:35', '', 'Nếu trượt nguyện vọng 1 của mình e có được trườg em đăng kí nghyện vọng 2 nhận xét tuyển và mức điểm xét tuyển của nguyện vọng 2 có bị tăng lên không ạ', NULL, NULL, NULL, NULL, NULL),
(134, 'Nguyễn Thùy An', '(THPT Quỳnh Lưu 1)', 123456, 'congpham@gmail.com', '16', '2017-07-13 16:07:46', '', 'Em chào thầy cô và anh chị ạ. Kết quả thi đại học của e vừa rồi là 8,08 ạ. Điểm toán e là 9 ạ. E trước đăng kí nguyện vọng 1 vào ngành KT31 ạ. E xin các thầy cô tư vấn là liệu e có khả năng đậu vào ngành ấy của trường đại học Bách Khoa Hà Nội ko ạ? E xin chân thành cảm ơn ạ.', NULL, NULL, NULL, NULL, NULL),
(135, 'Hoàng Nam Tiến', '(THPT Hàm Rồng)', 123456, 'congpham@gmail.com', '8', '2017-07-13 14:53:27', '', 'thầy cô cho em hỏi năm nay 23   0,5 ( điểm vùng) và toán được 8,4 thì liệu có đỗ được KT11 ko ạ?', NULL, NULL, NULL, NULL, NULL),
(136, 'lê thị ngọc hà', '(thpt pd)', 123456, 'congpham@gmail.com', '16', '2017-07-13 14:29:34', '', 'E dk khoang 26.5 có đỗ dk kt 31 k', NULL, NULL, NULL, NULL, NULL),
(137, 'Trần Quang Hải', '(THPT Bắc Sơn)', 123456, 'congpham@gmail.com', '9', '2017-07-13 14:24:34', '', 'Kính chào quý Thầy (Cô). \r\nEm hiện đã có kết quả thi THPT 2007 khối A1: Toán 8,6; Lý 5,5 ; Anh 8,4. Khu vực ưu tiên nơi em học được cộng 1,5 điểm. Với kết quả đó, em có cơ hội trúng tuyển vào khoa nào của trường a? ', NULL, NULL, NULL, NULL, NULL),
(138, 'Đỗ Thảo Linh', '(Việt Nam-Ba Lan)', 123456, 'congpham@gmail.com', '5', '2017-07-13 14:22:28', '', 'E đăng kí 3 NV nếu trúng cả 3 e có thể nộp hồ sơ vào NV 2 hoặc 3 mà bỏ qua NV1 không ạ?', NULL, NULL, NULL, NULL, NULL),
(139, 'Hoàng Minh Châu', '(Thpt chuyên ngoại ngữ đại học quốc gia)', 123456, 'congpham@gmail.com', '12', '2017-07-13 14:20:23', '', 'Con nhà tôi thi được 24 điểm khối A1 và 25,5 điểm khối D thì có thể dăng ký vào khoa nào của trường?', NULL, NULL, NULL, NULL, NULL),
(140, 'Nguyễn quang Anh', '(Nguyễn Gia Thiều)', 123456, 'congpham@gmail.com', '10', '2017-07-13 14:18:32', '', 'Thưa thầy nếu em đăng ký NV1 là KT13 nhưng bây giờ  điểm thi  em đạt cao hơn em muôn thay đổi NV sang KT21 thì em có cơ hội đỗ hơn các ban đăng ký KT21 ngay từ đầu ko ạ.', NULL, NULL, NULL, NULL, NULL),
(141, 'vũ công anh', '(thpt Trí Đức - Hà Nội)', 123456, 'congpham@gmail.com', '5', '2017-07-13 14:10:30', '', 'Thầy cô cho em xin hỏi, điểm thi của em khối AO1 là: Toán 8, lý 6, Anh 6,25 Tổng cộng là 20,25 điểm, em đăng ký nguyện vọng KT22 như vậy em có đủ điểm để vào trường không ạ? em xin cảm ơn Thầy cô ạ ', NULL, NULL, NULL, NULL, NULL),
(142, 'Lê Vĩnh Phúc', '(Thăng long)', 123456, 'congpham@gmail.com', '5', '2017-07-13 14:07:03', '', 'Em thi đựơc 21.8 điểm liệu em có đỗ được CTTT công nghệ thông tin hoặc Cơ điện tử Nagaoka nhật bản không ạ ?', NULL, NULL, NULL, NULL, NULL),
(143, 'Phạm Hà Linh', '(Nguyễn Du)', 123456, 'congpham@gmail.com', '7', '2017-07-13 14:04:14', '', 'Chao thay co em co cau hoi : Khi nào thì cần nộp hồ sơ xét tuyển ạ . Và hồ dơ bao gồm những gì ạ . E c.ơn', 'ỪA E CỨ NÓIFDSKLFJ SDFJSDLKJFLKJDSLJFLKADSJFKLSDJ', '7', '2017-08-31 13:02:20', '2017-08-31 22:00:00', 49873),
(144, 'Phạm Văn Đắc', '(Trường THPT Bình Lục A)', 123456, 'congpham@gmail.com', '8', '2017-07-13 14:02:02', '', 'Các thầy cô cho em hỏi .Năm nay nhà trường xét tuyển nguyện vọng như thế nào ạ .Các nguyện vọng ưu tiên từ trên xuống hay là mức độ ưu tiên là như nhau .Giả sử em được 27 điểm và em đỗ tất các khoa của trường thì em có quyền  được chọn bất kỳ nhóm ngành mình đã đăng kí hay là theo thứ tự ưu tiên từ trên xuống ạ .Em cảm ơn ', NULL, NULL, NULL, NULL, NULL),
(145, 'NGUYỄN THỊ PHƯƠNG', '(NGUYỄN ĐỨC THUẬN)', 123456, 'congpham@gmail.com', '3', '2017-07-13 10:58:58', '', 'Cho em hỏi chương trình tiên tiến của trường như điện -điện tử ,  cơ điện tử ngoài xét điểm trúng tuyển đại học ra có xét thêm tiêu chí phị nào không ạ ? ví dụ như điểm thi môn Tiếng Anh .', NULL, NULL, NULL, NULL, NULL),
(146, 'Le thanh hiền', '(Thpt uông bí)', 123456, 'congpham@gmail.com', '2', '2017-07-13 10:55:53', '', 'Cho e hỏi ngành công nghệ thông tin và nghành điện tử viễn thông bách khoa có bao nhieu hs dăng ký ty le 1chọi may e dc 25.6điên da cộng 0,5 diem khu vuc toan e dc8.6 vay có len dăng ky 2 nghành do o trương  o a', 'VIkdsajflsdkafdsafdsafdsffsdafsdafds dfsafdsafsad f', '3', '2017-08-24 10:41:19', '2017-08-24 11:00:00', 62714),
(147, 'Đỗ thu hoà', '(Chuyên biên hoà)', 123456, 'congpham@gmail.com', '4', '2017-07-13 10:52:05', '', 'Em đươc 27 điểm của 3 môn toán, lý , hóa  trong kỳ th tốt nghiệp ptth năm 2017. Nếu chọn bách khoa thí nên chọn khoa nào?', NULL, NULL, NULL, NULL, NULL),
(148, 'Nguyễn Tấn DŨng', '(THPT Đông Triều)', 123456, 'congpham@gmail.com', '11', '2017-07-13 10:48:57', '', 'E thi đươc 20,55 0,5 (điểm vùng) có cơ hội đỗ ngành công nghệ thông tin tại trường không ạ. Mong nhận được câu trả lời sớm từ tổ tư vấn.Em cảm ơn', NULL, NULL, NULL, NULL, NULL),
(149, 'Đặng Văn Đức', '(Nam Đông Quan)', 123456, 'congpham@gmail.com', '16', '2017-07-13 10:45:27', '', '-Cho em hỏi năm nay trường xét tuyển theo cách tính điểm như nào ạ\n-Em được ttỏng 3 môn toán lý hóa là 26,4 và thêm 1 điểm khu vực nữa thì liệu sẽ vào được các ngành nào trong 3 ngành\n1. Công nghệ thông tin\n2. Điện - Điều khiển và tự động hóa\n3. Cơ điện tử\nEm xin cảm ơn ạ!', NULL, NULL, NULL, NULL, NULL),
(150, 'Hoàng Thành Trung', '(Xuân Hòa)', 123456, 'congpham@gmail.com', '8', '2017-07-13 10:44:21', '', 'Chào thầy cô ạ, cho em hỏi là điều kiện để đăng kí vào lớp tài năng là gì ạ vào bao giờ thì bắt đầu xét điều kiện để học lớp tài năng ạ? Em cảm ơn', NULL, NULL, NULL, NULL, NULL),
(151, 'Nguyễn Khắc Trung', '(Trường THPT Nguyễn Trãi - Thường Tín)', 123456, 'congpham@gmail.com', '10', '2017-07-13 09:44:29', '', 'Em được Toán 8.00  Lý 7.00 Hóa 6,25 mong thầy cô tư vấn cho em đủ điều kiện vào ngành nào của trường', NULL, NULL, NULL, NULL, NULL),
(152, 'Trần diệu tân', '(Uông bí)', 123456, 'congpham@gmail.com', '8', '2017-07-13 09:43:27', '', 'Thưa nhà trường em vừa thi được 9,2 toán,6,75 lí, 7 hoá. Thì liệu em có đỗ trường mình không ạ? Nếu đỗ thì em có thể sẽ đỗ được khoa gì ạ?', NULL, NULL, NULL, NULL, NULL),
(153, 'Nguyễn Mạnh An', '(THPT Văn Giang)', 123456, 'congpham@gmail.com', '6', '2017-07-13 09:42:31', '', 'Em muốn hỏi là\" em vừa thiTHPT quốc gia 2017 va được 9 toán 7.25 hóa 7.75 lí thì nên học ngành nào la tốt nhất ạ\" em xin chân thành cảm ơn', NULL, NULL, NULL, NULL, NULL),
(154, 'ngô cẩm tú', '(hữu nghị t78)', 123456, 'congpham@gmail.com', '13', '2017-07-13 09:42:19', '', 'trường đại học bách khoa hà nội có được cộng điểm ưu tiên khu vực , dân tộc không?', NULL, NULL, NULL, NULL, NULL),
(155, 'Nguyễn Trung Hiếu', '(THPT Thanh Oai B)', 123456, 'congpham@gmail.com', '2', '2017-07-13 09:39:35', '', 'Cho e hỏi là năm nay trường xét điểm khối A và A1 riêng hay chung ạ? Hay là khi công bố điểm là 1 số X thì tất cả những ai A và A1 cao điểm hơn X đều đỗ ạ? e đang ví dụ là ngành đó lấy cả A và A1', 'greeefsfwerVIkdsajflsdkafdsafdsafdsffsdafsdafds dfsafdsafsad ', '3', '2017-08-24 10:41:19', '2017-08-24 11:00:00', 72874),
(156, 'Hoàng Văn Hải', '(Trường THPT Hoành Bồ, Quảng Ninh)', 123456, 'congpham@gmail.com', '15', '2017-07-13 09:38:36', '', 'Em là thí sinh đã tốt nghiệp THPT năm 2015. Năm nay, em muốn đăng ký xét tuyển vào trường thì phải làm thế nào ạ? Em có phải đăng ký kỳ thi quốc gia cùng thí sinh năm 2017 không ạ? Và hình thức nộp hồ sơ với các thí sinh tự do như em sẽ cụ thể như thế nào ạ? \r\nEm cảm ơn các thầy cô ạ.', NULL, NULL, NULL, NULL, NULL),
(157, 'Đào Anh Ngọc', '(Trường THPT NInh Giang)', 123456, 'congpham@gmail.com', '12', '2017-07-13 09:37:13', '', 'em thi toán đc 9, lí 6.72, hóa 8.75 , đc cộng 1 điểm khu vực, mọi người tư vấn giúp em xem em có thể vào đc khoa nào của trường với , em cảm ơn.', NULL, NULL, NULL, NULL, NULL),
(158, 'Nguyễn Thanh Tùng', '(Trường THPT Đoan Hùng)', 123456, 'congpham@gmail.com', '15', '2017-07-13 09:30:49', '', 'Trong kỳ thi THPT Quốc gia năm 2017 em được Toán 7, Lí 7,5: Hóa 8,25. Tổng điểm 22,75 thuộc KV1. Vậy em có cơ hội đỗ ngành nào của trường Bách Khoa không?', NULL, NULL, NULL, NULL, NULL),
(159, 'Vũ Ngọc Anh', '(THPT Chuyên Vĩnh Phúc)', 123456, 'congpham@gmail.com', '10', '2017-07-13 09:29:44', '', 'trong đợt thi THPT QG 2017 vừa rồi em làm bài thi và xét theo khối A1 đc 27.75 điểm tổng theo các tính trên FB trường thông báo. Trong đó có 9.2 toán 9.2 tiếng anh và 8.75 toán với 0.5 điểm KV1 nữa thì liệu em có cơ hội đỗ CNTT của trường không và em biết nếu không có khả năng đỗ thì trường có những khoa/nhóm ngành nào hợp với điểm của em. Em muốn chỉnh sửa hồ sơ xét tuyến để có lợi cho mình nhất.\n-cảm ơn thầy/cô vì đã đọc câu hỏi của em.', NULL, NULL, NULL, NULL, NULL),
(160, 'Nguyễn Bình Minh', '(THPT Lê Lợi)', 123456, 'congpham@gmail.com', '4', '2017-07-13 09:27:02', '', 'Em thi toán 7,4  lý 7,5 hóa 8,75=23,65 điểm có cơ hội vào trường nghành ( QT11) không nếu không thì có được đăng ký vào nguyện vọng khác của trường không', NULL, NULL, NULL, NULL, NULL),
(161, 'Trịnh Trường Giang', '(Chuyên Bắc Nịnh)', 123456, 'congpham@gmail.com', '8', '2017-07-13 09:21:25', '', 'Em thi đạt 22.75 đăng ký vào trường đại học Bách khoa cơ hội đỗ là bao nhiêu % ạ?', NULL, NULL, NULL, NULL, NULL),
(162, 'Nguyễn Văn Nam', '(Nguyễn Trãi)', 123456, 'congpham@gmail.com', '7', '2017-07-12 22:12:16', '', 'Em đang phân vân giữa Kĩ thuật cơ điện tử và Kĩ thuật Điều khiển và Tự động hóa. Mong thầy cô đưa ra một số điểm khác nhau giữa 2 ngành trên để em có sự lựa chọn. Em xin cảm ơn. ', NULL, NULL, NULL, NULL, NULL),
(163, 'Phạm Văn Hùng', '(Công Nghiệp - Hòa Bình)', 123456, 'congpham@gmail.com', '10', '2017-07-12 22:03:42', '', 'Kính chào thầy:\nEm muốn hỏi Chương trình tiên tiến Điện - điện tử, điện tử truyền thông sau khi học hết 4 năm em muốn học 01 năm ở nước ngoài lấy bằng thạc sỹ thì cần đủ những điều kiện nào?\nEm trân trọng cảm ơn.', NULL, NULL, NULL, NULL, NULL),
(164, 'Đỗ Hoàng Việt', '(THPT Văn Lâm)', 123456, 'congpham@gmail.com', '7', '2017-07-12 22:02:44', '', 'cho e hỏi là muốn vào hệ kĩ sư tài năng thì khi làm bài để vào lớp đó thì bài thi nó như thế nào ạ. có giống bài thi THPTQG ko ạ', NULL, NULL, NULL, NULL, NULL),
(165, 'Nguyễn Minh Hiếu', '(THPT chuyên Lam Sơn, Thanh Hóa)', 123456, 'congpham@gmail.com', '9', '2017-07-12 22:01:45', '', 'Năm nay e đang học lớp 11, e có nguyện vọng sang năm sẽ đăng ký ngành kỹ thuật phần mềm thuộc nhóm ngành KT22, em thấy nhóm ngành này có một mức điểm chuẩn chung, vậy khi đó xét điều kiện nào để em được học ngành mà em mong muốn và điều kiện để được học lớp kỹ sư tài năng của ngành này như thế nào ạ. Em cảm ơn thầy cô.', NULL, NULL, NULL, NULL, NULL),
(166, 'Nguyễn Tuấn Sơn', '(THPT Nguyễn Bỉnh Kihiêm)', 123456, 'congpham@gmail.com', '10', '2017-07-12 22:00:51', '', 'Em chào thầy cô\nEm có câu hỏi là e đăng kí NV1 là ngành CTTT điện- điều khiển và tự động hoá của Bách Khoa. Giả dụ e k đủ để vào và e xuống NV2 là Đại học Điện Lực, trong trường hợp NV1 xét bổ sung thì e có dk quay lại k ạ ?. e cảm ơn', NULL, NULL, NULL, NULL, NULL),
(167, 'Lê Hồng Minh', '(Trường THPT Chuyên KHTN - ĐHQG Hà Nội)', 123456, 'congpham@gmail.com', '14', '2017-07-12 22:00:06', '', 'Hiện tại e đang đăng ký mã ngành xét tuyển vào trường là KT24. Trường hợp e muốn đăng ký học chương trình tiến tiến của nhóm ngành - mã TT24 thì e có phải thay đổi đăng ký nguyện vọng luôn trong giai đoạn 15/07-22/07/2017 (theo quy định của Bộ GD-ĐT) hay không? Hay khi đăng ký nhập học e vẫn có thể đăng ký sang mã ngành TT24 hoặc các chương trình tiến tiến, CLC khác của Trường ạ?\nEm xin cảm ơn.', NULL, NULL, NULL, NULL, NULL),
(168, 'Lê Đăng Huy ', '(Lê Hồng Phong )', 123456, 'congpham@gmail.com', '3', '2017-07-12 21:59:38', '', 'Thầy cô cho em hỏi, nếu như số học sinh tuyển thẳng vào lớp tài năng của trường vượt quá chỉ tiêu thì dựa vào cơ sở nào để được tuyển ạ? ', NULL, NULL, NULL, NULL, NULL),
(169, 'Nguyễn Việt Linh', '(Đống Đa)', 123456, 'congpham@gmail.com', '7', '2017-07-12 21:58:45', '', 'Tuyển sinh hệ cử nhân khoa cntt cần những điều kiện gì ạ ? học phí bao nhiêu ?\nHọc phí ngành QT32 và TT22 là bao nhiêu ạ ?', NULL, NULL, NULL, NULL, NULL),
(170, 'Nguyễn Tiến Quang', '(THPT Việt Yên Số 1)', 123456, 'congpham@gmail.com', '6', '2017-07-12 21:55:10', '', 'Chào thầy cố, em đăng kí nguyện vọng chương trình tiên tiến của ngành cơ điện tử (TT11) nếu không đỗ nguyện vọng này thì có được học chường trình bình thường của ngành cơ điện tử (KT11) không ? hay phải đăng kí cả hai nhóm ngành của cơ điện tử, và trương trình tiên tiến có yêu cầu đâu vào tiếng anh không ?. Em cảm ơn.', NULL, NULL, NULL, NULL, NULL),
(171, 'Trần Đình Đức', '(Trường THPT Quang Trung)', 123456, 'congpham@gmail.com', '10', '2017-07-12 21:54:34', '', 'thầy cô cho em hỏi về lớp KSTN của nhà trường.em muốn biết về giới hạn chương trình thi của KSTN', NULL, NULL, NULL, NULL, NULL),
(172, 'Đặng Thị Quỳnh Hương', '(THPT Xuân Hòa)', 123456, 'congpham@gmail.com', '6', '2017-07-12 21:50:05', '', 'Em chào các thầy cô, theo em được một số anh chị khóa trước của trường tư vấn thì năm nay các sinh viên học lớp kỹ sư tài năng của trường sẽ không được tự đăng ký môn học mà sẽ được nhà trường đăng ký, và như vậy quá trình học tập sẽ kéo dài 5 năm, thông tin này có đúng không ạ ? Và nếu đúng thì có cách nào để rút ngắn thời gian học với chương trình này không ạ ?\nEm hy vọng sẽ sớm nhận được phản hồi từ thầy cô, em cảm ơn thầy cô ạ.', NULL, NULL, NULL, NULL, NULL),
(173, 'Vũ Thị Quỳnh Trang ', '(THPT Cao Bá Quát- Gia Lâm)', 123456, 'congpham@gmail.com', '3', '2017-07-12 21:47:39', '', 'Nhà trường có thể giải đáp thắc mắc giúp e: nếu e đăng kí học TT24 và sau 1 thời gian hojc    Tập e muốn chuyến sang KT24 và ngược lại liệu có được không ạ ? Và chương trình học của KT24 và TT24 cái nào tốt hơn ạ? \nEm xin cảm ơn', NULL, NULL, NULL, NULL, NULL),
(174, 'Nguyễn Đình Phúc', '(Nguyễn Khuyến)', 123456, 'congpham@gmail.com', '10', '2017-07-12 21:18:55', '', 'Chào thầy cô ạ, cho em hỏi là e được giải ba quốc gia môn hóa thì được vào thẳng KSTN ngành kĩ thuật hóa học nhưng liệu năm nay có chắc chắn có lớp KSTN của ngành này không ạ?Và nếu có thì lớp này liệu sẽ có cả những bạn không có giải quốc gia không ạ?Với lại e muốn hỏi thêm là năm nay thi KSTN thì thi toán lí như mọi năm hay như thế nào ạ?E xin cám ơn các thầy cô', NULL, NULL, NULL, NULL, NULL),
(175, 'Phương Nam', '(Chuyên Vĩnh Phúc)', 123456, 'congpham@gmail.com', '5', '2017-07-12 21:14:40', '', 'Cho e hỏi khi đăng kí ngành TT22  có được thi xét vào lớp kỹ sư tài năng k ạ', NULL, NULL, NULL, NULL, NULL),
(176, 'Mai Tuấn Thành', '(Thpt Phù Cừ)', 123456, 'congpham@gmail.com', '11', '2017-07-12 21:13:44', '', 'Thưa thầy, em muốn hỏi là em có nguyện vọng đăng kí CTTT Cơ điện tử ,  ngoài điểm đầu vào thì có xét thêm yêu cầu về ngoại ngữ k và  mức học  phí của CTTT như thế nào ạ', NULL, NULL, NULL, NULL, NULL),
(177, 'pham văn hưng', '(Trường THPT nguyễn khuyến)', 123456, 'congpham@gmail.com', '11', '2017-07-12 21:12:18', '', 'anh chị cho e hỏi nếu muốn đăng kí vào cttt dhbk cần có điều kiện j về ngoại ngữ', NULL, NULL, NULL, NULL, NULL),
(178, 'Trần Đức lương', '(THPT Thạch Bàn)', 123456, 'congpham@gmail.com', '4', '2017-07-12 21:11:52', '', 'cho em hỏi điểm em là 23.175 toán em 9.2 tính theo CT (toán x2  lý   hóa ) x 0.75 em đăng kí vào ngành CTTT điện tử viễn thông năm ngoái là 7.55 có an toàn không ạ', NULL, NULL, NULL, NULL, NULL),
(179, 'Lưu Đình Nhật', '(THPT Phù Cừ)', 123456, 'congpham@gmail.com', '14', '2017-07-12 21:09:56', '', 'cho e hỏi ngành TT22 có cần điều kiện tiếng anh j để đc xét tuyển k ạ nếu có thì ntn ạ e thi lại k thi t/a thì ntn ạ :P :P', NULL, NULL, NULL, NULL, NULL),
(180, 'Vũ Thị Quỳnh Trang', '(THPT Cao Bá Quát)', 123456, 'congpham@gmail.com', '5', '2017-07-12 21:08:33', '', 'Em chào thầy cô! Thầy cô có thể cho e hỏi TT24 thì coa phải thi tiếng anh đầu vào k ạ và năm đầu tiêm học hoàn toàn bằng tiếng anh ạ ? TT24 có chia riênng kĩ thuật điện bà tự động hoá k ạ ? ', NULL, NULL, NULL, NULL, NULL),
(181, 'Vũ Văn Long', '(Quốc Oai)', 123456, 'congpham@gmail.com', '7', '2017-07-12 21:07:07', '', 'Cho e hỏi: nếu thi trượt KSTN thì có thể về Chương trình tiên tiến học lớp Việt - Nhật được không ạ', NULL, NULL, NULL, NULL, NULL),
(182, 'Đào Đức Tuấn', '(Hàn Thuyên)', 123456, 'congpham@gmail.com', '9', '2017-07-12 21:06:20', '', 'Cho em hỏi về mức học phí của chơng trình tiên tiến', NULL, NULL, NULL, NULL, NULL),
(183, 'Phạm Duyên', '(Phú Xuyên B)', 123456, 'congpham@gmail.com', '13', '2017-07-12 21:04:51', '', 'thưa thày/cô e e yếu tiếng anh mà lại muốn đăng kí cttt kỹ thuật ý sinh...... vậy có yêu cầu j với đầu vafp tiếng anh k ạ???\ne cảm ơn!', NULL, NULL, NULL, NULL, NULL),
(184, 'Lê Ngọc Đồng', '(Trường THPT Tĩnh Gia 2)', 123456, 'congpham@gmail.com', '12', '2017-07-12 17:04:23', '', 'thưa thầy cô em là học sinh vừa thi tốt nghiệp THPTQG và  có dự định đăng kí vào trường Đại Học Bách Khoa Hà Nội . Em có Một số câu hỏi mong thầy cô giúp đỡ em . Em hiện tại có đăng kí mã ngành QT15 	Công nghệ thông tin, ĐH Victoria (New Zealand)  của trường Bách Khoa nhưng em vẫn chưa hiểu đôi chút về hai giai đoạn ạ . Và nếu hk xong giai đoạn một  thì nếu như em muốn học giai đoạn hai tại nước tức tại trường thì có được ko vậy ạ ?', NULL, NULL, NULL, NULL, NULL),
(185, 'Đinh Thị Mừng', '(Giao Thủy)', 123456, 'congpham@gmail.com', '6', '2017-07-12 15:49:56', '', 'e thi với số điểm toán 8.6,lý 7.75,hóa 8 , tổng 25.35 thì có thể học được những ngành gì trong trường ạ. Và điểm như thế e có thể học ngành kế toán của trường không ạ', NULL, NULL, NULL, NULL, NULL),
(186, 'Đinh Thị Kim Khánh', '(Trường THPT Giao Thủy)', 123456, 'congpham@gmail.com', '6', '2017-07-12 15:43:04', '', 'Thưa thầy cô tư vấn cho em. Điểm thi cộng cả khu vực tổng là 22. Trong đó Toán: 8,2.   Văn: 6,75 .  Tiếng anh: 6,0. Em xin hỏi với số điểm trên em có lên đăng ký vào nhóm ngành KQ2 không ạ', NULL, NULL, NULL, NULL, NULL),
(187, 'Đặng Ngọc Anh', '(Nguyễn Đức Cảnh)', 123456, 'congpham@gmail.com', '8', '2017-07-12 15:30:45', '', 'Ngành kinh tế công nghiệp và quản lí công nghiệp có gì khác nhau ạ? Cụ thể là em sẽ phải học những môn học gì sau khi trúng tuyển vào một trong hai ngành trên? Sau này, em có thể làm việc ở đâu?\nEm cảm ơn thầy cô.', NULL, NULL, NULL, NULL, NULL),
(188, 'Đỗ Đức Thắng', '(Hoàng Văn Thụ)', 123456, 'congpham@gmail.com', '13', '2017-07-12 15:27:23', '', 'em chào thầy cô ạ, cho em hỏi cái tiêu chí phụ là như nào ạ và năm nay điểm đấy có tăng lên không ạ ???\r\n', NULL, NULL, NULL, NULL, NULL),
(189, 'Mai Nhật Quang', '(Trường THPT Trần Hưng Đạo - Nam Định)', 123456, 'congpham@gmail.com', '16', '2017-07-12 15:25:09', '', 'Điểm thi khối A của em la 21,5, khối B là 22,8, khối A1 là 22, em có thể trúng tuyển khoa nào của ĐH Bách khoa năm nay không ạ? Cảm ơn các thầy', NULL, NULL, NULL, NULL, NULL),
(190, 'Đỗ Duy Ngọc', '(Nguyễn Huệ)', 123456, 'congpham@gmail.com', '9', '2017-07-12 15:23:28', '', 'Em muốn thi vào trường, khoa Cntt hệ kỹ sư. Trong trường hợp không đủ điểm vào hệ kỹ sư thì nguyện vọng vào hệ cử nhân.\r\nNhưng cả 2 hệ mã ngành đều là KT22 thì em sẽ phải ghi 2 lần vào hồ sơ hay chỉ cần ghi 1 lần ạ?', NULL, NULL, NULL, NULL, NULL),
(191, 'Hà Lê Quỳnh', '(THPT Nguyễn DU)', 123456, 'congpham@gmail.com', '5', '2017-07-12 15:20:02', '', 'Thưa thầy, em đăng kí nguyện vọng là Kinh tế công ngiệp và Quản lí công nghiệp thuộc nhóm ngành Kinh tế -Quản lí. Vậy em sẽ ghi vào phiếu đăng kí dự thi của mình sẽ là Mã ngành/nhóm ngành : KQ1 và tên ngành/ nhóm  ngành: Kinh tế -Quản lí 1 có đúng không ạ. Em cảm ơn nhiều ạ', NULL, NULL, NULL, NULL, NULL),
(192, 'Trương Đức Hiếu', '(thpt Phan Huy Chú - Đống Đa)', 123456, 'congpham@gmail.com', '11', '2017-07-12 15:17:18', '', 'ch muốn nộp hs sơ tuyển cho con trai vào nhóm GX , mã ngành QT15 và TT22 . tư vấn giúp ch nhé', NULL, NULL, NULL, NULL, NULL),
(193, 'Cao Xuân Hùng ', '(Trường THPT Đô Lương 3)', 123456, 'congpham@gmail.com', '11', '2017-07-12 15:05:11', '', 'Em thi đc 24.2 giờ học cơ điện tử hệ 8.05 có khả năng đậu ko ạ \ntoán 8.2 vật lý 7 hóa học 8\n', NULL, NULL, NULL, NULL, NULL),
(194, 'Hoàng Minh Việt', '(THPT Quảng Hà)', 123456, 'congpham@gmail.com', '9', '2017-07-12 15:03:46', '', 'em là sinh viên năm nhất trường DHCN QUẢNG NINH. năm năm em muốn học lại vì dhcn quảng ninh k có ngành em muốn theo học. bây giờ e muốn xét tuyển vào trường mình, mà e lại k dăng kí thi đại học năm 2106 mà chỉ thi TN THPTQG k thôi. nếu muốn theo học trường mình e cần làm như thế nào ạ?. xét tuyển học bạ hay có thể chuyển từ DHCN Quảng Ninh lên thẳng dc k ạ. giúp em', NULL, NULL, NULL, NULL, NULL),
(195, 'Nguyễn Thị Thảo', '(THPT Nam Trực)', 123456, 'congpham@gmail.com', '3', '2017-07-12 15:02:53', '', 'cho e hỏi điểm dự kiếm năm nay có cao hơn năm ngoái không ạ, em được 25,3 dự định nộp vào ngành kĩ thuật ô tô hoặc nhiệt-lạnh thì có khả năng đỗ không ạ', NULL, NULL, NULL, NULL, NULL),
(196, 'đỗ tuấn khanh', '(thpt ngọc tảo)', 123456, 'congpham@gmail.com', '15', '2017-07-12 15:00:50', '', 'cách tính điểm thi vs tiêu chí phụ năm nay là gì ạ?', NULL, NULL, NULL, NULL, NULL),
(197, 'Phạm Thị Thu Hà', '(THPT Nguyễn DU)', 123456, 'congpham@gmail.com', '12', '2017-07-12 14:53:14', '', 'Em chào Thầy Cô ạ, cho em hỏi câu hỏi như sau ạ. Sau khi biết điểm thi, em vẫn giữ các nguyện vọng như bản đki như sau: nv1: công nghệ tt - ĐHBK, nv2: Điện tử - ĐHBK, nv3:Cơ khi-ĐHBK, nv4: Kỹ thuật - ĐH XD...thì khi xét tuyển đợt 1 thì xét như thế nào ạ. Em thấy bảo ví dụ nv1 e k đủ điểm, khi xét tới nv2, nếu như cacs bạn khác lấy nv2 của em làm nv1 thì khi đó, ngành đủ chỉ tiêu rồi, mà điểm của em cao hơn điểm đầu vào ngành đó thì em có trúng không ạ. Em xin cảm ơn các Thầy Cô ạ.', NULL, NULL, NULL, NULL, NULL),
(198, 'Dương', '(Vĩnh Phúc)', 123456, 'congpham@gmail.com', '2', '2017-07-12 14:49:38', '', 'Em chào Thầy (Cô) ạ! Thầy (Cô) cho e hỏi năm có phải vẫn tính điểm: (Toán x2   Lí   Hóa   điểm KV) / 4 = điểm mình ------ có đúng không ạ. E thi khối A ', 'jdsjfkljsdlkajflkjdslkaflksdjalkfjlksdjlakjflksdjlkfj', '1', '2017-09-21 03:38:31', '2017-09-22 00:00:00', 98875),
(199, 'nguyễn hoàng chiến', '(trường PTTH hàn thuyên bắc ninh)', 123456, 'congpham@gmail.com', '15', '2017-07-12 14:49:04', '', 'điểm thi cụ thể : toans9,4.  Lý 9,25  ,Hóa 8.0 điểm yêu tiên khu vưc 2 với tổn diem nhu vay có kha nang vao truong DHBKHN ma nganh Kt21 hoac KT22 không', NULL, NULL, NULL, NULL, NULL),
(200, 'Nguyễn Đức Hiển', '(Đống Đa Hà Nội)', 123456, 'congpham@gmail.com', '10', '2017-07-12 14:46:33', '', 'Thưa Thầy Cô ! Em thi tổ hợp A00 được 25,5 điểm tính theo cách tính của trường em được 26 điểm . Em thấy phổ điểm năm 2017 cao hơn 2016 khoảng 2-3 điểm ( cùng số thí sinh ) như vậy theo như 2016 em được khoảng 23 điểm 3 môn . Nếu theo cách tính năm ngoái e được 7,8- 8 điểm . Em muốn vào ngành kỹ thuật như cttt CNTT , Cttt cơ điện tử , hoặc cttt điện tử  vậy xin Thầy Cô cho em biết liệu em có khả năng  vào được không ạ ! Em xin cảm ơn Thầy Cô ạ !\n', NULL, NULL, NULL, NULL, NULL),
(201, 'Lê Huy Sơn', '(Trường PTTH Trần Nguyên Hãn)', 123456, 'congpham@gmail.com', '5', '2017-07-12 14:45:07', '', 'Em xin hỏi : Điểm thi  của em là 23,65 điểm (khối A1) Toán 7,8, Lý 8,25, Tiếng Anh 7,6 Em đăng ký nguyên vọng vào KT24 - Như vậy em có đủ điểm đỗ vào khoa trên của trường Đại học Bách khoa Hà Nội được không a, nếu ko được có vào được khoa kinh tế của Trường ko a,Em xin cám ơn', NULL, NULL, NULL, NULL, NULL),
(202, 'Đặng Xuân Hoàng', '(THTP Cổ Loa)', 123456, 'congpham@gmail.com', '2', '2017-07-12 14:45:00', '', 'Thưa thầy cô em thi Khối A vào ngành Cơ khí-Động lực học của trường Bách Khoa Hà Nội với điểm thi 3 môn Toán:8,4 Lí:7 Hóa:7,75 thì có khả năng đỗ không ạ.Chỗ em có cộng thêm điểm khu vực 0,5 nữa ạ.', 'lkdsajflkjdsalkjflksdjalkfjlksdajlkf\nfdgsdfgdfsgfdsg', '9', '2017-09-24 22:29:06', '2017-09-24 23:00:00', 42405),
(203, 'đỗ quốc dũng', '(thpt yên dũng số 2)', 123456, 'congpham@gmail.com', '6', '2017-07-12 14:38:18', '', '22 điểm năm nay em có khả năng đỗ hệ cử nhân cơ điện tử không ạ', NULL, NULL, NULL, NULL, NULL),
(204, 'Phạm Hà Linh', '(THPT Nguyễn Du)', 123456, 'congpham@gmail.com', '11', '2017-07-12 14:33:07', '', 'Ngày bao nhiêu thì nộp hồ sơ xét tuyển ạ . Và cần nộp những gì ạ . E c.ơn', NULL, NULL, NULL, NULL, NULL),
(205, 'Nguyễn Ngọc Anh', '(THPT Hoàng Hoa Thám, Pleiku, Gia Lai)', 123456, 'congpham@gmail.com', '15', '2017-07-12 14:29:43', '', 'Cho em hỏi là BKA tuyển sinh bằng phương thức xét tuyển học bạ thì hồ sơ gồm những gì và thời gian nào nộp hồ sơ ?', NULL, NULL, NULL, NULL, NULL),
(206, 'Ngọc Linh ', '(thpt nguyễn trãi)', 123456, 'congpham@gmail.com', '6', '2017-07-12 14:28:43', '', 'Chào thầy cô ạ, năm nay em định thi vào trường. Em muốn hỏi có cần phải mua thêm hồ sơ gì ở trường không ạ    ', NULL, NULL, NULL, NULL, NULL),
(207, 'Quốc Thái', '(Lê Quý Đôn)', 123456, 'congpham@gmail.com', '7', '2017-07-12 14:26:54', '', 'Em muốn đăng ký 2 nhóm ngành là Tự đông hoá và Điện tử truyền thông mỗi nhóm ngành em đăng ký 2 khối A00 và A01 tổng là 4 nguyện vọng có được k ạ.E thấy tren mạng là chỉ được đăng ký tối đa 2 nguyện vọng đúng k ạ . Em cảm ơn.', NULL, NULL, NULL, NULL, NULL),
(208, 'Vũ Tuấn Dương', '(Quốc Tuấn)', 123456, 'congpham@gmail.com', '12', '2017-07-12 14:19:59', '', 'Em chào thầy cô ạ!!! Thầy cô cho e hỏi năm nay tính thang điểm 30 hay thang điểm 10 ạ! ', NULL, NULL, NULL, NULL, NULL),
(209, 'nguyễn phương nam', '(thpt bình sơn)', 123456, 'congpham@gmail.com', '10', '2017-07-12 14:15:43', '', 'em được 24.85 điểm khối A thi vào ngành kĩ thuật hàng không điểm vùng được cộng 1.5 toán  8.6 liệu có đỗ được không các anh chị', NULL, NULL, NULL, NULL, NULL),
(210, 'Lê Trâm Anh', '(THPT Thái Phiên)', 123456, 'congpham@gmail.com', '8', '2017-07-12 14:13:12', '', 'Cho em hỏi trường xét tuyển học bạ trung bình ba năm trên 22,0 là sao ạ? Trung bình? Trên 22?', NULL, NULL, NULL, NULL, NULL),
(211, 'Nguyễn Thái Phong', '(Phạm Hồng Thái)', 123456, 'congpham@gmail.com', '6', '2017-07-12 14:06:37', '', 'Trường ơi cho em hỏi là trường mình xét học bạ như thế nào ạ ? Em tìm kiếm trên website của nhà trường mà không thấy. Với cả hạn chót xét học bạ là ngày bao nhiêu ạ. Em cảm ơn trường ạ', NULL, NULL, NULL, NULL, NULL),
(212, 'Nguyễn Thị Phương Anh', '(THPT Hoài Đức A)', 123456, 'congpham@gmail.com', '10', '2017-07-12 14:04:21', '', 'E muốn đăng kí ngành công nghệ thực phẩm của trường mình. Nhưng khi xem thông tin tuyển sinh và xem điểm chuẩn năm ngoái, e thấy có 2 ngành công nghệ thực phẩm. 1 là CN3 , 2 là KT31. Vậy thầy cô có thể giải đáp cho e được k ạ...', NULL, NULL, NULL, NULL, NULL),
(213, 'Nguyễn Văn Tùng', '(THPT Hàn Thuyên- Bắc Ninh)', 123456, 'congpham@gmail.com', '2', '2017-07-12 13:50:46', '', 'Em chào thầy cô ạ! Em muốn nguyện vọng vào ngành CNTT của trường ạ! Nhưng theo tìm hiểu e thấy có 2 mã CN2- cử nhân công nghệ và KT22- cử nhân kỹ thuật đều đào tạo CNTT. Vậy em muốn biết sự khác nhau của 2 ngành này là gì ạ? Và thời gian đào tạo 2 khối trên là như nhau ạ?\r\n', NULL, NULL, NULL, NULL, NULL),
(214, 'Vũ Chí Tuấn Anh', '(THPT Xuân Đỉnh)', 123456, 'congpham@gmail.com', '7', '2017-07-12 13:38:00', '', 'Em đăng kí thi ngành CNTT của trường mình, em chọn khối A1 thì cách xét điểm như thế nào ạ? Và em thi a1 có thiệt hơn khi xét tuyển những bạn thi a0 không ạ? Em cảm ơn anh/ chị/ thâỳ/ cô ạ!', NULL, NULL, NULL, NULL, NULL),
(215, 'Nguyễn Quang Anh', '(Yên Hòa HN)', 123456, 'congpham@gmail.com', '14', '2017-07-12 10:53:40', '', 'Em thấy năm trước có các mã ngành CN1,2,3. Năm nay không có trong mã ngành tuyển sinh. Vậy khi xét tuyển có hay không. Em xin cám ơn. ', NULL, NULL, NULL, NULL, NULL),
(216, 'Đinh Thi Kim Khánh', '(Trường THPT Giao Thủy)', 123456, 'congpham@gmail.com', '16', '2017-07-12 10:50:17', '', 'Thưa thầy cô tư vấn giúp em. Em dự thi khối D. Toán 8.2. Văn 6.75. Tiếng anh 6.0 cộng cả điểm khu vực em được 22 điểm. Em muốn học vào nhóm ngành KQ2.Vậy em có đủ điểm để xét tuyển không a.\r\n', NULL, NULL, NULL, NULL, NULL),
(217, 'Đỗ Đức Thắng ', '(Chuyên Hoàng Văn Thụ)', 123456, 'congpham@gmail.com', '10', '2017-07-12 10:45:25', '', 'cho em hỏi tiêu chí phụ là như nào ạ ??? năm nay tiêu chí phụ đấy có tăng không ạ ??', NULL, NULL, NULL, NULL, NULL),
(218, 'phùng quang tùng', '(thpt Yên Lãng)', 123456, 'congpham@gmail.com', '14', '2017-07-12 10:40:37', '', 'thầy cô cho e hỏi là hệ cử nhân cntt thì điểm xét có khác với hệ kĩ sư cntt k ạ. Có phải cử nhân điểm hấp hơn kĩ sư k ạ', NULL, NULL, NULL, NULL, NULL),
(219, 'Nguyễn Việt Anh', '(Trường THPT Triệu Sơn 2)', 123456, 'congpham@gmail.com', '2', '2017-07-12 10:40:09', '', 'chào thầy cô ạ! khi em đủ điểm vào trường thì trường xét học bạ ntn ạ? em có điểm trung bình môn hóa của kì 1 năm lớp 10 dưới 6,5 còn tất cả các kì còn lại trên 8, thì em có đủ điều kiện vào trường ko ạ\n', NULL, NULL, NULL, NULL, NULL),
(220, 'Vũ Văn Long', '(Thpt Nguyễn Du Thanh Oai)', 123456, 'congpham@gmail.com', '5', '2017-07-12 10:37:53', '', 'Em vừa thi thpt quốc gia xong mà có mong muốn được theo học tại trường. Vậy cho em hỏi trong các nhóm nghành mà trường đang đào tạo thì những nhóm nhanh nào có nhiều cơ hội xin việc hơn. Em xin cảm ơn.', NULL, NULL, NULL, NULL, NULL),
(221, 'Lê Thị Trần Thủy', '(THPT Lê Hoàn )', 123456, 'congpham@gmail.com', '3', '2017-07-12 10:34:29', '', 'cho em hỏi nếu như em không có đủ điểm để đỗ hệ đại học của trường thì trường có hệ cao đẳng không ạ\n', NULL, NULL, NULL, NULL, NULL),
(222, 'Phạm Trọng Đại', '(THPT Toàn Thắng)', 123456, 'congpham@gmail.com', '3', '2017-07-12 10:33:24', '', 'Các thầy cô cho em hỏi là năm 2017 có khoa nào của trường xét tuyển học bạ mà không xét điểm thi trung học phổ thông không ạ. Ý em là chỉ xét tuyển dựa vào học bạ ấy ạ. Em xin cảm ơn', NULL, NULL, NULL, NULL, NULL),
(223, 'Tuấn Anh', '(Nông Cống 1)', 123456, 'congpham@gmail.com', '4', '2017-07-12 10:31:37', '', 'Cho em hỏi cách tính điểm chuẩn của một số ngành là như thế nào ạ, tại em cứ thấy điểm chuẩn nv1 có 8 hay 8,5 là sao ạ, cụ thể hơn thì em muốn hỏi ngành kĩ thuật hàng không thì thế nào ạ ', NULL, NULL, NULL, NULL, NULL),
(224, 'bùi minh hiệu', '(xuân mai)', 123456, 'congpham@gmail.com', '14', '2017-07-12 10:31:36', '', 'em thi khối a, toán 7,8 ,lý 6,75 ,hóa 6,75 cách tính điểm vào bách khoa thì em bao nhiều điểm , có hi vọng vào trường ko ạ', NULL, NULL, NULL, NULL, NULL),
(225, 'Chu Quang Huy', '(Trường THPT chuyên Thái Nguyên)', 123456, 'congpham@gmail.com', '3', '2017-07-12 10:29:18', '', 'Ngành cntt có KT22 và TT22, 2 cái này khác nhau ntn ạ (về tất cả các mặt như là điểm đầu vào, học phí, cơ hội việc làm ra sao)', NULL, NULL, NULL, NULL, NULL),
(226, 'Nguyễn Quốc Tuấn ', '(Trường THPT Sóc Sơn)', 123456, 'congpham@gmail.com', '16', '2017-07-12 10:28:58', '', 'cho em hỏi về cách tính điểm vào Bách Khóa năm nay (2017) và cách xét tuyển nhóm ngành kỹ thuật ô tô ', NULL, NULL, NULL, NULL, NULL),
(227, 'bùi minh hiệu ', '(xuân mai)', 123456, 'congpham@gmail.com', '11', '2017-07-12 10:28:46', '', 'điểm thi khối a của em 21,3 thì có khả năng vào trường nào ạ . Em thích học công nghệ thông tin liêu  có được ko ạ ', NULL, NULL, NULL, NULL, NULL),
(228, 'đặng văn dũng', '(thpt hai bà trưng)', 123456, 'congpham@gmail.com', '10', '2017-07-12 10:27:34', '', 'cho em hỏi học nghành cơ điện tử học phí bao nhiêu ạ.với lại nếu đi học thì có xin được vào kí túc xá không ạ?', NULL, NULL, NULL, NULL, NULL),
(229, 'bùi minh hiệu', '(xuân mai)', 123456, 'congpham@gmail.com', '9', '2017-07-12 10:27:16', '', 'hiện nay điểm thi khối a của cháu là 21.3 ( không kể điểm khu vực),cháu thích học công nghệ thông tin thì có khả năng không, với mức điểm đó cháu có khả năng vào trường nào ', NULL, NULL, NULL, NULL, NULL),
(230, 'Trần Minh Đức', '(thpt diễn châu 2)', 123456, 'congpham@gmail.com', '7', '2017-07-12 10:23:16', '', 'chào thầy cô ạ!!em muốn hỏi xem cách tính điểm của trường như thế nào ạ?? và ưu tiên nguyện vọng 1 hay mọi nguyện vọng như nhau vây???em cảm ơn ạ!!!!', NULL, NULL, NULL, NULL, NULL),
(231, 'Nguyễn Đăng', '(Kim Liên)', 123456, 'congpham@gmail.com', '15', '2017-07-12 10:22:23', '', 'Em xin hỏi: \"Em đã đăng ký nguyện vọng 1 vào trường mình nhưng điểm thi của em chỉ ở mức điểm chuẩn năm ngoái của ngành đó nên em muốn đăng ký thêm nguyên vọng vào ngành có điểm đầu vào thấp hơn một chút của trường mình thì nguyện vọng đăng ký thêm này sẽ được xét vào đợt 2 phải không a? Và các nguyện vọng cũ em đã đăng ký có được xét đợt 1 không hay cũng phải chuyển sang xét đợt 2?\nEm cảm ơn các thầy/cô ạ.', NULL, NULL, NULL, NULL, NULL),
(232, 'Nguyễn Bá Quân', '(THPT Chuyên Biên Hòa)', 123456, 'congpham@gmail.com', '11', '2017-07-12 10:21:34', '', 'Thưa thầy cô, cho em hỏi theo cơ chế tính điểm mới với thang điểm 30 như năm nay thì giải ba hsg quốc gia sẽ được cộng bao nhiêu điểm ạ ? Em cảm ơn', NULL, NULL, NULL, NULL, NULL),
(233, 'Lê Nga', '(Thpt Đức Thọ)', 123456, 'congpham@gmail.com', '6', '2017-07-12 10:20:26', '', 'Em nghe ac nói là năm nay k tách CN và KT vậy ví dụ năm nay em muốn đăng kí CN2 thì phải sửa nguyện vọng như thế nào ạ? Em cảm ơn', NULL, NULL, NULL, NULL, NULL),
(234, 'Dương Văn Hòa', '(THPT Hiệp Hòa)', 123456, 'congpham@gmail.com', '5', '2017-07-12 10:20:12', '', 'Thầy cô cho em hỏi: khi xem điểm chuẩn của trường các năm, em có thấy tiêu chí phụ là môn toán với các mức điểm khác nhau. ví dụ như ngành kĩ thuật cơ điện tử có tiêu chí phụ là môn toán :8,5. Em thắc mắc rằng liệu có phải các thí sinh trên 8,5 mới được đăng kí vào ngành này hay không. Xin thầy cô giải đáp thắc mắc cho em. Em xin chân thành cảm ơn', NULL, NULL, NULL, NULL, NULL),
(235, 'Đinh Thị Mừng ', '(Giao Thuỷ )', 123456, 'congpham@gmail.com', '2', '2017-07-12 10:17:22', '', 'Với số điểm 25.35 e có thể học được những ngành nào của trường ạ', NULL, NULL, NULL, NULL, NULL),
(236, 'Lê Việt Hoàng', '(Cầu Giấy)', 123456, 'congpham@gmail.com', '6', '2017-07-12 10:16:22', '', 'em vẫn chưa biết là bao giờ thì mua và nộp hồ sơ đăng ký xét tuyển tại trường Bách Khoa Hà Nội thế ạ?? có phải là sau khi đợt thay đổi nguyện vọng diễn ra không ạ', NULL, NULL, NULL, NULL, NULL),
(237, 'đặng trần thiện ', '(thpt chuyên Nguyễn Huệ Hà Nội )', 123456, 'congpham@gmail.com', '5', '2017-07-12 10:14:43', '', 'chà thầy. \nem muốn hỏi thầy 2 vấn đề như sau:\n1: nếu em đăng ký và trúng tuyển ngành cn2. thì em có được dự thi tuyêrn vào cttt CNTT ko ạ. \n2: nếu được thi và em trúng tuyển thì sau này ra trường bằng của em có tương đương với bằng của các bạn bên kt 22 không ạ ', NULL, NULL, NULL, NULL, NULL),
(238, 'Lê Nga', '(THPT Đức Thọ)', 123456, 'congpham@gmail.com', '4', '2017-07-12 10:13:17', '', 'Em chào Thầy,\nThưa Thầy cho em hỏi là: Em có đứa em năm nay định xét tuyển vào hệ cử nhân CNTT của trường mình mà em thấy trên trang tuyển sinh là hệ cử nhân lại gộp vào KT22 vậy năm nay là chung cho cả 2 hệ đó là cùng 1 điểm đầu vào hả Thầy ?\n', NULL, NULL, NULL, NULL, NULL),
(239, 'Nguyễn Thị Xuyến', '(Ngọc Hồi)', 123456, 'congpham@gmail.com', '14', '2017-07-12 10:11:31', '', 'năm nay trường có tính điểm như năm 2016 không ạ?(hay là môn toán không nhân 2 nữa và cũng không cộng điểm ưu tiên nữa ạ?) Nếu em được 24,2 (cả vùng là 0.5) thì có khả năng đỗ được KT31, hoặc KT13 không ạ?', NULL, NULL, NULL, NULL, NULL),
(240, 'thân thế ngoan', '(Trường tHPT Việt Yên 1 Bắc Giang)', 123456, 'congpham@gmail.com', '2', '2017-07-12 10:10:38', '', 'Em đạt 24.65 khối A, liệu em có đậu vào trường Bách Khoa Hà Nội không?', NULL, NULL, NULL, NULL, NULL),
(241, 'nguyễn thế anh', '(thpt nho quan b)', 123456, 'congpham@gmail.com', '16', '2017-07-12 10:07:43', '', 'cho e hỏi là năm nay mấy ngành đầu là cntt,tự động hóa với điện tử viễn thông thì điểm sẽ xét là không cộng điểm ưu tiên với toán không nhân đôi nữa ạ cơ', NULL, NULL, NULL, NULL, NULL),
(242, 'nguyễn linh ch', '(thpt lê hồng phong thái nguyên)', 123456, 'congpham@gmail.com', '12', '2017-07-12 10:07:40', '', 'thầy cô cho em hỏi em có em họ năm nay thi em tính theo cách tính của trường mình là toán nhân đôi với tổ hợp toán lý hóa là em đc 28.5. Em nó rất thích Công nghệ thông tin và với số điểm đấy liệu có bao nhiêu phần trăm vào đc ngành này và điểm xét tuyển hồ sơ em có thể theo dõi ở đâu ạ.Bao lâu thì hết hạn đk xét tuyển đợt 1 ạ.Em chân thành cám ơn. ', NULL, NULL, NULL, NULL, NULL),
(243, 'Nguyễn Xuân Trường', '(Đông Hiếu)', 123456, 'congpham@gmail.com', '4', '2017-07-12 10:06:42', '', 'tiêu chí phụ năm nay là những gì vậy ạ? em có đọc qua nhưng không hiểu nên mong anh(chị) giải thích rõ hơn ạ!', NULL, NULL, NULL, NULL, NULL),
(244, 'Nguyễn Thanh Long', '(Cao Thắng)', 123456, 'congpham@gmail.com', '9', '2017-07-12 10:04:47', '', 'Chào Thầy/Cô\nCho e hỏi là những ngành nào trong trường có môm chính, và là môm gì à?\nEm cảm ơn!', NULL, NULL, NULL, NULL, NULL),
(245, 'Đinh Lê Nhất Thống', '(thpt chuyên Đại học Vinh)', 123456, 'congpham@gmail.com', '5', '2017-07-12 10:04:18', '', 'Cho em hỏi cách tính điểm ưu tiên của bách khoa hà nội với ạ.\nEm thấy bka có cộng điểm ưt(kv,đt) nhưng không ghi rõ diện ưu tiên.\nCho em hỏi luôn đạt giải khuyến khích hsg quốc gia có được cộng điểm không ạ?\nEm cảm ơn', NULL, NULL, NULL, NULL, NULL),
(246, 'Đinh Lê Nhất Thống', '(thpt chuyên Đại học Vinh)', 123456, 'congpham@gmail.com', '12', '2017-07-12 10:03:49', '', 'Cho em hỏi cách tính điểm ưu tiên của bách khoa hà nội với ạ.\nEm thấy bka có cộng điểm ưt(kv,đt) nhưng không ghi rõ diện ưu tiên.\nCho em hỏi luôn đạt giải khuyến khích hsg quốc gia có được cộng điểm không ạ?\nEm cảm ơn', NULL, NULL, NULL, NULL, NULL),
(247, 'Phạm Nhật Anh', '(THPT Công Nghiệp Việt Trì)', 123456, 'congpham@gmail.com', '10', '2017-07-12 10:03:29', '', 'Thưa thầy điểm xét tuyển vào một ngành giữa các khối ví dụ như A , A1,.. là khác nhau hay cùng một mức ạ ?', NULL, NULL, NULL, NULL, NULL),
(248, 'Nguyễn Thị Hà', '(trường thpt Bắc Kiến Xương)', 123456, 'congpham@gmail.com', '6', '2017-07-12 10:02:51', '', 'thầy cô cho em hỏi về công thức tính điểm trường mình về điểm cộng là như thế nào ạ.Em cảm ơn', NULL, NULL, NULL, NULL, NULL),
(249, 'Đoàn Tuấn Anh', '(Võ Nhai)', 123456, 'congpham@gmail.com', '12', '2017-07-12 10:02:31', '', 'em được 23.35 cả điểm ưu tiên, toán em được 7.6. Admin có thể tư vấn giup em nên đăng kí ngành nào của Bách khoa không ạ. Em cảm ơn. Cụ thể em muốn ngành mà liên quan đến hệ thống điện tử...', NULL, NULL, NULL, NULL, NULL),
(250, 'Đỗ Văn Phương', '(Trường THPT Lý Bôn)', 123456, 'congpham@gmail.com', '4', '2017-07-12 10:00:41', '', 'Năm 2017 trường có tính điểm khu vực vào điểm xét tuyển không ạ?', NULL, NULL, NULL, NULL, NULL),
(251, 'nguyen huu trung', '(an thới)', 123456, 'congpham@gmail.com', '6', '2017-07-12 10:00:30', '', 'em chào thầy cô ạ,  cho e hỏi trường mình có đào tạo ngành kĩ thuật ô tô không ạ,  và trường có xét học bạ không ạ ', NULL, NULL, NULL, NULL, NULL),
(252, 'Nguyễn Minh Hoàng', '(Hoàng Quốc Việt)', 123456, 'congpham@gmail.com', '14', '2017-07-12 10:00:19', '', 'cho e hỏi cách tính điểm năm nay ntn ạ? và năm nay tính điểm thì toán có đc nhân đôi k ạ ?\n', NULL, NULL, NULL, NULL, NULL),
(253, 'Võ Minh Thu', '(THPT Kim Liên)', 123456, 'congpham@gmail.com', '16', '2017-07-12 09:59:37', '', 'Em muốn hỏi đầu vào điểm của khoa Hóa-Sinh-Thực phẩm và Môi trường của các năm khoảng bao nhiêu  và tiêu chí về môn Toán là bao nhiêu ạ?Em cảm ơn.', NULL, NULL, NULL, NULL, NULL),
(254, 'Trương Văn Thành', '(Lương Đắc Bằng - Hoằng Hóa - Thanh Hóa)', 123456, 'congpham@gmail.com', '12', '2017-07-12 09:58:13', '', 'Chào thầy cô! Em có một câu hỏi về điểm chuẩn của trường trong năm 2016. Ví dụ ngành công nghệ thông tin trong năm 2016 điểm chuẩn là 8.82 thì số điểm đó cho cả khối A0 và A1 là như nhau ạ? Em xin cảm ơn!', NULL, NULL, NULL, NULL, NULL),
(255, 'Tô Hoàng Hiệp', '(Quỳnh lưu 3)', 123456, 'congpham@gmail.com', '8', '2017-07-12 09:57:43', '', 'Vì số điểm của em không có khả năng đậu vào ngành kĩ sư, nên cho e hỏi đăng kí cử nhân như thế nào ạ? Kĩ sư với Cử nhân điểm có chênh lệch nhau không?', NULL, NULL, NULL, NULL, NULL),
(256, 'Hà linh', '(THPT NGUYỄN DU)', 123456, 'congpham@gmail.com', '4', '2017-07-12 09:56:35', '', 'Có phải trường nưm nay xét học bạ không ạ . Và thời gian nộp học bạ là thời gian nào và cần nộp những gì ạ . E c.ơn', NULL, NULL, NULL, '0000-00-00 00:00:00', NULL),
(257, 'Phạm văn thắng', '(thpt anh son 1)', 123456, 'congpham@gmail.com', '15', '2017-07-12 09:56:12', '', 'em đạt số điểm toán 8.2 , lý 7.5.hóa 6,5 điểm vùng đưọc cọng của em là 1,5\nem muốn đăng kí bách khoa hà noị . có đủ và nên chọn ngành naò ạ. em cảm on', NULL, NULL, NULL, NULL, NULL),
(258, 'Nguyễn Thị Khánh Ly ', '(Trường THPT Quỳnh Lưu 4)', 123456, 'congpham@gmail.com', '8', '2017-07-12 09:56:06', '', 'Hồ sơ xét tuyển học bạ gồm những gì?  Hiện nay em chưa có băng tốt nghiệp thì có thể nạp hồ sơ về trường rồi bổ sung ngay khi có bằng tốt nghiệp được không ạ? ', NULL, NULL, NULL, NULL, NULL),
(259, 'Vương Quốc Mạnh', '(Trường PTTH Thuận Thành 1, Bắc Ninh)', 123456, 'congpham@gmail.com', '9', '2017-07-12 09:54:38', '', 'E chỉ đăng ký xét tuyển ở Hai trường, nhưng không đăng ký xét tuyển vào trường ĐH Bách khoa Hà Nội. E hỏi sau khi có kết quả kỳ thi em có được thay đổi nguyện vọng sang trường ĐH Bách khoa được không . E đăng ký xét tuyển ngành CNTT tại trường ĐH Công Nghiệp và Học viện Bưu chính viễn thông. Em cảm  ơn.', NULL, NULL, NULL, NULL, NULL),
(260, 'NGUYEN MINH DUC', '(THTP NÔNG CỐNG II)', 123456, 'congpham@gmail.com', '15', '2017-07-12 09:54:23', '', 'Em chào Thầy, Cô\n\nEm có nguyện vọng muốn đăng vào hệ cử nhân Công nghệ thông tin (CN) của trường ĐH Bách Khoa Hà Nội. Tuy nhiên, mã nhóm ngành của cử nhân nằm chung với các khoa của CNTT, đều nằm trong KT22.\nVậy thì nếu em đăng kí nhóm ngành KT22 thì điểm trúng tuyển của cử nhân cũng bằng với cái ngành kia ạ? Và làm sao để biết được chính xác em đăng kí và trúng tuyển vào cử nhân CNTT hay ví dụ như HTTT ạ ?\n\nEm cám ơn!', NULL, NULL, NULL, NULL, NULL),
(261, 'Đặng Duy Hưng', '(chuyên Nguyễn Huệ)', 123456, 'congpham@gmail.com', '11', '2017-07-12 09:51:59', '', 'Em chào thầy cô, thầy cô có thể cho em hỏi thi vào ngành Hệ thống điện là xét tổ hợp môn Toán Lý Hoá hay là Toán Lý Anh được không ạ', NULL, NULL, NULL, NULL, NULL),
(262, 'Đỗ Văn Phương', '(Trường THPT Lý Bôn)', 123456, 'congpham@gmail.com', '13', '2017-07-12 09:51:53', '', 'Em xem tin tức thấy nói năm nay trường bk hà nội không tính điểm ưu tiên nghĩa là có tính điểm vùng không ạ? Như em thuộc khu vực 2-NT (được cộng 1 điểm) thì có được không ạ?', NULL, NULL, NULL, NULL, NULL),
(263, 'Nguyễn Đức Trung', '(THPT Thăng Long)', 123456, 'congpham@gmail.com', '5', '2017-07-12 09:51:24', '', 'Cho em hỏi điểm chuẩn để vào Cử nhân công nghệ (ngành công nghệ thông tin) năm ngoái là bao nhiêu ạ và liệu năm nay có cao hơn không ạ', NULL, NULL, NULL, NULL, NULL),
(264, 'Nguyễn Hải Phong', '(THPT Thanh Miện)', 123456, 'congpham@gmail.com', '4', '2017-07-12 09:49:50', '', 'thầy ơi, vì một số lý do mà điểm trung bình môn tin, sinh của em dưới 6,5. thầy cho em hỏi nó có ảnh hưởng tới việc xét tuyển không ạ? em cảm ơn thầy', NULL, NULL, NULL, NULL, NULL),
(265, 'Nguyễn Hoàng Anh', '(Trường THPT Chuyên Hưng Yên)', 123456, 'congpham@gmail.com', '9', '2017-07-12 09:48:42', '', 'Cho em hỏi muốn nộp đơn xét tuyển vào trường căn cứ theo kết quả học tập thì cần chuẩn bị những gì ạ?', NULL, NULL, NULL, NULL, NULL),
(266, 'nguyên văn kiên', '(lê quy đôn)', 123456, 'congpham@gmail.com', '11', '2017-07-12 09:48:18', '', 'cac hinh thuc xét tuyen cua truong dua trên cac hinh thuc nao', NULL, NULL, NULL, NULL, NULL),
(267, 'Hồ Khánh Linh', '(Thpt Đông Hiếu)', 123456, 'congpham@gmail.com', '5', '2017-07-12 09:47:38', '', 'Trường đh Bách Khoa Hà Nội có xét tuyển học bạn k ạ? ', NULL, NULL, NULL, NULL, NULL),
(268, 'Vũ Chí Tuấn Anh', '(THPT Xuân Đỉnh)', 123456, 'congpham@gmail.com', '13', '2017-07-12 09:46:12', '', 'Em đăng kí thi ngành CNTT của trường mình, em chọn khối A1 thì cách xét điểm như thế nào ạ? Và em thi a1 có thiệt hơn khi xét tuyển những bạn thi a0 không ạ? Em cảm ơn anh/ chị/ thâỳ/ cô ạ!', NULL, NULL, NULL, NULL, NULL),
(269, 'Vũ Chí Tuấn Anh', '(THPT Xuân Đỉnh)', 123456, 'congpham@gmail.com', '7', '2017-07-12 09:44:57', '', 'Em đăng kí thi ngành CNTT của trường mình, em chọn khối A1 thì cách xét điểm như thế nào ạ? Và em thi a1 có thiệt hơn khi xét tuyển những bạn thi a0 không ạ? Em cảm ơn anh/ chị/ thâỳ/ cô ạ!', NULL, NULL, NULL, NULL, NULL),
(270, 'Vũ Chí Tuấn Anh', '(THPT Xuân Đỉnh)', 123456, 'congpham@gmail.com', '9', '2017-07-12 09:44:27', '', 'Em đăng kí thi ngành CNTT của trường mình, em chọn khối A1 thì cách xét điểm như thế nào ạ? Và em thi a1 có thiệt hơn khi xét tuyển những bạn thi a0 không ạ? Em cảm ơn anh/ chị/ thâỳ/ cô ạ!', NULL, NULL, NULL, NULL, NULL),
(271, 'Vũ Chí Tuấn Anh', '(THPT Xuân Đỉnh)', 123456, 'congpham@gmail.com', '12', '2017-07-12 09:43:46', '', 'Em đăng kí thi ngành CNTT của trường mình, em chọn khối A1 thì cách xét điểm như thế nào ạ? Và em thi a1 có thiệt hơn khi xét tuyển những bạn thi a0 không ạ? Em cảm ơn anh/ chị/ thâỳ/ cô ạ!', NULL, NULL, NULL, NULL, NULL),
(272, 'Nguyễn Thị Nga', '(Thpt Hoằng Hóa 3)', 123456, 'congpham@gmail.com', '8', '2017-07-12 09:41:47', '', 'Em chào thầy cô. Em muốn thi vào khoa kt31 thấy môn toán của năm 2016 là 8.5, cho em hỏi đó là điểm gì thế ạ. Có phải là điều kiện để vào khoa đó không ạ?', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tb_question` (`id`, `name_question`, `address_question`, `phone_question`, `email_question`, `type_question`, `time_question`, `title`, `question`, `rep_question`, `id_user`, `time_rep_question`, `time_public`, `rank_view`) VALUES
(273, 'Tăng Thị Mai Hương', '(THPT Gia Lộc 2)', 123456, 'congpham@gmail.com', '16', '2017-07-12 09:39:47', '', 'Khi đăng ký vào trước em có phải mua hồ sơ riêng của trường khó hay bọn em chỉ phải làm thủ tục như xét tuyển một bộ hồ sơ ở trường thôi ak em thấy một số trương các bạn đawnh ký vào phải mua hồ sơ của trường trường mình có phải thế không ak', NULL, NULL, NULL, NULL, NULL),
(274, 'Tăng Thị Mai Hương', '(THPT Gia Lộc 2)', 123456, 'congpham@gmail.com', '2', '2017-07-12 09:38:42', '', 'Khi đăng ký vào trước em có phải mua hồ sơ riêng của trường khó hay bọn em chỉ phải làm thủ tục như xét tuyển một bộ hồ sơ ở trường thôi ak em thấy một số trương các bạn đawnh ký vào phải mua hồ sơ của trường trường mình có phải thế không ak', NULL, NULL, NULL, NULL, NULL),
(275, 'Quốc Thái', '(Lê Quý Đôn)', 123456, 'congpham@gmail.com', '5', '2017-07-12 09:38:14', '', 'Em muốn đăng ký 2 nhóm ngành là Tự động hóa và điện tử truyèn thông ,mỗi nhóm ngành em đăng ký 2 khối là A00 và A01 là 4 nguyện vọng có được k ạ .Em cảm ơn.', NULL, NULL, NULL, NULL, NULL),
(276, 'Nguyễn Thị Thu Uyên', '(THPT chuyên Nguyễn Trãi)', 123456, 'congpham@gmail.com', '8', '2017-07-12 09:36:59', '', 'Em muốn hỏi là thi vào CTTT Công  nghệ thông tin Việt Nhật thì ngoài yêu cầu điểm trung bình của tổ hợp môn xé tuyển, điều kiện điểm môn toán thỳ có thêm điều kiện về điểm môn ngoại ngữ ko ạ. Em cảm ơn nhiều ạ =]]', NULL, NULL, NULL, NULL, NULL),
(277, 'dang ngoc hung', '(thpt nam dong quan)', 123456, 'congpham@gmail.com', '15', '2017-07-12 09:31:37', '', 'Em chao thay cô ạ. Sau tg tìm hiểu em rất thik vao nganh cơ điện tử cttt. Tieng Anh cua e chi o muc kha thôi. Thấy trong bài viết trường chỗ cttt sẽ công bố yêu cầu nhất định về trình độ tieng Anh, sau khi biet diem thi moi cong bo. Có phải nhu vay k a. Em cam on ak', NULL, NULL, NULL, NULL, NULL),
(278, 'Nguyễn Thị Thanh Nhàn', '(THPT Thạch Thất)', 123456, 'congpham@gmail.com', '11', '2017-07-12 08:39:48', '', 'cho em hỏi là ngành Quản trị kinh doanh – ĐH Victoria (New Zealand) cần tiếng anh phải >=4.5 ielts nhưng chưa đạt được thì  phải học bổ sung lớp Tiếng Anh. Vậy học phí bổ sung tiếng anh đẻ đạt được điều kiện ngoại ngữ là bao nhiêu vậy ạ?\n*câu hỏi 2 là: học phí ngành Quản trị kinh doanh – ĐH Victoria (New Zealand) 4 năm tầm bao nhiêu ạ?\n', NULL, NULL, NULL, NULL, NULL),
(279, 'Đinh Quang Anh', '(THPT Nho Quan C)', 123456, 'congpham@gmail.com', '11', '2017-07-12 08:33:10', '', 'Em năm nay thi được 7.2 toán, 6.25 lí, 6,75 hóa và có nguyện vọng vào học ở chương trình liên kết quốc tế của trường. vậy cho em hỏi điểm của em có cơ hội vào các ngành QT của trường không, mức học phí như thế nào vậy ạ? ', NULL, NULL, NULL, NULL, NULL),
(280, 'Trần thị thủy', '(Thạch thanh 2)', 123456, 'congpham@gmail.com', '8', '2017-07-12 08:29:08', '', 'E được toán 8.4 lý 7.5 hóa 7.5 điểm ưu tiên 1.5 vậy có khả năng đỗ QT14 không ạ? ', NULL, NULL, NULL, NULL, NULL),
(281, 'Vũ Đức Đông', '(THPT Lý Thái Tổ)', 123456, 'congpham@gmail.com', '8', '2017-07-12 08:26:10', '', 'Cho e hỏi là học phí chương trình đào tạo quốc tế QT11 là bao nhiêu trên một tín chỉ? và 1 năm cần bao nhiêu tín chỉ ạ', NULL, NULL, NULL, NULL, NULL),
(282, 'Bùi Thị Xuân Anh', '(THPT Thanh Hà)', 123456, 'congpham@gmail.com', '7', '2017-07-12 08:17:28', '', 'Ad có thể cho em hỏi một chút về chương trình đào tạo hệ quốc tế và học phí của trường được k ạ', NULL, NULL, NULL, NULL, NULL),
(283, 'Đinh Xuân Khải', '(Trường THPT Thạch Thành 3)', 123456, 'congpham@gmail.com', '15', '2017-07-12 08:02:59', '', 'Em muốn hỏi, em thấy tuyển sinh liên thông có đối tượng là tốt nghiệp cao đẳng chính quy của Trường ĐHBK Hà Nội. Nhưng Bách Khoa em chỉ thấy cao đẳng nghề. Vậy nếu tốt nghiệp cao đẳng nghề bách khoa có thể được xét liên thông lên đại học chính quy không ạ? Trong khoảng 3 năm tới liệu có thay đổi quy định hay không? Có phải thi tuyển lại không ạ? Năm nay em tốt nghiệp trung học phổ thông, muốn vào cao đẳng nghề bách khoa. Nếu 3 năm sau em muốn liên thông lên đại học chính quy có được không ạ?', NULL, NULL, NULL, NULL, NULL),
(284, 'lê thị trang', '(trần quang khải)', 123456, 'congpham@gmail.com', '6', '2017-07-11 22:21:46', '', 'điều khiển tự động và tự động hóa về chương trình đào tạo và việc làm sau này khác nhau ở chỗ nào ạ', NULL, NULL, NULL, NULL, NULL),
(285, 'đỗ văn liêm', '(triệu quang phục)', 123456, 'congpham@gmail.com', '3', '2017-07-11 22:14:58', '', 'dạ cho em hỏi:ngành điều khiển và tự động hóa của trường đào tạo chủ yếu về điện hay đòa tạo mạnh về các mạch điều khiển và tự động vậy ạ', NULL, NULL, NULL, NULL, NULL),
(286, 'Nguyễn Ngọc Huy', '(Trường THPT Chuyên - ĐH Vinh)', 123456, 'congpham@gmail.com', '2', '2017-07-11 22:11:38', '', 'Cho em hỏi CTTT Tự động hoá của trường mình học có như khoa Tự động hoá và có thể cung cấp thêm thông tin về khoa này được không ạ?', NULL, NULL, NULL, NULL, NULL),
(287, 'Nguyễn Trung Hiếu', '(THPT Thanh Oai B)', 123456, 'congpham@gmail.com', '11', '2017-07-11 22:05:57', '', 'Cho e hỏi là khoa tự động hóa và cơ điện tử thì ngành nào đang hot hơn và khả năng năm nay lấy điểm cao hơn ạ? E đang phân vân giữa 2 ngành và muốn biết rõ hơn để xếp thứ tự nguyện vọng ạ', NULL, NULL, NULL, NULL, NULL),
(288, 'Nguyễn Quốc Anh', '(THPT KIẾN AN)', 123456, 'congpham@gmail.com', '10', '2017-07-11 21:58:49', 'Tiêu đề Câu hỏi', 'Cho e hỏi là ngành Tự động hóa học về những gì và sau này ra trường thì làm những công việc như thế nào ạ? Và khi ra trường thì mức lương của công việc là bao nhiêu ạ? e xin cảm ơn!', NULL, NULL, NULL, NULL, NULL),
(289, 'Lê Minh Đức', '(Trường THPT Lê Hồng Phong)', 123456, 'congpham@gmail.com', '14', '2017-07-11 17:55:38', '', 'Em đăng ký nguyện vọng 1 vào quân đội nay biết  điểm thi rồi em muốn đổi nguyện vọng sang trường khác cũng ở trong quân đội có được không ạ?', NULL, NULL, NULL, NULL, NULL),
(290, 'Trịnh Hữu Dương', '(THPT Đào Duy Từ)', 123456, 'congpham@gmail.com', '14', '2017-07-11 17:37:10', '', 'Chào thầy, chào cô ạ, cho em hỏi em muốn thay đổi mã ngành đăng ký có được không ạ!', NULL, NULL, NULL, NULL, NULL),
(291, 'Chế ngoc̣ an', '(Truong thpt hung vuong.đơn dương.lâm đông̀)', 123456, 'congpham@gmail.com', '8', '2017-07-11 17:34:30', '', 'Diem thi thptqg nam2017 toi khong du diem vao dhbk. Toi co ba nam hoc sinh kha lop 10,11,12 co duoc xet tuyen vao dhbk kong. HUONG DAN CACH NOP HO SO', NULL, NULL, NULL, NULL, NULL),
(292, 'pham duc quang thanh', '(bắc kiến xương huyện kiến xương tỉnh thái bình )', 123456, 'congpham@gmail.com', '14', '2017-07-11 17:21:24', '', 'em muon thay doi nguyenj vọng 1 quan doi truong hoc vien phòng khong khong quan băng truong giao thong van tai la nguyen vong 1  thì phai lam the nào ', NULL, NULL, NULL, NULL, NULL),
(293, 'Huyền', '(Hàn Thuyên )', 123456, 'congpham@gmail.com', '11', '2017-07-11 16:54:30', '', 'Cho em hỏi ngành qt41 học phí 1 năm học là bao nhiêu ạ .  Ngành này có học theo tín chỉ k ạ     Năm đầu có phải học hoàn toàn bằng tiền anh k .và chỉ tiêu xét học bổng của ngành như thế nào ạ .em cảm ơn', NULL, NULL, NULL, NULL, NULL),
(294, 'Nguyễn Hiền', '(THPT Kinh Môn)', 123456, 'congpham@gmail.com', '16', '2017-07-11 16:50:08', '', 'Cho em hỏi: thông tin về ngành QT21(quản trị kinh doanh -ĐH Victoria) , về học phí và chương trình đào tạo ạ', NULL, NULL, NULL, NULL, NULL),
(295, 'Hoàng văn Tường', '(THPT Hậu Lộc 4)', 123456, 'congpham@gmail.com', '7', '2017-07-11 16:39:30', '', 'Phương thức tuyển sinh của trường mình là như thế nào ạ và bao nhiêu điểm thì đủ để xét tuyển ạ . ', NULL, NULL, NULL, NULL, NULL),
(296, 'Nguyễn Hữu Phước', '(Trường Trung cấp nghề Đức Hòa)', 123456, 'congpham@gmail.com', '4', '2017-07-11 16:34:18', '', 'Kính xin quý trường cho em hỏi. Năm 2017 về phía trường có liên kết đào tạo trình độ thạc sỹ ngành công nghệ dệt may với trường nào ở TPHCM hay không ạ? E là giáo viên đã tốt nghiệp đại học và hiện tại đang công tác ở trường trung cấp nghề Đức Hòa. Kính mong quý trường trả lời sớm giúp.', NULL, NULL, NULL, NULL, NULL),
(297, 'Đặng Huy', '(THPT Huỳnh Thúc Kháng)', 123456, 'congpham@gmail.com', '9', '2017-07-11 16:32:32', '', 'Em muốn nộp học bạ xét tuyển vào trường thì làm thế nào ạ?', NULL, NULL, NULL, NULL, NULL),
(298, 'Nguyễn Thị Thùy Trang', '(THPT Chuyên khoa học tự nhiên - ĐHQGHN)', 123456, 'congpham@gmail.com', '2', '2017-07-11 14:09:16', '', 'Hiện tại em đang là sinh viên năm 3 của ĐHQGHN. Thầy cô cho em hỏi là nếu em tốt nghiệp ĐH xong. Có cơ hội học văn bằng hai ngành CNTT của ĐHBK không ạ, và nếu học thì mức học phí như thế nào và học trong bao lâu ạ. Em cảm ơn !', NULL, NULL, NULL, NULL, NULL),
(299, 'thang', '(thpt tiên lãng )', 123456, 'congpham@gmail.com', '2', '2017-07-11 14:06:32', '', 'chào thầy cô , cho em xin thông tin về lịch tuyển sinh văn bằng 2 của trường năm 2017 được không ạ , em không thấy thông tin của năm nay và em muốn đăng ký học thì phải làm thủ tục như thế nào ạ?', NULL, NULL, NULL, NULL, NULL),
(300, 'Nguyễn Văn Mạnh ', '(thpt vĩnh bảo)', 123456, 'congpham@gmail.com', '11', '2017-07-11 13:52:12', '', 'năm nay trường mình có tổ chức mở lớp văn bằng 2 hệ chính quy không ạ ?', NULL, NULL, NULL, NULL, NULL),
(301, 'Đào minh tuấn', '(Thpt yên lãng)', 123456, 'congpham@gmail.com', '8', '2017-07-11 13:50:49', '', 'Em tốt nghiệp chuyên ngành kinh tế bcvt, của trg dh giao thông vận tải.\nEm muốn học vb2 ngành điều khiển - tự động hóa dc ko a? \nMong a/c chỉ tư vấn giúp em. \nCảm ơn a/c .', NULL, NULL, NULL, NULL, NULL),
(302, 'nguyễn tuấn anh', '(trường thpt thanh oai a)', 123456, 'congpham@gmail.com', '13', '2017-07-11 13:46:01', '', 'em chào thầy(cô). Em xin hỏi hệ vừa làm vừa học có nghành kỹ thuật cơ điện tử, em muốn học thì cần làm những thủ tục(giấy tờ) gì ạ? học xong chương trình đào tạo thì được nhận chứng chỉ hay cấp bằng kỹ sư ạ? em cám ơn.', NULL, NULL, NULL, NULL, NULL),
(303, 'nguyen trang', '(ktqd)', 123456, 'congpham@gmail.com', '16', '2017-07-11 13:43:31', '', 'em muốn hỏi lịch nộp hồ sơ văn bằng 2 là khi nào a? em cám ơn', NULL, NULL, NULL, NULL, NULL),
(304, 'Huy Hoàng', '(Hà Nội)', 123456, 'congpham@gmail.com', '4', '2017-07-11 13:43:03', '', 'Chào Thầy Cô, Hiện e đã tốt nghiệp đại học thuộc khối ngành kĩ thuật muốn thi tuyển VB2 của trường, không biết trường có những Ngành nghề nào tuyển sinh? và có phải thi tuyển ko ạ? Thời gian đăng kí như thế nào ạ? E xin cảm ơn!', NULL, NULL, NULL, NULL, NULL),
(305, 'Nguyễn thị Trang', '(Quãng xương 3)', 123456, 'congpham@gmail.com', '8', '2017-07-11 13:41:28', '', 'Cho em hỏi về hồ sơ xét tuyển học bạ của trường cần những gì và thời gian nộp hồ sơ là khi nào ạ', NULL, NULL, NULL, NULL, NULL),
(306, 'Bùi Trần Yến Linh', '(Quốc Học Quy Nhơn)', 123456, 'congpham@gmail.com', '14', '2017-04-23 15:13:18', '', 'Chào thầy cô ạ, cho em hỏi sự khác nhau giữa ngành hóa học, kĩ thuật hóa học và công nghệ kĩ thuật hóa học là gì vậy ạ? Ngành nào lúc học có kiến thức lí thuyết, thực hành giống với 1 kỹ sư hóa dầu làm nhất ạ? Và ngành nghề này hợp với nữ không ạ. Em cảm ơn.', NULL, NULL, NULL, NULL, NULL),
(307, 'Bùi Trần Yến Linh', '(Quốc Học Quy Nhơn)', 123456, 'congpham@gmail.com', '15', '2017-04-23 15:12:09', '', 'Chào thầy cô, em có câu hỏi: ngành hóa học có phải thiên về nghiên cứu hơn là ngành kỹ thuật hóa học phải không ạ? Và  sự khác nhau cơ bản giữa ngành hóa học và ngành kỹ thuật hóa học là gì vậy ạ? Ngành nào khi học gần với công việc của một kĩ sư hóa lọc dầu hơn ạ? Em cảm ơn thầy cô ạ.', NULL, NULL, NULL, NULL, NULL),
(308, 'Nguyễn Công Quyền', '(THPT Huỳnh Thúc Kháng)', 123456, 'congpham@gmail.com', '16', '2017-04-22 21:18:55', '', 'Cho em hỏi năm nay khoa CNTT không chia thành 2 nhánh Kĩ sư với cử nhân như năm ngoái nữa ạ ?', NULL, NULL, NULL, NULL, NULL),
(309, 'Phan Tùng', '(Phan Châu Trinh)', 123456, 'congpham@gmail.com', '8', '2017-04-22 21:16:21', '', 'cho e hỏi ngành công nghệ kỹ thuật hóa học khi tham gia học sẽ có từng chuyên ngành riêng ko??? nếu có thì các chuyên ngành đó là gì và tổ hợp môn xét tuyển cho từng chuyên ngành. E cảm ơn!!', NULL, NULL, NULL, NULL, NULL),
(310, 'Đỗ Hải Anh', '(THPT Yên Lãng)', 123456, 'congpham@gmail.com', '2', '2017-04-22 21:10:19', '', 'Ad cho e hỏi ngành kĩ thuật in và truyền thông sau khi học xong ra trường sẽ làm gì ạ ? \nem xin cảm ơn', NULL, NULL, NULL, NULL, NULL),
(311, 'đậu đinhf sơn', '(phan đăng lưu)', 123456, 'congpham@gmail.com', '6', '2017-04-22 21:07:58', '', 'em muốn đăng kí 1 nguyện vọng vào cttt công nghệ thông tin việt-nhật/ict  thì phải có điều kiện gì về ngoại ngử  trước khi đăng kí nghành này không', NULL, NULL, NULL, NULL, NULL),
(312, 'Đỗ Ngọc Minh', '(Trường THPT Nông Cống 1)', 123456, 'congpham@gmail.com', '6', '2017-04-22 21:05:55', '', 'Số tín chỉ và chương trình đào tạo của ngành công nghệ thông tin là như thế nào  ạ\n', NULL, NULL, NULL, NULL, NULL),
(313, 'Nguyễn Trọng Đức', '(THPT Lương Đắc Bằng)', 123456, 'congpham@gmail.com', '14', '2017-04-22 21:01:55', '', 'Em chòa thầy ạ.Em có ý định thi vào ngành cơ điện tử thì nếu sau khi trúng tuyển vào nhóm ngành KT11 này, nhà trường sẽ phân ngành cho em vào ngành nào ạ.và dựa vào những yếu tố nào để phân ngành ạ.\nEm xin cảm ơn', NULL, NULL, NULL, NULL, NULL),
(314, 'Nguyễn Luân', '(THPT Quảng Oai)', 123456, 'congpham@gmail.com', '3', '2017-04-22 20:59:45', '', 'Thưa thầy !! Kt điện điện tử với kt cơ điện tử công việc cụ thể là làm gì sẽ làm ở đâu cơ hội thăng tiến ra sao....e nên theo học ngành nào bây giờ .', NULL, NULL, NULL, NULL, NULL),
(315, 'Trần Minh Đại', '(Trường THPT Nguyễn Quán Nho)', 123456, 'congpham@gmail.com', '9', '2017-04-22 20:34:14', '', 'Thưa thầy, định đăng ký vào hoc ngành kỹ thuât ô tô (cơ khí - động lực) mà không thích 5 ngành còn lại). NẾU EM ĐĂNG KÝ VÀ TRÚNG TUYỂN nhóm ngành này (mà những người có nguyện vọng như em quá nhiều trong tổng số 900 chỉ tiêu) liệu nhà trường có đáp ứng được nguyện vọng của em và các bạn khác như em không ạ. nếu phải chuyển qua ngành không có đam mê thì em sẽ hết hy vong vào các trường khác?', NULL, NULL, NULL, NULL, NULL),
(316, 'Đức', '(Văn Giang)', 123456, 'congpham@gmail.com', '6', '2017-04-22 20:32:37', '', 'Điều kiện để được học ngành kỹ thuật hàng không là gì ạ?\n', NULL, NULL, NULL, NULL, NULL),
(317, 'Dương Hồng Sơn', '(Trường THPT Dương Quảng Hàm)', 123456, 'congpham@gmail.com', '15', '2017-04-22 13:52:49', '', 'Thầy cô có thể giới thiệu cho em về chương trình Kĩ sư tài năng công nghệ thông tin được không ạ (về chỉ tiêu tuyển sinh, chỉ tiêu tuyển sinh thẳng, chương trình học)? ', NULL, NULL, NULL, NULL, NULL),
(318, 'Ngọc Hà', '(Thái Phiên)', 123456, 'congpham@gmail.com', '16', '2017-04-20 11:57:35', '', ' Thầy cô cho em hỏi là CTTT Việt Nhật của trường mình học phí là năm đầu 460.000/ 1 tín chỉ. Mỗi năm tăng dần là 500.000/1 tín và 540.000/ 1 tín. Mỗi năm học phí dao động từ 23 triệu và tăng dần đến mức 30 triệu 1 năm phải không ạ. Và em muốn hỏi là ngoài học phí em còn có phải nộp thêm khoản phí nào không ạ.Vd: tiền học tiếng Nhật hoặc Tiếng Anh ạ. Và nếu phải thi lại thì nhà trường sẽ tính bao nhiêu 1 tín ạ. Em xin cảm ơn thầy cô ạ', NULL, NULL, NULL, NULL, NULL),
(319, 'tạ hiếu', '(Lê quý đôn - đống đa)', 123456, 'congpham@gmail.com', '3', '2017-04-19 14:35:00', '', 'Thầy ơi, cho em hỏi, CTTT cơ điện tử làm thế nào để đỗ ạ, nó có xét khối A1 như các ngành khác không ạ? Ngoài việc đạt điểm chuẩn của ngành thì cần điều kiện gì nữa mới đỗ ạ? Em cảm ơn ạ', NULL, NULL, NULL, NULL, NULL),
(320, 'Nguyễn Minh Anh', '(Trường THPT chuyên tỉnh Sơn La)', 123456, 'congpham@gmail.com', '8', '2017-04-19 14:34:17', '', 'Em xin hỏi em muốn đăng ký dự tuyển chương trình tiên tiến thì sau khi trúng tuyển em bắt buộc phải thi kiểm tra tiếng anh ạ, nếu không qua được môn tiếng anh em phải làm thế nào ạ ', NULL, NULL, NULL, NULL, NULL),
(321, 'Hoàng Văn Nam', '(Nam Định)', 123456, 'congpham@gmail.com', '2', '2017-04-19 14:31:53', '', 'cho em hỏi là năm nay trường mình có giới hạn chỉ tiêu tuyển thẳng cho ngành TT22 không ạ?', NULL, NULL, NULL, NULL, NULL),
(322, 'Bùi Tú Hà', '(Hà Nội - Amsterdam)', 123456, 'congpham@gmail.com', '12', '2017-04-19 11:43:19', '', 'Nếu em được giải ba quốc gia Vật lý có được tuyển thẳng năm nay không ạ. Nếu có thì cho em xin link tải mẫu đơn và các ngành tuyển thẳng ạ. Em cảm ơn ạ :))', NULL, NULL, NULL, NULL, NULL),
(323, 'Nguyễn Giang', '(chuyên Phan Bội Châu)', 123456, 'congpham@gmail.com', '16', '2017-04-19 11:33:02', '', 'Theo công văn 603 về tuyển thẳng thì yêu cầu em phải in phụ lục 3, còn theo yêu cầu của trường thì in mẫu khác. Vậy em phải làm thế nào ạ?', NULL, NULL, NULL, NULL, NULL),
(324, 'Đỗ Hoàng An', '(THPT Chuyên Hạ Long)', 123456, 'congpham@gmail.com', '9', '2017-04-19 11:08:41', '', 'Em được giải 3 quốc gia vật lý. Em đăng ký tuyển thẳng vào mã ngành KT24 được không? Trường có giới hạn số lượng học sinh tuyển thẳng không?', NULL, NULL, NULL, NULL, NULL),
(325, 'Nguyễn Mạnh Cường', '(THPT chuyên Nguyễn Trãi)', 123456, 'congpham@gmail.com', '3', '2017-04-19 11:00:02', '', 'Em có giải khuyến khích quốc gia môn tin học thì khi đăng kí vào khoa công nghệ thông tin của trường có được cộng điểm không ạ? Nếu có thì được cộng bao nhiêu và làm thế nào để được ưu tiên ạ?', NULL, NULL, NULL, NULL, NULL),
(326, 'Nguyễn Hồng Quân', '(Trường THPT Hoài Đức B)', 123456, 'congpham@gmail.com', '15', '2017-04-19 10:46:15', '', 'em ở khu vực 2 thuộc hộ nghèo thì học CTTT Công nghệ thông tin Việt Nhật/ICT thì có được giảm học phí không ạ?', NULL, NULL, NULL, NULL, NULL),
(327, 'lê tuấn anh', '(thpt phùng khắc khoan)', 123456, 'congpham@gmail.com', '13', '2017-04-19 10:43:35', '', 'e có 1 số câu hỏi muốn hỏi trực tiếp viện cơ điện tử thì đến đâu để trao đổi ạ', NULL, NULL, NULL, NULL, NULL),
(328, 'Lê Linh', '(THPT Vũ Văn Hiếu)', 123456, 'congpham@gmail.com', '2', '2017-04-19 09:35:30', '', 'Cho em hỏi mức học phí của QT33 Quản trị kinh doanh - ĐH Pierre Mendes France (Pháp) khoảng bao nhiêu ạ?', NULL, NULL, NULL, NULL, NULL),
(329, 'Bùi Thị Hằng', '(Thành Đô)', 123456, 'congpham@gmail.com', '11', '2017-04-19 08:16:34', '', 'Em đã có bằng cao đẳng ngành công nghệ thông tin. Em muốn liên thông lên Đại học bách khoa được không ạ?\n', NULL, NULL, NULL, NULL, NULL),
(330, 'Trần Kim HIển', '(Chuyên Hùng Vương)', 123456, 'congpham@gmail.com', '3', '2017-04-19 08:06:14', '', 'Thầy cho em hỏi nếu em được giải nhì cuộc thi violimpic toán quốc gia thì em có được xét tuyển thẳng vào 1 ngành nào đó của trường không ạ?', NULL, NULL, NULL, NULL, NULL),
(331, 'Đinh Phương Nam', '(Lê Hồng Phong - Nam Định)', 123456, 'congpham@gmail.com', '16', '2017-04-19 07:52:33', '', 'Em xin chào các thầy cô giáo! Em bị khuyết tật đặc biệt nặng, đang học tại trường Lê Hồng Phong - Nam Định. Em có nguyện vọng thi vào ngành cử nhân công nghệ thông tin của trường, nhưng hơi lo là không đỗ; em muốn làm hồ sơ ưu tiên xét tuyển. Em xin hỏi:\nHồ sơ ưu tiên xét tuyển gồm những gì, mua ở đâu, thời gian nộp hồ sơ, nộp ở đâu?\nNếu được ưu tiên xét tuyển em có được học đúng nguyện vọng hệ cử nhân công nghệ thông tin không ạ?\n', NULL, NULL, NULL, NULL, NULL),
(332, 'Trương như quyết', '(Diễn châu 3)', 123456, 'congpham@gmail.com', '15', '2017-04-18 15:05:52', '', 'Thầy cô cho e hỏi chút ạ:naem nay đăng ký thi vào trường mình ,nhưng khi ghi hồ sơ e viết phần đăng ký nhóm ngành có 2 ngành trong cùng 1 nhóm, vậy khi em bỏ 1 nhóm ngành thì sau này, khi e đậu vào trường thì bắt buộc phải học ngành mình ghi teong hồ sơ hay được nộp đơn phân ngành vào ngành khác trong nhóm ngành đó không ạ', NULL, NULL, NULL, NULL, NULL),
(333, 'Phạm Xuân Nam', '(Yên Mô A)', 123456, 'congpham@gmail.com', '11', '2017-04-18 14:53:44', '', 'Em muốn thi công nghệ thông tin nhưng thấy có chỉ tiêu điểm toán trên 8.5 e muốn hỏi đó là chỉ tiêu chính để xét ạ', NULL, NULL, NULL, NULL, NULL),
(334, 'Nguyễn Nguyên', '(ĐTA)', 123456, 'congpham@gmail.com', '2', '2017-04-18 14:51:13', '', 'Cho em hỏi là xét tuyển vào BKA cùng 1 ngành mà khác khối thì điểm vẫn như nhau ạ???\nVà KT31 xét tuyển những khối nào v ạ?', NULL, NULL, NULL, NULL, 11),
(335, 'Vũ Văn Mạnh', '(Kim Thành)', 123456, 'congpham@gmail.com', '16', '2017-04-18 14:49:03', '', 'thầy cô cho em hỏi nếu năm đầu đủ điểm khoa cơ khí động lực thì năm thứ hai có thể học khoa cơ điện tử theo kết quả bài thi cuối năm thứ nhất hay không', NULL, NULL, NULL, NULL, 10),
(336, 'Nguyễn Thịnh', '(THPT Hoài Đức A)', 123456, 'congpham@gmail.com', '11', '2017-04-18 14:46:42', '', 'Thưa thầy, cô\nSau khi em trúng tuyển vào một nhóm ngành của trường thì việc phân ngành là dựa trên nguyện vọng của thí sinh và kết quả thi THPT ạ?', NULL, NULL, NULL, NULL, 9),
(337, 'Nguyễn Cảnh Tiến', '(THPT Lê Viết Thuật)', 123456, 'congpham@gmail.com', '7', '2017-04-18 14:03:06', '', 'Cho em hỏi năm nay Ngành Công Nghệ thông tin chỉ tuyển cử nhân chứ ko tuyển kĩ sư như năm ngoái nữa ạ ?', NULL, NULL, NULL, NULL, 8),
(338, 'nguyễn văn đức', '(anh sơn 2 )', 123456, 'congpham@gmail.com', '12', '2017-04-18 14:00:52', '', 'e muốn hỏi là đăng kí nguyện vọng vào trường thì đăng kí theo nhóm ngành rồi lúc vào trường mới phân ngành hay là đăng kí ngành luôn ạ.\n', NULL, NULL, NULL, NULL, 7),
(339, 'Nguyễn Văn Tiến', '(Trường THPT Cẩm Lý)', 123456, 'congpham@gmail.com', '14', '2017-04-18 13:58:09', '', 'Thầy cho em hỏi: Hiện nay em học yếu môn Tiếng Anh nhưng em muốn đăng kí vào học chương trình CTTT Công nghệ thông tin Việt - Nhật (Tiếng Việt), liệu em có học được chương trình này không ạ?', NULL, NULL, NULL, NULL, 6),
(340, 'Nguyễn Thị Hiền', '(Thiệu Hóa)', 123456, 'congpham@gmail.com', '5', '2017-04-18 13:56:20', '', 'Nghành QT41 e lỡ ghi vào hồ sơ là Quản lí hệ thống công nghiệp vì năm ngoái ghi vậy. Nhưng năm nay tên là Kỹ thuật hệ thống công nghiệp, vậy e có phải sửa lại k ạ. Cứ để như thế có bị loại hồ sơ k ạ', NULL, NULL, NULL, NULL, 5),
(341, 'Quốc Thái', '(Lê Quý Đôn Đống Đa)', 123456, 'congpham@gmail.com', '4', '2017-04-18 10:09:29', '', 'Dạ thưa thầy cô em muốn hỏi là em đăng ký 2 nhóm ngành là tự đông hóa và điện tử truyền thông ,mỗi nhóm nghành em đăng ký 2 khối là A00 và A01 thành 4 nguyện vọng khác nhau được không ạ .Em cảm ơn ạ.', NULL, NULL, NULL, NULL, 4),
(342, 'nguyên nghiêm huy hoàng', '(phoorthoong trung học hoài đức a )', 123456, 'congpham@gmail.com', '11', '2017-04-17 07:56:34', '', 'trong kỳ tuyển sinh năm nay, e đăng ký nguyện vong 1 là trường quân sự, nguyện vọng 2 là trường bách khoa, không biết năm nay trường bách khoa có xét đến nguyện vọng 2 không , hay chỉ xét hết nguyện vọng 1 , nếu thiếu mới xét đến nguyện vọng 2', NULL, NULL, NULL, NULL, 4),
(343, 'Trần quang khải', '(Chuyên hoàng văn thụ)', 123456, 'congpham@gmail.com', '4', '2017-04-17 07:55:07', '', 'Cho em hỏi lớp chất lượng cao hệ thống thông tin và truyền thông thuộc nhóm ngành nào ạ', NULL, NULL, NULL, NULL, 3),
(344, 'Đặng Thai Hùng', '(THPT Qùy Hợp 2)', 123456, 'congpham@gmail.com', '14', '2017-04-16 16:10:40', '', 'Kính thưa quý nhà truòng làm ơn cho em hỏi ngành kĩ thuật y sinh sau khi học xong ra trường sẽ làm những gì ạ? và có khả năng tìm được việc làm ngay sau khi ra trường không ạ?\n', NULL, NULL, NULL, NULL, 2),
(345, 'Nguyễn Thị Hồng ', '(Trường THPT Hiệp Hòa số 1)', 123456, 'congpham@gmail.com', '10', '2017-04-16 16:01:38', '0 0 20 0  ', 'E muốn thi ngành kĩ thuật điện tử viễn thông của trường nhưng chưa hiểu lắm về ngành này và chưa biết cách tính điểm của trường. Thầy cô có thể trả lời giúp e được không ạ?', NULL, NULL, NULL, NULL, 2),
(346, 'Hoàng Trung Dũng', '(THPT Chuyên khoa học tự nhiên)', 123456, 'congpham@gmail.com', '4', '2017-04-16 13:26:42', '0 0 0 0 0 0 0 0 0', 'Thầy ơi cho em hỏi, lớp 12 em được giải nhì môn toán,theo tiêu chí của trường thì em được tuyển thẳng , và em muốn chọn khoa kstn và TT ICT thầy cho em hỏi khoa kstn có trao đổi sinh viên với các nước như khoa TTICT không. Và nếu em đăng ký khoa kstn vào NV xét tuyển thẳng thì đăng ký như thế nào?. Mong thầy tư vấn cho em.', NULL, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_room`
--

CREATE TABLE `tb_room` (
  `id` int(11) NOT NULL,
  `name_room` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `keyword` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='tb_room';

--
-- Dumping data for table `tb_room`
--

INSERT INTO `tb_room` (`id`, `name_room`, `keyword`) VALUES
(2, 'Ban tư vấn', 'BTV'),
(3, 'Viện cơ khí', 'ViệnCK'),
(4, 'Viện cơ khí động lực', 'Viện CKĐL'),
(5, 'Viện Công nghệ Sinh học và Công nghệ Thực phẩm', 'Viện CNSH&TP'),
(6, 'Viện Công nghệ Thông tin và Truyền thông', 'Viện CNTT&TT'),
(7, 'Viện Dệt may - Da giầy và Thời trang', 'Viện DM-DG&TT'),
(8, 'Viện Khoa học và Công nghệ Môi trường', 'Viện KH&CNMT'),
(9, 'Viện Khoa học và Công nghệ nhiệt lạnh', 'Viện KH&CNNL'),
(10, 'Viện Khoa học và Kỹ thuật Vật liệu', 'Viện KH&KTVL'),
(11, 'Viện Kinh tế và Quản lý', 'Viện KT&QL'),
(12, 'Viện Kỹ thuật hạt nhân và Vật lý môi trường', 'Viện KTHN&VLMT'),
(13, 'Viện Kỹ thuật Hóa học', 'Viện KTHH'),
(14, 'Viện Kỹ thuật Điều khiển và Tự động hóa', 'Viện KTĐK&TĐH'),
(15, 'Viện Ngoại ngữ', 'Viện NN'),
(16, 'Viện Sư phạm Kỹ thuật', 'Viện SPKT'),
(17, 'Viện Toán ứng dụng và Tin học', 'Viện TƯD&TH');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id` int(11) UNSIGNED NOT NULL,
  `username` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fullname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` text COLLATE utf8_unicode_ci,
  `add_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id`, `username`, `password`, `email`, `fullname`, `level`, `add_date`) VALUES
(1, 'phamcong', '9c7ee3719618163c909296a1f1a16d7d', 'phamvancong@hust.edu.vn', 'Phạm Văn ', '2,4,5,6', NULL),
(2, 'phamvancong', 'd5f803faf52da3a75bb35f6ebfff52b1', 'phamvancong1@hust.edu.vn', 'Công', '4,5,7', NULL),
(3, 'vien1', 'f778a9253775eed1b8ce358ef0056725', 'vien1@hust.edu.vn', 'viện1', '3', NULL),
(4, 'vien2', 'aa2cd8611382547582f45b0b645cb7a6', 'vien2@hust.edu.vn', 'Viện2', '4', NULL),
(5, 'vien3', '0de8ab84ef7f7918161112dc67cb1467', 'vien3@hust.edu.vn', 'viện 3', '4', NULL),
(6, 'vien4', '7341400ca51609eb091e7d8a7ec2bfe4', 'vien4@hust.edu.vn', 'viện 4', '6', NULL),
(7, 'vien5', '8ff4ecebf4eafecc84ce0991f5540b59', 'vien5@hust.edu.vnq', 'viện5', '7', NULL),
(8, 'vien6', 'f147e5d57fdbd64dbff05790356f264d', 'vien6@hust.edu.vn', 'viêkn6', '8', NULL),
(9, 'vien7', 'd00f47933156794b6b8ca0333b93a211', 'vienjdskfjdks@gmail.com', 'coaoaa', '2,4,7', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vocabulary`
--

CREATE TABLE `vocabulary` (
  `ID` int(11) UNSIGNED NOT NULL,
  `Words` text COLLATE utf8_unicode_ci NOT NULL,
  `NewWords` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vocabulary`
--

INSERT INTO `vocabulary` (`ID`, `Words`, `NewWords`) VALUES
(44, 'nguye', 'Nguyễn'),
(49, 'cntt', 'CNTT&TT'),
(70, 'chường', 'trường'),
(73, 'họk sih', 'học sinh'),
(83, 'đếch', ''),
(90, 'méo', ''),
(97, 'bkhn', 'Bách Khoa Hà Nội');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_question`
--
ALTER TABLE `tb_question`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `tb_room`
--
ALTER TABLE `tb_room`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tb_question`
--
ALTER TABLE `tb_question`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=347;
--
-- AUTO_INCREMENT for table `tb_room`
--
ALTER TABLE `tb_room`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
