<?php  
	 include 'connect.php';
	 $sql = "SELECT * FROM tb_user ORDER BY id ASC";  
	 $result = mysqli_query($connect, $sql);  
	 $output = '
		  <div class="table-responsive">  
			   <table class="table table-bordered">  
					<tr>  
						 <th width="5%">Id</th>  
						 <th width="20%">Tên đăng nhập</th> 
						 <th width="20%">Email</th>
						 <th width="20%">Phân quyền trả lời</th>  
						 <th width="20%">Tên đầy đủ</th>
						   
					</tr>';  
	 if(mysqli_num_rows($result) > 0)  
	 {  
		  while($row = mysqli_fetch_array($result))  
		  {  
			   $output .= '  
					<tr id="tr_'.$row["id"].'">  
						 <td>'.$row["id"].'</td>  
						 <td class="username" data-id1="'.$row["id"].'" id="username_'.$row["id"].'" contenteditable="false">'.$row["username"].'</td>
						 <td class="email" data-id2="'.$row["id"].'" id="email_'.$row["id"].'" contenteditable="false">'.$row["email"].'</td> 
						 <td class="level" data-id3="'.$row["id"].'" id="select_'.$row["id"].'">
							 <select class="text_sel" name="type_question" id="select_room_'.$row["id"].'" multiple style="width: 200px;> 
							<option value="1">Tổ hỗ trợ câu hỏi</option>';
							 try{
								$sql_select_room="SELECT * from tb_room ORDER BY id";
								$dl_room=mysqli_query($connect, $sql_select_room);
								}catch (PDOException $e){
									die("lỗi" . $e->getMessage());
								}
								while($row_1 = mysqli_fetch_array($dl_room)){
									$output .='<option value='.$row_1['id'].'>'.$row_1['keyword'].'</option>';
								}
						$output .='
						</select>
						<script>
							  $(function(){
								  $("#select_room_'.$row["id"].'").multiselect({
									  includeSelectAllOption: true
									  });
							});
							$("#select_room_'.$row["id"].' option").prop("disabled", true);
							var data="'.$row["level"].'";
							var dataarray=data.split(",");
							$("#select_room_'.$row["id"].'").val(dataarray);
							$("#select_room_'.$row["id"].'").multiselect("refresh");
							
						</script>
						 </td>
						 <td class="fullname" data-id4="'.$row["id"].'" id="fullname_'.$row["id"].'" contenteditable="false">'.$row["fullname"].'</td>
						 <td>
						 	<button type="button" name="edit_btn" data-id5="'.$row["id"].'" class="btn btn-xs btn-danger btn_edit_user" id="edit_user_'.$row["id"].'">sửa</button>
							<button type="button" name="save_btn" data-id51="'.$row["id"].'" class="btn btn-xs btn-success btn_save_user" id="save_user_'.$row["id"].'" style="display:none" >lưu</button>
						</td>  
						 <td>
						 	<button type="button" name="delete_btn" data-id6="'.$row["id"].'" class="btn btn-xs btn-danger delete_user" id="delete_user_'.$row["id"].'">x</button>
							<button type="button" name="reset_btn" data-id61="'.$row["id"].'" class="btn btn-xs btn-success reset_user" id="reset_user_'.$row["id"].'" style="display:none">reset MK</button>
						</td>  
					</tr>  
			   ';  
		  }  
		  $output .= '  
			   <tr>  
					<td></td>  
					<td id="user_name_add" contenteditable=></td> 
					<td id="email_add" contenteditable></td>
					<td>
						<select class="text_sel" name="type_question" id="select_room" multiple style="width: 50px"> 
						<option value="1">Tổ hỗ trợ câu hỏi</option>';
						 try{
							$sql_select_room="SELECT * from tb_room ORDER BY id";
							$dl_room=mysqli_query($connect, $sql_select_room);
							}catch (PDOException $e){
								die("lỗi" . $e->getMessage());
							}
							while($row = mysqli_fetch_array($dl_room)){
								$output .='<option value='.$row['id'].'>'.$row['keyword'].'</option>';
							}
					$output .='
					</select>
					<script>
						  $(function(){
							  $("#select_room").multiselect({
								  includeSelectAllOption: true
								  });
						});
					</script>
					</td>
					 
					<td id="fullname_add" contenteditable></td>
					<td><button type="button" name="btn_add" id="btn_add_user" class="btn btn-xs btn-success">+</button></td>  
			   </tr>
		  ';  
	 }  
	 else  
	 {  
		  $output .= '
		  <tr>  
					<td></td>  
					<td id="user_name_add" contenteditable="false"></td> 
					<td id="email_add" contenteditable="false"></td>
					<td>
						<select class="text_sel" name="type_question" id="select_room" multiple style="width: 50px"> 
						<option value="1">Tổ hỗ trợ câu hỏi</option>';
						 try{
							$sql_select_room="SELECT * from tb_room ORDER BY id";
							$dl_room=mysqli_query($connect, $sql_select_room);
							}catch (PDOException $e){
								die("lỗi" . $e->getMessage());
							}
							while($row = mysqli_fetch_array($dl_room)){
								$output .='<option value='.$row['id'].'>'.$row['keyword'].'</option>';
							}
					$output .='
					</select>
					<script>
						  $(function(){
							  $("#select_room").multiselect({
								  includeSelectAllOption: true
								  });
						});
					</script>
					</td>
					 
					<td id="fullname_add" contenteditable="false"></td>
					<td><button type="button" name="btn_add" id="btn_add_user" class="btn btn-xs btn-success">+</button></td>  
			   </tr>
		  <tr>
		  				<td colspan="4">Data not Found</td>
					</tr>';  
	 }  
	 $output .= '</table>  
	
		  </div>
		  ';  
	 echo $output;  
	 mysqli_close($connect);
 ?>