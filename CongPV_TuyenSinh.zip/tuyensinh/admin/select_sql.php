<?php  
	 include 'connect.php';
	 $sql = "SELECT * FROM tb_room ORDER BY id ASC";  
	 $result = mysqli_query($connect, $sql);  
	 $output = '  
		  <div class="table-responsive">  
			   <table class="table table-bordered">  
					<tr>  
						 <th width="10%">Id</th>  
						 <th width="40%">Viện</th>
						 <th width="40%">Viết Tắt</th>
						 <th width="10%">Delete</th>  
					</tr>';  
	 if(mysqli_num_rows($result) > 0)  
	 {  
		  while($row = mysqli_fetch_array($result))  
		  {  
			   $output .= '  
					<tr>  
						 <td>'.$row["id"].'</td>  
						 <td class="name_room" data-id1="'.$row["id"].'" id="name_id'.$row["id"].'" contenteditable="false">'.$row["name_room"].'</td> 
						 <td class="key_room" data-id3="'.$row["id"].'" id="key_id'.$row["id"].'" contenteditable="false">'.$row["keyword"].'</td>
						 <td><button type="button" name="delete_btn" data-id2="'.$row["id"].'" class="btn btn-xs btn-danger btn_delete">x</button></td>  
					</tr>  
			   ';  
		  }  
		  $output .= '  
			   <tr>  
					<td></td>  
					<td id="name_room_add" contenteditable></td> 
					<td id="key_room_add" contenteditable></td> 
					<td><button type="button" name="btn_add" id="btn_add" class="btn btn-xs btn-success">+</button></td>  
			   </tr>  
		  ';  
	 }  
	 else  
	 {  
		  $output .= '
				   <tr>  
						<td></td>  
						<td id="name_room_add" contenteditable></td> 
						<td id="key_room_add" contenteditable></td> 
						<td><button type="button" name="btn_add" id="btn_add" class="btn btn-xs btn-success">+</button></td>  
				   </tr> 
					<tr>
		  				<td colspan="4">Data not Found</td>
					</tr>';  
	 }  
	 $output .= '</table>  
	
	
		  </div>';  
	 echo $output;  
	 mysqli_close($connect);
 ?>