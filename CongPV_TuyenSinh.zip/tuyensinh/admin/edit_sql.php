<?php 
	if($_POST["insert"]==1){
		try{
			include 'connect.php';
			$sql = "SELECT * FROM tb_room WHERE name_room = '".$_POST["name_room_add"]."' OR keyword = '".$_POST["key_room_add"]."'";
    		 $result = mysqli_query($connect, $sql);
			     if (mysqli_num_rows($result) > 0)
					{
					echo '"Tên viện" hoặc "tên viết tắt" của viện đã tồn tại, xin vui lòng nhập lại!';
						 
				}else{
					$sql = "INSERT INTO tb_room (name_room, keyword) VALUES('".$_POST["name_room_add"]."','".$_POST["key_room_add"]."')";  
					 if(mysqli_query($connect, $sql))  
					 {  
						  echo 'Thêm dữ liệu thành công';  
					 }
				}
			 mysqli_close($connect);
		}catch(PDOException $e){
			echo "lỗi" .$e->getMessage();
		}  
	}elseif($_POST["insert"]==2){
		try{
			include 'connect.php';
			 $id = $_POST["id"];  
			 $text = $_POST["name_room"];  
			 $sql = "UPDATE tb_room SET name_room ='".$text."' WHERE id ='".$id."'";  
			 if(mysqli_query($connect, $sql))  
			 {  
				  echo 'Đã sửa dữ liệu';  
			 } 
			 mysqli_close($connect);
		}catch(PDOException $e){
			echo "lỗi" .$e->getMessage();
		}  
	}elseif($_POST["insert"]==3){
		try{
			 include 'connect.php';  
			 $sql = "DELETE FROM tb_room WHERE id = '".$_POST["id"]."'";  
			 if(mysqli_query($connect, $sql))  
			 {  
				  echo 'đã xóa!';  
			 }  
			 mysqli_close($connect);
		}catch(PDOException $e){
			echo "lỗi" .$e->getMessage();
		} 
	}elseif($_POST["insert"]==4){
		try{
			 include 'connect.php';
			 $sql = "SELECT * FROM tb_user WHERE username = '".$_POST["user_name_add"]."' OR email = '".$_POST["email_add"]."'";
    		 $result = mysqli_query($connect, $sql);
			     if (mysqli_num_rows($result) > 0)
					{
					echo 'tài khoản đã tồn tại hoặc email đã được dùng, không thêm được người dùng!';
						 
				}else{
					$pass_add= md5($_POST["user_name_add"]."1234");  
					$sql = "INSERT INTO tb_user (username,password,email,fullname,level) VALUES('".$_POST["user_name_add"]."','".$pass_add."','".$_POST["email_add"]."','".$_POST["fullname_add"]."','".$_POST["select_room"]."')";  
					 if(mysqli_query($connect, $sql))  
					 {  
						  echo 'Thêm dữ liệu thành công';  
					 }
				}
			 mysqli_close($connect);
		}catch(PDOException $e){
			echo "lỗi" .$e->getMessage();
		} 
	}elseif($_POST["insert"]==5){
		try{
			 include 'connect.php';  
			 $sql = "DELETE FROM tb_user WHERE id = '".$_POST["id"]."'";  
			 if(mysqli_query($connect, $sql))  
			 {  
				  echo 'đã xóa!';  
			 }  
			 mysqli_close($connect);
		}catch(PDOException $e){
			echo "lỗi" .$e->getMessage();
		} 
	}elseif($_POST["insert"]==6){
		try{
			include 'connect.php';
			$pass_add= md5($_POST["name_edit"]."1234"); 
			 $sql = "UPDATE tb_user SET username ='".$_POST["name_edit"]."',password='".$pass_add."',email='".$_POST["email_edit"]."',fullname='".$_POST["fullname_edit"]."',level='".$_POST["select_room"]."' WHERE id ='".$_POST["id"]."'";  
			 if(mysqli_query($connect, $sql))  
			 {  
				  echo 'Đã sửa dữ liệu';  
			 } 
			 mysqli_close($connect);
		}catch(PDOException $e){
			echo "lỗi" .$e->getMessage();
		}  
	}elseif($_POST["insert"]==7){
		try{
			include 'connect.php';
			$pass_add= md5($_POST["name_room"]."1234"); 
			 $sql = "UPDATE tb_user SET password='".$pass_add."' WHERE id ='".$_POST["id"]."'";  
			 if(mysqli_query($connect, $sql))  
			 {  
				  echo 'Đã reset mật khẩu cho tài khoản '.$_POST["name_room"];  
			 } 
			 mysqli_close($connect);
		}catch(PDOException $e){
			echo "lỗi" .$e->getMessage();
		}  
	}
?>