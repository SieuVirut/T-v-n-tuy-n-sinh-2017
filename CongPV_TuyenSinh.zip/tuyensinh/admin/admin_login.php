<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');
 
if (isset($_POST['dangnhap'])) 
{
	include('connect.php');
     
    $name_admin = addslashes($_POST['txtname_admin']);
    $password_admin = addslashes($_POST['txtpassword_admin']);
    if (!$name_admin || !$password_admin) {
		echo '<script language="javascript">';
		echo 'alert("Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu")';
		echo '</script>';
		$url=$_SERVER['REQUEST_URI'];
  		header("Refresh: 1; URL=$url");
    }else{
		$password_admin = md5($password_admin);
		$query = mysqli_query($connect, "SELECT * FROM tb_admin WHERE name_admin='".$name_admin."' OR email_admin='".$name_admin."'");
		if (mysqli_num_rows($query) == 0) {
			echo '<script language="javascript">';
			echo 'alert("Tên đăng nhập này không tồn tại. Vui lòng kiểm tra lại.")';
			echo '</script>';
			$url=$_SERVER['REQUEST_URI'];
			header("Refresh: 1; URL=$url");
		} else{
			$row = mysqli_fetch_array($query);     
			if ($password_admin != $row['password_admin']) {
				echo '<script language="javascript">';
				echo 'alert("mật khẩu sai vui lòng nhập lại")';
				echo '</script>';
				$url=$_SERVER['REQUEST_URI'];
				header("Refresh: 1; URL=$url");
			}else{
				if($row['level']==1){
					$_SESSION['name_admin'] = $row['name_admin'];
					$_SESSION['level'] = $row['level'];
					echo "Xin chào " .$row['name_admin']. ". Bạn đã đăng nhập thành công. <a href='/'>về trang quản lý câu hỏi</a>";
					header("location:admin_manager.php");
					die();
				}
			}
		}
	}
}
?>
<!DOCTYPE html>
<html>
    <head>
    	<link rel="stylesheet" href="../lib/style_login.css" type="text/css" media="screen">
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
    	<div class="logo">
        	<a href="index.php"><img width="365px" src="../images/logo.png" alt="Tuyển sinh ĐHBK Hà Nội" ></a>
    </div>
    	<div class="Text">
        	<p style="margin:auto;text-align:Center;">
            	<span style="font-family:'Roboto', sans-serif;font-weight:700;font-size: 36px;color:#FFF;">Đăng nhập hệ thống</span>
            </p>
        </div>
        
    <div class="login-page">
        
        	<div class="form">
                <form class="login-form" action='admin_login.php?do=login' method='POST'>
                	<input type="text" placeholder="tên hoặc email" name='txtname_admin'/>
                    <input type="password" placeholder="password" name='txtpassword_admin'/>
                    <button type='submit' name="dangnhap" value='Đăng nhập'>login</button>
                </form>
                <a id="showmes" href="#">Bạn Quên mật khẩu?</a>
                <div class="mesdialog">
           <span style="font-family:'Roboto', sans-serif;font-weight:700;font-size: 14px;color:#4CAF50;">Vui lòng liên hệ quản trị website!</span>

            </div>
            </div>
        </div>
        
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
	<script src="../lib/jsshow.js"></script>
</body>
</html>