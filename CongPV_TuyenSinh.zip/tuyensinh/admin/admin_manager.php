﻿<?php
session_start();
if($_SESSION['level']=1){
	?>
<!doctype html>
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="stly.css">
<script src="https://code.jquery.com/jquery-2.2.0.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<title>Untitled Document</title>
</head>

<body style="background:#CCC; text-align:center; width:98%; margin: 0 auto;">

	<div id="ttrpage1" class="contain">
            <div class="header">
            	<a href="http://ts.hust.edu.vn">
                	<img src="../images/logo.png" alt="Tuyển sinh ĐHBK Hà Nội">
                </a>
            </div>
            <div>
                <h1 style="right:0%">Quản lý tài khoản Admin</h1>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                	<ul class="nav navbar-nav">
                        <li><a href="">Trang chủ</a></li>
                        <li><a href="" name="bt_reset_new" id="manager_room">Danh sách viện</a></li>
                        <li><a href="" name="manager_user" id="manager_user">Tài khoản người trả lời</a></li>
                        <li><a href="" name="manager_students" id="manager_students">Tài khoản sinh viên</a></li>
                    </ul>
                    	<ul class="nav navbar-nav navbar-right" >
                        <li><a href="#">Cá nhân</a></li>
                        <li><a href="../logout.php"><span class="glyphicon glyphicon-log-out"></span>Đăng Xuất</a></li>
                    </ul>
                </div>
            <div id="live_data"></div>
   </div>
</body>
</html>
<script>
	  $(document).ready(function() {
		  $('#manager_room').click(function(e) {
			   e.preventDefault();
            $('#live_data').load('select_sql.php'); 
		  });
	  });
	  $(document).on('click', '#btn_add', function(){  
           var name_room_add = $('#name_room_add').text();
           if(name_room_add == '')  
           {  
                alert("Vui lòng nhập tên viện được thêm!");  
                return false;  
           }
		   var key_room_add = $('#key_room_add').text();
           if(key_room_add == '')  
           {  
                alert("Vui lòng nhập tên viết tắt của viện được thêm!");  
                return false;  
           }

           $.ajax({  
                url:"edit_sql.php",  
                method:"POST",  
                data:{name_room_add:name_room_add,key_room_add:key_room_add,insert:1},
                success:function(data)  
                {  
                     alert(data);  
                     $('#live_data').load('select_sql.php');  
                }  
           })  
      });
	  $(document).on('click', '.name_room', function(){
		  	$(this).attr("contenteditable","true");
	  });
	  $(document).on('blur', '.name_room', function(){
			   var id = $(this).data("id1");  
			   var name_room = $(this).text();
			   $.ajax({  
					url:"edit_sql.php",  
					method:"POST",  
					data:{id:id, name_room:name_room, insert:2},
					success:function(data){  
						 alert(data); 
						 $('#live_data').load('select_sql.php'); 
					}  
			   });
			});
	  $(document).on('click', '.btn_delete', function(){  
           var id=$(this).data("id2");
		   var name_room =$('#name_id'+id).text();  
           if(confirm("Bạn muốn xóa "+name_room+ "chứ ?"))  
           {  
                $.ajax({  
                     url:"edit_sql.php",  
                     method:"POST",  
                     data:{id:id, insert:3}, 
                     success:function(data){  
                          alert(data);  
                          $('#live_data').load('select_sql.php');  
                     }  
                });  
           }  
      });
	  $(document).ready(function() {
		  $('#manager_user').click(function(e) {
			   e.preventDefault();
            	$('#live_data').load('select_sql2.php'); 
		  });
	  });
	  $(document).on('click', '#btn_add_user', function(){  
           var user_name_add = $('#user_name_add').text();
           if(user_name_add == '')  
           {  
                alert("Vui lòng thêm tên đăng nhập cho người dùng!");  
                return false;  
           }
		   var email_add = $('#email_add').text();
           if(email_add == '')  
           {  
                alert("Vui lòng nhập email cho người dùng!");  
                return false;  
           }
		   var fullname_add = $('#fullname_add').text();
           if(fullname_add == '')  
           {  
                alert("Vui lòng nhập Họ và Tên người dùng!");  
                return false;  
           }
		   var select_room = $('#select_room').val();
           $.ajax({  
                url:"edit_sql.php",  
                method:"POST",  
                data:{user_name_add:user_name_add,email_add:email_add,fullname_add:fullname_add,select_room:select_room.toString(),insert:4},
                success:function(data)  
                {  
                     alert(data);  
                     $('#live_data').load('select_sql2.php');  
                }  
           });  
      });
	  $(document).on('click', '.delete_user', function(){  
           var id=$(this).data("id6");
		   var name_room =$('#username_'+id).text();  
           if(confirm("Bạn muốn xóa "+name_room+ " chứ ?"))  
           {  
                $.ajax({  
                     url:"edit_sql.php",  
                     method:"POST",  
                     data:{id:id, insert:5}, 
                     success:function(data){  
                          alert(data);  
                          $('#live_data').load('select_sql2.php');  
                     }  
                });  
           }  
      });
	  $(document).on('click', '.btn_edit_user', function(){
		  	var id=$(this).data("id5");
			var select_mul='#select_room_'+id+' option';
			$("#tr_"+id).css('background-color', 'rgba(102,204,0,0.5)');
			$(select_mul).prop("disabled", false);
			$('#select_room_'+id).multiselect("refresh");
			$('#username_'+id).prop("contenteditable", true);
			$('#email_'+id).prop("contenteditable", true);
			$('#fullname_'+id).prop("contenteditable", true);
			$("#save_user_"+id).css('display', 'inline');
			$("#reset_user_"+id).css('display', 'inline');
			$("#edit_user_"+id).css('display', 'none');
			$("#delete_user_"+id).css('display', 'none');
	  });
	  $(document).on('click', '.btn_save_user', function(){  
           var id=$(this).data("id51");
		   var name_edit =$('#username_'+id).text();
		   if(name_edit == '')  
           {  
                alert("Vui lòng thêm tên đăng nhập cho người dùng!");  
                return false;  
           }
		   var email_edit = $('#email_'+id).text();
           if(email_edit == '')  
           {  
                alert("Vui lòng nhập email cho người dùng!");  
                return false;  
           }
		   var fullname_edit = $('#fullname_'+id).text();
           if(fullname_edit == '')  
           {  
                alert("Vui lòng nhập Họ và Tên người dùng!");  
                return false;  
           }
		   var select_room=$('#select_room_'+id).val();
           if(confirm("Bạn muốn lưu "+name_edit+ " chứ ?"))  
           {  
                $.ajax({  
                     url:"edit_sql.php",  
                     method:"POST",  
                     data:{id:id,name_edit:name_edit,email_edit:email_edit,fullname_edit:fullname_edit,select_room:select_room.toString(), insert:6}, 
                     success:function(data){  
                          alert(data);  
                          $('#live_data').load('select_sql2.php');  
                     }  
                });  
           }  
      });
	  $(document).on('click', '.reset_user', function(){  
           var id=$(this).data("id61");
		   var name_room =$('#username_'+id).text();  
           if(confirm("Bạn muốn reset mật khẩu của tài khoản "+name_room+ " chứ ?"))  
           {  
                $.ajax({  
                     url:"edit_sql.php",  
                     method:"POST",  
                     data:{id:id,name_room:name_room ,insert:7}, 
                     success:function(data){  
                          alert(data);  
                          $('#live_data').load('select_sql2.php');  
                     }  
                });  
           }  
      });
</script>
<?php }		
else{
			echo 'Xin mời đăng nhập! ';
			$url=$_SERVER['REQUEST_URI'];
			header("location:admin_login.php");
			}
?>