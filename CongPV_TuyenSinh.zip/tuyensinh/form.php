        <?php
			$dtz = new DateTimeZone("Asia/Ho_Chi_Minh");
			$now = new DateTime(date("Y-m-d H:i:s"), $dtz);
			$time =$now->format("Y-m-d H:i:s");
		if (isset($_POST['bt_insert_question'])) 
		{
			
			include('connect.php');
			$name = addslashes($_POST['name_question']);
			$address = addslashes($_POST['address_question']);
			$email = addslashes($_POST['email_question']);
			$phone = addslashes($_POST['numphone_question']);
			$type = addslashes($_POST['type_question']);
			$question = addslashes($_POST['main_question']);
			$sql="INSERT INTO tb_question ( name_question, address_question, email_question, phone_question, type_question, question, time_question) VALUES ('".$name."' ,'".$address."','".$email."','".$phone."','".$type."','".$question."','".$time."')";
			if(mysqli_query($connect, $sql)){
				echo '<script language="javascript">';
				echo 'alert("Câu hỏi của bạn đã được gửi đến tổ tư vấn!")';
				echo '</script>';
				$url=$_SERVER['REQUEST_URI'];
				header("Refresh: 1; URL=$url");
			}else{
				echo '<script language="javascript">';
				echo 'alert("Câu hỏi không gửi được hãy kiểm tra kết nối!")';
				echo '</script>';
				$url=$_SERVER['REQUEST_URI'];
				header("Refresh: 1; URL=$url");
				}
		}

 
		$inpt='<form method="post" style="margin:10px">
                                    <div class="input_text">
                                    	<div class="text_lab">Kính gửi: </div>
                                        <select class="text_sel" name="type_question">';
										
                                        try{
												include'connect.php';
												$sql_select_room="SELECT * from tb_room ORDER BY id";
												$dl_room=mysqli_query($connect, $sql_select_room);
											}catch (PDOException $e){
												die("lỗi" . $e->getMessage());
												}
											while($row = mysqli_fetch_array($dl_room)){
										$inpt .='<option value="'.$row["id"].'">'.$row["name_room"].'</option> ';
                                        }
                                      $inpt .='</select>
                                      <div class="underline_sel"></div>
                                      <div class="text_lab">Trường đại học bách khoa Hà Nội</div>
                                    </div>
                                    <div class="input_text">
                                    	<div class="text_lab">Tên em là: </div>
                                        <input class="text_q" type="text" name="name_question" >
                                        <div class="underline"></div>
                                        <div class="text_lab">, học sinh trường: </div>
                                        <input class="text_q" type="text" name="address_question">
                                        <div class="underline"></div>
                                    </div>
                                    <div class="input_text">
                                    	<div class="text_lab">, hòm thư điện tử của em là: </div>
                                        <input class="text_q" required x-autocompletetype="email" type="email" name="email_question">
                                        <div class="underline"></div>
                                        <div class="text_lab">, số điện thoại: </div>
										<input class="text_q" required x-autocompletetype="phone-full" type="tel" name="numphone_question" style="width:107px">
										<div class="underline" style="width:107px"></div>
                                    </div>
									
									<div class="input_text">
										<input class="text_q" type="text" name="title_q" readonly value="'.$_POST["a_title"].'">
										<div class="underline"></div>
									</div>
                                    <div>. Em muốn hỏi: "</div>
                                    <div class="input_text">
                                        <textarea class="text_q" rows="5" required placeholder="Câu hỏi" name="main_question" readonly>'.$_POST["a_content"].'</textarea>
                                        <div class="underline"></div>
                                    </div>
                                    <br>
                                    <div>" Mong thầy cô giải đáp giúp em, em xin chân thành cảm ơn! </div>
                                    <button name="bt_insert_question" style=" margin-left:40%">Gửi câu hỏi</button>
                                </form>';
								echo $inpt;
								?>