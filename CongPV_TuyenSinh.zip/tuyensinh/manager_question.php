<?php
session_start();
if($_SESSION['level']>=1){
$dtz = new DateTimeZone("Asia/Ho_Chi_Minh");
$date_now = new DateTime(date("Y-m-d"), $dtz);
$time_now = new DateTime(date("H:i:s"), $dtz);
$date_select =$date_now->format("Y-m-d");
$time_select =$time_now->format("H:i:s");
header('Content-Type: text/html; charset=UTF-8');
include('connect.php');
$tb_user = mysqli_fetch_array(mysqli_query($connect, "SELECT * FROM tb_user WHERE id='".$_SESSION['id_user']."'"));
$array_level = explode(",", $tb_user['level']);
?>
<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript" src="lib/jquery.js"></script>
<script type="text/javascript" src="lib/totop.js"></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<link rel="stylesheet" href="lib/style_question.css" type="text/css" media="screen">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<title>Untitled Document</title>

</head>


<body style="background:#CCC; text-align:center; width:98%; margin: 0 auto;">

	<div class="totopshow">
    	<a href="#" class="back-to-top">
        <img alt="Lên đầu trang" src="images/gototop0.png">
        </a>
    </div>
    
	<div id="ttrpage1" class="contain">
            <div class="header">
            	<a href="http://ts.hust.edu.vn">
                	<img src="images/logo.png" alt="Tuyển sinh ĐHBK Hà Nội">
                </a>
            </div>
            <div>
                <h1 style="right:0%">Quản lý câu hỏi <?php echo
				($tb_user['fullname']); ?></h1>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                	<ul class="nav navbar-nav">
                        <li><a href="">Trang chủ</a></li>
                        
                        <li class="dropdown"><a>Câu Hỏi Mới</a>
                        	<ul class="dropdown-menu" style="background-color:#ccc !important">
                            	<?php
								foreach($array_level as $array_value){
								$tb_room = mysqli_fetch_array(mysqli_query($connect, "SELECT * FROM tb_room WHERE id='".$array_value."'"));
								echo '<li><a href="" data-id1="'.$array_value.'" id="bt_reset_new'.$array_value.'" class="bt_reset_new">'.$tb_room["name_room"].'</a></li>';
								}
								?>
                            </ul>
                        </li>
                        <li class="dropdown"><a>Câu bạn đã trả lời</a>
                        	<ul class="dropdown-menu" style="background-color:#ccc !important">
                            	<?php
								foreach($array_level as $array_value){
								$tb_room = mysqli_fetch_array(mysqli_query($connect, "SELECT * FROM tb_room WHERE id='".$array_value."'"));
								echo '<li><a href="" data-id2="'.$array_value.'" id="bt_reset_old'.$array_value.'" class="bt_reset_old">'.$tb_room["name_room"].'</a></li>';
								}
								?>
                            </ul>
                        </li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right" >
                        <li><a href="#">Cá nhân <?php echo $tb_user['fullname'] ?></a></li>
                        <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span>Đăng Xuất</a></li>
                    </ul>
                </div>
            <div id="live_data"></div>
            
   </div>
</body>
</html>
<script>
	  $(document).on('click', '.bt_reset_new', function(e){
		  e.preventDefault();
			 var id=$(this).data("id1");
            $.ajax({  
                     url:"select_new.php",  
                     method:"POST",  
                     data:{id:id},   
                     success:function(data){
                          $('#live_data').html(data);  
                     }
		  });
	  });
	  $(document).on('click', '.bt_reset_old', function(e){
		  e.preventDefault();
			 var id=$(this).data("id2");
            $.ajax({  
                     url:"select_old.php",  
                     method:"POST",  
                     data:{id:id},   
                     success:function(data){
                          $('#live_data').html(data);  
                     }
		  });
	  });
		  $(document).on('mouseenter mouseleave', '.btn', function(){  
           var id=$(this).data("id00");
		   		var bttt="#show_infoi" +id;
               $.ajax({  
               		url:"answer.php",  
                    method:"POST",  
                    data:{id_select:id, get:3},   
                    success:function(data){
						var bttt="#show_infoi" +id;
                          $(bttt).html(data);  
                     }  
                });
				$(bttt).toggle("slow");
				
		  });
      $(document).on('click', '.btn_return', function(){  
           var id=$(this).data("id6");  
           if(confirm("Bạn muốn câu hỏi chuyển sang viện khác? Câu hỏi không thuộc viện (khoa) của bạn?"))  
           {  
                $.ajax({  
                     url:"answer.php",  
                     method:"POST",  
                     data:{id:id,get:2},   
                     success:function(data){  
 						  alert("Được chuyển lên tổ hỗ trợ");
                          $('#live_data').load('select_new.php');  
                     }  
                });  
           }  
      });
      $(document).on('click', '.btn-success', function(){
		var count_check=0;
		$('td').each(function(){
			if(Number.isInteger($(this).find('.checkbox_td').data("id0"))){
				var id=$(this).find('.checkbox_td').data("id0");
				var answer="#answer_"+id;
				if($(answer).val().length >=40) {
					count_check++;
					}
				}
				
			});
			if(count_check==0){
				alert("chưa có câu hỏi được trả lời");
				return false;
			}
		  if(($('#time_math2').val().length>0)){
			  if(($('#time_math4').val().length>0)){
				   var date =$('#time_math2').val() +" "+ $('#time_math4').val();
				   if(confirm("Bạn muốn public câu hỏi này vào ngày: "+ date)){
					   $('td').each(function(){
							if(Number.isInteger($(this).find('.btn_return').data("id6"))){
								var id=$(this).find('.btn_return').data("id6");
								var answer="#answer_"+id;
								if($(answer).val().length >=40) {
									var main_ans=$(answer).val();
									$.ajax({  
										 url:"answer.php",  
										 method:"POST",  
										 data:{id:id,main_ans:main_ans,date:date,id_user:<?php echo $tb_user['id'] ?>,get:1},   
										 success:function(data){
											  $('#live_data').load('select_new.php');  
										 }  
									});						
								}
							}
					   });
					   alert("Hoàn thành!");
				   }
			  }
			   
		  }else{
			  $('#time_math5').css("color", "red");
			  }
		   
      });
	  $(document).on('dblclick', '.ud_date', function(){  
           var id=$(this).data("idtong");  
		   var bt_40="#date_update"+id;
		   var text_40="#answer_update"+id;
		   if($(bt_40).prop('disabled')==true){
			   if(confirm("Bạn muốn cập nhật lại câu bạn vừa double click ?"))  
			   {
				   $(bt_40).prop('disabled', false);
				   $(text_40).prop('disabled', false);
			   }  
		   }
      });  
	  $(document).on('click', '.btn_return_2', function(){
		  var id = $(this).data('id60');
		  if($('#answer_update'+id).val().length>=40){
				  var answer_up=$('#answer_update'+id).val();
				  var date_up=$('#date_update'+id).val();
				  if(confirm("Bạn muốn cập nhập ngày bublic câu trả lời: "+ date_up)){
					  $.ajax({
						url:"answer.php",  
						method:"POST",  
						data:{id:id,get:4,answer_up:answer_up,date_up:date_up},   
						success:function(data){  
							alert("Cập nhật thành công");
							$('#live_data').load('select_old.php');
						}
					   });
				  }
		  }else{
			  alert("bạn chưa nhập nội dung câu trả lời cho câu này");
		}
	  });
		
</script>

<?php
}
		else{
			echo 'Xin mời đăng nhập! ';
			$url=$_SERVER['REQUEST_URI'];
			header("location:login.php");
			}
?>