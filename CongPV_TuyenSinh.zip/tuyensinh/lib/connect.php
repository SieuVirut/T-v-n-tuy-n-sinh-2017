<?php

    $connect= mysqli_connect("localhost","root","","tuyensinhsql") or die("Không thể kết nối database");
    mysqli_select_db($connect,"tuyensinhsql") or die("Không thể chọn database");
?>