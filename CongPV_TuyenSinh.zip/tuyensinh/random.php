<?php 
			include'connect.php';
			$sql_select="SELECT * from tb_question ORDER BY time_public DESC";
			$dl=mysqli_query($connect, $sql_select);
		while($row = mysqli_fetch_array($dl)){
			if(!empty($row['rep_question'])){
				$like_count =rand(1000, 100000);
				$sql = "UPDATE tb_question SET rank_view = '".$like_count."' WHERE id= '".$row["id"]."'";
				mysqli_query($connect, $sql);
			}
			}
?>