<?php
session_start();
if($_SESSION['level']>=1){
	$dtz = new DateTimeZone("Asia/Ho_Chi_Minh");
	$date_now = new DateTime(date("Y-m-d"), $dtz);
	$time_now = new DateTime(date("H:i"), $dtz);
	$date_select =$date_now->format("Y-m-d");
	$hour_select =$time_now->format("H");
	$minute_select=$time_now->format("i");
	$hour_next=$hour_select+1;
	if($hour_next>=24){
		$date_select = date('Y-m-d', strtotime('+1 day', strtotime($date_select)));
	}
	$output='<h2 style="text-align: centre">Câu hỏi mới</h2>
				<div id="mana_question" style=" text-align:center;">
				<table border="1px" style="width:100%">
						<tr bgcolor="#CC3300" style="color:#FFFFFF; font-weight:bold">
							<td style="width:3%"></td>
							<td style="width:10%">Người trả lời</td>
							<td style="width:10%">Thời gian trả</td>
							<td style="width:10%">Email</td>
							<td style="width:10%">Địa Chỉ</td>
							<td style="width:60%">Câu Hỏi</td>
						</tr>
					</table>
					<form name="answer_1" method="post">';	
					try{
					include'connect.php';
					$mangID[]=0;
					$sql_select="SELECT * from tb_question WHERE type_question='".$_POST["id"]."' ORDER BY id";
					$dl=mysqli_query($connect, $sql_select);
					}	
					catch (PDOException $e){
					die("lỗi" .$e->getMessage());
					}
					if(mysqli_num_rows($dl) > 0)
					{  
						while($row = mysqli_fetch_array($dl))
							{ 	
							if(empty($row['rep_question'])){
								$mangID[]=$row['id'];
								$output.='
								<div id="tb_'.$row["id"].'">
									<table border="1px" style="width:100%">
										<tr id="main_question" style=" color:#333; width:100%">
											<td style="width:3%"><input type="checkbox" name="vehicle" data-id0="'.$row["id"].'" id="'.$row["id"].'" class="checkbox_td"></td>
											<td style="width:10%" data-id1="'.$row["id"].'">'.$row["name_question"].'</td>
											<td style="width:10%" data-id2="'.$row["id"].'">'.$row["phone_question"].'</td>
											<td style="width:10%" data-id3="'.$row["id"].'">'.$row["email_question"].'</td>
											<td style="width:10%" data-id4="'.$row["id"].'">'.$row["address_question"].'</td>
											<td id="main_'.$row["id"].'" style="width:50%" data-id5="'.$row["id"].'">'.$row["question"].'</td>
											<td><button type="button" name="return_btn" data-id6="'.$row["id"].'" class="btn btn-xs btn-danger btn_return">X</button></td>
										</tr>
									</table>
									<textarea name="main_answer'.$row["id"].'" id="answer_'.$row["id"].'" bgcolor="#CC3300" style=" width:100%; height:100px; display:none; font-weight:bold" placeholder="Phần trả lời, Lưu ý câu trả lời phải lớn hơn 10 chữ!"></textarea>
									<script>
									$("#main_'.$row["id"].'").click(function(){
										$("#answer_'.$row["id"].'").toggle("slow");
										$(this).toggleClass("green");
										});
									$("#answer_'.$row["id"].'").keydown(function() {
										var len = $(this).val().length;
										if(len >=40) {
											$("#'.$row["id"].'").prop("checked",true);
											$("#tb_'.$row["id"].'").css("background","rgba(112,217,81,1)");
										}else{
											$("#'.$row["id"].'").prop("checked",false);
											$("#tb_'.$row["id"].'").css("background","none");
										}
									});
									$("#'.$row["id"].'").click(function(){
										var len = $("#answer_'.$row["id"].'").val().length;
										if(len >=40) {
											$("#'.$row["id"].'").prop("checked",true);
											$("#tb_'.$row["id"].'").css("background","rgba(112,217,81,1)");
										}else{
											$("#tb_'.$row["id"].'").css("background","none");
											$("#'.$row["id"].'").prop("checked",false);
											alert("câu hỏi chưa được trả lời, hoặc câu trả lời dưới 40 ký tự vui lòng kiểm tra !")
										}									
									});
									</script>
								</div>
								';
								
							}
						 }
					}else{
						echo'<h1>Không có câu hỏi trong hệ thống</h1>';
					}	
					$output .='<div id="from_success">
						<div style="margin:10% auto">
						<label id="time_math1">Chọn thời gian public</label>
						<input id="time_math2" type="date" name="bday" min='.$date_select .' required>
						<label id="time_math3">Vào lúc: </label>
						<input id="time_math4" type="time" name="hrs" placeholder="hrs:mins" value="" pattern="^([0-1]?[0-9]|2[0-4]):([0-5][0-9])(:[0-5][0-9])?$" class="inputs duration t1 time hrs" required>
						<label id="time_math5">Vui lòng chọn ngày giờ dữ liệu được public</label>
						<button type="button" name="btn_add" id="btn_add" class="btn btn-xs btn-success">Lưu</button>
						<script>
							$("#time_math2").hover(function() {
								var date_input = $("#time_math2").val();
								var date_now= "'.$date_select.'";
								var time_next= '.$hour_next. ';	
								if(new Date(date_now).getTime()==new Date(date_input).getTime()){
									if(time_next <24){
										if(time_next<10){
											$("#time_math4").prop("min","0'.$hour_next.':00");
											$("#time_math4").val("0'.$hour_next.':00");
										}else{
											$("#time_math4").prop("min","'.$hour_next.':00");
											$("#time_math4").val("'.$hour_next.':00");
										}
										$("#time_math4").prop("max", "23:59");
										$("#time_math5").text("Dữ liệu sẽ được public tối thiểu sau '.$hour_next.':00 giờ hôm nay");
									}
								}else{
									$("#time_math5").text("Vui lòng chọn giờ dữ liệu public" );
									$("#time_math4").val("00:00");
								}
							});
						</script>
						</div>
						</div>
				</form>
				<button id="button_sub" name="button_answer">Hoàn thành trả lời</button>
				</div>
				<script>
					$s=0;
					$("#button_sub").click(function(){
						if($s==0){ 
							$(this).text("Quay lại");
							$("#from_success").css("display","block");
							$s=1;}
						else{
							$(this).text("Hoàn thành trả lời");
							$("#from_success").css("display","none");
							$s=0;}
						});
				</script>';
				mysqli_close($connect);
				echo $output;
}else{
	$url=$_SERVER['REQUEST_URI'];
	header("location:index.php");
}
        ?>