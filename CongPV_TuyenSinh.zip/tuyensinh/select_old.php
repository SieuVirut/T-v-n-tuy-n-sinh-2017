<?php
session_start();
if($_SESSION['level']>=1){
$dtz = new DateTimeZone("Asia/Ho_Chi_Minh");
$date_now = new DateTime(date("Y-m-d"), $dtz);
$time_now = new DateTime(date("H:i:s"), $dtz);
$date_select =$date_now->format("Y-m-d");
$time_select =$time_now->format("H:i:s");
$output='<h2 style="text-align: centre">Câu hỏi đã trả lời</h2>
			<div id="mana_question" style=" text-align:center;">
        	<table border="1px" style="width:100%">
                    <tr bgcolor="#CC3300" style="color:#FFFFFF; font-weight:bold">
						<td style="width:5%">info</td>
                        <td style="width:30%">Câu hỏi </td>
                        <td style="width:40%">câu trả lời</td>
                        <td style="width:10%">Thời gian trả lời</td>
                        <td style="width:10%">Thời gian public</td>
						<td style="width:5%"> lưu</td>
                	</tr>
				<form name="answer_1" method="post">';	
                try{
                include'connect.php';
				$mangID[]=0;
                $sql_select="SELECT * from tb_question WHERE type_question='".$_POST["id"]."' AND id_user='".$_SESSION['id_user']."' ORDER BY id";
                $dl=mysqli_query($connect, $sql_select);
                }	
                catch (PDOException $e){
                die("lỗi" .$e->getMessage());
                }
				if(mysqli_num_rows($dl) > 0)
				{  
					while($row = mysqli_fetch_array($dl))
						{ 	
						if(!empty($row['rep_question'])){
							$date_public = date("Y-m-d", strtotime($row["time_public"]));
							$time_public = date("H:s", strtotime($row["time_public"]));
							$mindate_public = date("Y-m-d", strtotime($row["time_public"]));
							$mintime_public = date("H:s", strtotime($row["time_public"]));
							$mangID[]=$row['id'];
							$output.='
								<tr id="rows2_'.$row["id"].'" data-idtong="'.$row["id"].'" class="ud_date" style=" color:#333; width:100%">
									<td style="width:5%"><button type="button" class="btn glyphicon glyphicon-info-sign" name="vehicle" data-id00="'.$row["id"].'"></button><div id="show_infoi'.$row["id"].'" class="show_info"></div></td>
									<td data-id10="'.$row["id"].'">'.$row["question"].'</td>
									<td><textarea  data-id20="'.$row["id"].'" style="width:100%;" rows="5" id="answer_update'.$row["id"].'" disabled="disabled" class="ans_up2">'.$row["rep_question"].'</textarea></td>
									<td data-id30="'.$row["id"].'">'.$row["time_rep_question"].'</td>
									<td><input data-id40="'.$row["id"].'" id="date_update'.$row["id"].'" type="datetime-local" name="bday" value="'.$date_public.'T'.$time_public.'" min="'.$mindate_public.'T'.$mintime_public.'" pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}" disabled="disabled" required="required"><span class="validity"></span></td>
									<td><button type="checkbox" name="return_btn" data-id60="'.$row["id"].'" class="btn btn-xs btn-danger btn_return_2">Lưu</button></td>
								</tr>
								<script>
									$("#answer_update'.$row["id"].'").keydown(function() {
										var len = $(this).val().length;
										if(len >=40) {
											$("#rows2_'.$row["id"].'").css("background","rgba(112,217,81,1)");
										}else{
											$("#rows2_'.$row["id"].'").css("background","none");
										}
									});
									
								</script>
							';
							
						}
					 }
				
				}else{
					echo'<h1>Không có câu hỏi trong hệ thống</h1>';
				}
				 mysqli_close($connect);	
                $output .='
            </form>
			</table>
			</div>';
			echo $output;
}else{
	$url=$_SERVER['REQUEST_URI'];
	header("location:index.php");
}
?>