<?php 
session_start();
$session_name ='question_' . $_POST["id"];
if( empty($_SESSION[$session_name])||($_SESSION[$session_name])==0 )
{
	$_SESSION[$session_name] = 1;
		try{
			include 'connect.php';
			$sql = "UPDATE tb_question SET rank_view = rank_view + 1 WHERE id= '".$_POST["id"]."'";
			     if(mysqli_query($connect, $sql)) 
					{
						$sql = "SELECT * FROM tb_question WHERE id= '".$_POST["id"]."'";
						$dl=mysqli_query($connect, $sql);
						$row = mysqli_fetch_array($dl);
						echo $row["rank_view"];
					}
			 mysqli_close($connect);
		}catch(PDOException $e){
			echo "lỗi" .$e->getMessage();
		}  
	}else{
		$_SESSION[$session_name] = 0;
		try{
			include 'connect.php';
			$sql = "UPDATE tb_question SET rank_view = rank_view-1 WHERE id= '".$_POST["id"]."'";
			     if(mysqli_query($connect, $sql)) 
					{
						$sql = "SELECT * FROM tb_question WHERE id= '".$_POST["id"]."'";
						$dl=mysqli_query($connect, $sql);
						$row = mysqli_fetch_array($dl);
						echo $row["rank_view"];
					}
			 mysqli_close($connect);
		}catch(PDOException $e){
			echo "lỗi" .$e->getMessage();
		}  
	}
?>