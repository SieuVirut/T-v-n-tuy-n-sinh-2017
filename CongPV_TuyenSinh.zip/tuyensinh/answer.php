<?php 
								if($_POST["get"]==1){
									try{
										$dtz = new DateTimeZone("Asia/Ho_Chi_Minh");
										$date_now = new DateTime(date("Y-m-d H:i:s"), $dtz);
										$date_select =$date_now->format("Y-m-d H:i:s");
										include'connect.php';
										$sqli_update="UPDATE tb_question SET rep_question='".$_POST["main_ans"]."',id_user='".$_POST["id_user"]."', time_public='".$_POST["date"].":00', time_rep_question='".$date_select."' WHERE id='".$_POST["id"]."'";
										echo $sqli_update;
										mysqli_query($connect, $sqli_update);
										mysqli_close($connect);
									}
									catch(PDOException $e){
											echo "lỗi" . $e->getMessage();
											mysqli_close($connect);
										}
								}elseif($_POST["get"]==2){
									 try{
										 include 'connect.php';
										 $sql = "UPDATE tb_question SET type_question='1' where id ='".$_POST["id"]."'";  
										 if(mysqli_query($connect, $sql))  
										 {  
											  echo 'Đã chuyển lên tổ hỗ trợ';  
											  mysqli_close($connect);
										 }  
									 }catch(PDOException $e){
										 die("lỗi" .$e->getMessage());
										 
									}
								}elseif($_POST["get"]==3){
									try{
										include 'connect.php';  
										$dl_sel=mysqli_fetch_array(mysqli_query($connect, "SELECT * from tb_question WHERE id ='".$_POST["id_select"]."'"));
									}catch(PDOException $e){
										die("lỗi" .$e->getMessage());
																			 
										}
										$output ='
										<div>THÔNG TIN NGƯỜI GỬI CÂU HỎI</div>
										<div>Bạn :'.$dl_sel["name_question"].'</div>
										<div>Số Điện thoại: '.$dl_sel["phone_question"].'</div>
										<div>Địa chỉ email: '.$dl_sel["email_question"].'</div>
										<div>Trường: '.$dl_sel["address_question"].'</div>
										<div>Thời gian hỏi: '.$dl_sel["time_question"].'</div>
										';
										echo $output;
										mysqli_close($connect);
								}elseif($_POST["get"]==4){
									try{
										include'connect.php';
										$sqli_update="UPDATE tb_question SET rep_question='".$_POST["answer_up"]."', time_public='".$_POST["date_up"].":00' WHERE id='".$_POST["id"]."'";
										echo $sqli_update;
										mysqli_query($connect, $sqli_update);
										mysqli_close($connect);
									}
									catch(PDOException $e){
											echo "lỗi" . $e->getMessage();
											mysqli_close($connect);
										}
								}
			  ?>